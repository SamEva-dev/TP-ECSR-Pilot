# Registre anomalies — lot1 du 07/11/2026

## task-14 — P2 — Double inscription : compte existant présenté comme service d’authentification indisponible

Statut : todo

AUTH-UI-006, staging 07/11/2026 19:27 UTC ; visiteur, USER-01 déjà créé Centre Horizon ECSR. URL /register?email=sam.user1@email.com. Repro : Create an account, renseigner mêmes organisation/prénom/nom/email et mot de passe conforme, valider. Attendu : compte existant indiqué ou orientation explicite vers connexion. Observé : The authentication service is temporarily unavailable ; HTTP400 sur POST AuthGate /api/Auth/register-with-tenant (req313). Aucun doublon démontré ; défaut de restitution d’erreur métier. Snapshot41 et capture duplicate-inscription.png. Les nouvelles inscriptions ont fonctionné pour les quatre comptes. Gravité medium / P2.

## task-15 — P3 — Pilotage organisation neuve : sections vides sans message explicite

Statut : todo

ORG-INIT-003. USER-01 Direction / Responsable pédagogique, Centre Horizon ECSR cdd10510-dff3-418c-8fff-883a7b29ef36. URL https://pedagora.staging.locaguest.com/organisation. Après inscription neuve sans données métier, ouvrir Organization overview. Attendu cahier : conteneurs visibles et états vides explicites. Observé : Site performance, Performance by program, Alerts et Recent activity ne présentent que titres/colonnes, aucun message expliquant l’absence de données. Indicateurs bien à zéro ; aucune donnée fictive démontrée. Snapshot53, capture horizon-pilotage-initial.png, dashboard HTTP200. Impact mineur : ambiguïté données absentes/chargement non abouti. Gravité low/P3.

## task-16 — P1 — Mot de passe oublié : le lien retourne à la connexion sans récupération

Statut : todo

AUTH-UI-023. Staging 07/11/2026 19:30 UTC ; visiteur, compte USER-02 actif Académie Azur Deux-Roues. Repro : /connexion, saisir sam.user2@email.com, Continue, cliquer Forgot password? (href /mot-de-passe-oublie). Attendu : formulaire de demande puis instructions de récupération. Observé : retour /connexion vierge sans formulaire ni message. Demande impossible, email non envoyé/vérifié. Snapshot61 avant / snapshot62 après ; capture forgot-password.png. Perte d’accès au compte si mot de passe oublié : parcours entier de récupération inaccessible depuis lien. Gravité high/P1. Aucun mot de passe changé.

## task-17 — P3 — Présences : paramètre {{count}} affiché au lieu du nombre d’absences justifiées

Statut : todo

MENU-UI-009 (itération USER-01). Staging 07/11/2026 19:32 UTC. Centre Horizon ECSR, Direction/Responsable pédagogique ; aucune séance ni stagiaire. Ouvrir https://pedagora.staging.locaguest.com/presences. Attendu : libellé résolu including 0 excused ou état neutre. Observé : including {{count}} excused sous Missed hours 0h. Snapshot84, capture attendance-empty.png. Aucun calcul d’heures avec données réelles encore vérifié. Gravité low/P3 ; défaut d’interpolation distinct de clés brutes task-4.

## Preuves locales
- task-14 : duplicate-inscription.png / test-34
- task-15 : horizon-pilotage-initial.png / test-36
- task-16 : forgot-password.png / test-37
- task-17 : attendance-empty.png / test-38
