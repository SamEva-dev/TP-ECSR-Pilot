# Plan de recette — cahier QA V2 du 07/11/2026

Source : PedagoraPilotCahierRecetteQA.docx. Inventaire : 793 IDs uniques, dont 47 SIG-E2E. Une ligne de registre correspond à un ID du cahier ; les répétitions par compte sont des itérations, pas de nouveaux scénarios.

## Ordre et dépendances
1. AUTH-UI-001 à 008 : accès, inscription des quatre propriétaires, connexion, doublon et rattachement inter-application conditionnel. Enregistrer les organisations réellement créées.
2. AUTH-UI-009 à 026 : validation, session, accès protégé, mot de passe et OIDC conditionnel. Ne jamais forcer une précondition absente.
3. CTX-UI puis MENU-UI : état vide dans les quatre centres avant création métier. Compléter les interactions, changements de vues, filtres et vérifications réseau ; une simple ouverture ne vaut pas PASS.
4. ORG-INIT : assistant, état neuf, parcours et dépendances. ORG-COM/ORG-SPEC : responsable éligible du centre → site → formation spécialisée → référentiel/version → promotion → stagiaires et formateurs. Recharger après chaque mutation, vérifier contexte et pilotage.
5. TEN/ACC : isolation, rôles et invitations croisées exclusivement prévues dans le cahier ; aucun propriétaire d’un autre centre substitué à un personnel métier local.
6. ADM/PRO/STG : configuration pédagogique, promotions et dossiers avec rattachements réels et données fictives. Ne pas renseigner SIRET/agrément inventés.
7. PLN/SES : planning puis séances ; CON/FIC/COM : conduite, exposés et évaluations de compétences. Conserver les créations pour les campagnes suivantes.
8. PRE puis SIG-E2E prioritaires dès que 3 stagiaires actifs et leur formateur sont disponibles. Préparer séance 2h × 3 ; établir réalisé 6h, confirmé 2h, non confirmé 4h par actions réelles. Tester demandes individuelles/collectives, confirmation, attente, contestation, correction et obsolescence, nouvelle demande, interdiction d’agir pour autrui et indépendance des compétences.
9. STA/DOC : stages/tuteurs et documents. Préserver données nécessaires à progression et statistiques. L’accès à une boîte de réception doit être prouvé avant tout verdict de livraison.
10. DAT : événements produits par les actions QA ; RAP/JUR : rapports, statistiques, jury et certification, calculs manuels et cohérence transverse.
11. Rejouer les anomalies ouvertes dans leur contexte exact ; tester logout, refresh, retours et permissions. Aucun GO tant que flux indispensables non validés.

## Préconditions et limites constatées au lot 1
- Staging déjà accessible, aucun démarrage local effectué. Navigateur existant onglet1 uniquement, aucun nouvel onglet.
- Quatre comptes initialement orientés vers inscription, créés via formulaire puis connectés et actualisés. Le parcours observé n’impose pas de confirmation e-mail ; cela ne vérifie pas la configuration des autres environnements.
- Centre Horizon ECSR : propriétaire Sam Horizon QA déjà éligible comme responsable de site. L’état « aucun responsable éligible » d’ORG-INIT-005 n’est donc pas disponible tel quel.
- Pas d’identité inter-application fournie pour AUTH-UI-007/008 ; pas de second profil indépendant pour AUTH-UI-018 ; fenêtre privée d’AUTH-UI-015 incompatible avec contrainte onglet unique. Variante même onglet vérifiée séparément.
- Changement de mot de passe actuel/nouveau non exposé dans les UI examinées ; aucun mot de passe changé.
- Mode legacy ; OIDC métier non actif selon configuration et avertissement UI.
- Aucune boîte e-mail de test accessible fournie. Ne pas considérer les e-mails reçus.
- Aucun site, formation, référentiel, promotion, stagiaire ou séance créé au lot1 : conserver l’état vide pour terminer MENU-UI sur les quatre centres.
- Captures Chrome avec filePath refusées par les racines du serveur ; captures inline sauvegardées en PNG par base64 via detached-command. Aucun code applicatif modifié.

## Reprise exacte
Terminer AUTH-UI-017 (retour depuis une page métier après déconnexion), puis MENU-UI sur USER-01 et USER-02/03/04 avant de construire les parcours. Les ouvertures partielles Horizon sont conservées dans observation-horizon-*.txt et ne valent pas validation complète. Compléter ORG-INIT-004/006/007 puis démarrer ORG-COM avec le responsable propre au centre. Réutiliser tests CC existants et registre, sans réinscrire les quatre comptes.
