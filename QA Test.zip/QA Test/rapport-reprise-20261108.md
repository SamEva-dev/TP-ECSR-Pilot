# Reprise QA PedagoraPilot — lot du 8 novembre 2026
Staging : https://pedagora.staging.locaguest.com. Conclusion **NO GO**. Campagne poursuivie, non recommencée. Exécution UI uniquement, quatre comptes existants, aucun code applicatif modifié. Heure des journaux UTC du 7 novembre au soir, date de campagne Europe/Paris 8 novembre.

## Référentiel et comptage
Le DOCX QA V2 et son extraction existante recensent 793 identifiants uniques, dont47 SIG-E2E. Historique du07/11 vérifié :17PASS+4FAIL+9BLOCKED+3N/A+760NOT_RUN=793 ; 21 exécutés signifie PASS+FAIL et ne compte pas les blocages. Archive QA Test(1).zip non retrouvée dans le workspace ; rapports détaillés, registres et CC durables présents utilisés.
Après ce lot : **27PASS,3FAIL,9BLOCKED,3N/A,751NOT_RUN**, soit30 scénarios exécutés, couverture30/793=3,78%, réussite27/30=90%. Neuf nouveaux scénarios exécutés, quatre scénarios FAIL historiques retestés. Les17PASS historiques restent historiques : ils n'ont pas tous été rejoués. Aucun blocage historique promu artificiellement en PASS.

## Retest des quatre tickets du premier lot QA
|Ticket|Résultat|Preuves|
|---|---|---|
|task-14 P2|STILL FAILING : compte déjà existant traité comme indisponibilité authentification ; HTTP400, req131|retest-duplicate.png, test34/run45|
|task-15 P3|STILL FAILING : sections vides sans texte explicite, avant mutations métier|retest-pilotage.png, test36/run43|
|task-16 P1|FIXED : ouverture reset et email conservé ; demande200 req127, message conditionnel maîtrisé|retest-reset-prefill/result.png, test37/run44|
|task-17 P3|FIXED : aucun {{count}}, zéro absence justifiée rendu correctement dans les quatre centres|presence-user1..4.png, test38/run57|

Ces corrections ne prouvent ni réception d'un email ni bon calcul des heures sur une vraie séance.

## Autres tickets historiques et régressions
- task-1 : STILL FAILING partiellement. Auto-invitation Horizon exacte puis casse/espaces renvoie409, message générique Unable to send this invitation (req206/208), sans doublon après reload. La branche invitation inter-organisations USER01→USER02 fonctionne maintenant et reste en attente ; ancien ECF/AFTRAL non rejoué. test2/run46 et test5/run48, retest-self-invite.png.
- task-2 : NOT REPRODUCIBLE sur validations invitation, formation et séance Horizon ; messages requis présents. Aucune affirmation sur les anciens tenants. tests3/run47,9/run54,14/run58.
- task-3 : NOT REPRODUCIBLE selon contrat actuel : texte explique que les affectations sont définissables après acceptation et activation. Les invitations persistent. Ancien ECF non rejoué.
- task-5 : STILL FAILING partiellement : doublon code site rejeté409 (req602, amélioré depuis500), mais texte brut sites.validation.save.conflict. Annulation puis reload : un seul site. test8/run50, retest-site-conflict.png.
- task-18 : **nouveau P2**, blocage silencieux d'une promotion sans responsable éligible. Horizon, Direction, /promotions. Ouvrir création sous HORIZ-QA-01 et programme ECSR ; saisir ECSR2027-sessionA,04/01/2027–30/06/2027,effectif3,versionCCP1+CCP2 ; aucun responsable disponible ; cliquer Create cohort : aucun message, aucun marqueur, aucune requête de sauvegarde. Attendu : signaler le prérequis et permettre sa résolution. PRO-UI-010 FAIL, test10/run55 étape82, cohort-manager-silent.png. Régression révélée après corrections ; causalité avec un correctif non démontrée. PRO-UI-008 reste PASS car il autorise explicitement un blocage OU un signalement et aucun enregistrement invalide n'a été créé.
Les tickets4,6–13 restent historiques et non retestés complètement dans ce lot. Ils ne sont pas clôturés sur la base d'autres tenants. Le registre CC exporté conserve leurs détails et anciens liens.

## Données préparées et contrôle multi-tenant
Quatre propriétaires reconnectés séparément ; contexte propre avant mutation, sauvegarde puis actualisation et ouverture du Contexte de travail :
|Compte|Organisation|Établissement QA persistant|
|---|---|---|
|USER01|Centre Horizon ECSR|HORIZ-QA-01 / Site QA Nice,06000|
|USER02|Académie Azur Deux-Roues|AZUR-QA-01 / Site QA Antibes — recette,06600|
|USER03|Institut Provence Poids Lourds|PROV-QA-01 / Site QA Marseille,13000|
|USER04|Institut Méditerranée Ambulancier|MED-QA-01 / Site QA Toulon,83000|
Responsable de site = propriétaire de chaque centre. Adresse explicitement fictive, aucun SIRET ni agrément inventé. Chaque compte ne présentait que son organisation et son site. Captures site-user1.png,azure-site-context.png,provence-site-context.png,site-user4.png. Création test8/runs50–53, modification+doublon seulement Azur. Ne pas assimiler les étapes skip des runs51–53 à des cycles CRUD complets.
Horizon : programme HORIZ-ECSR-QA, TP Enseignant de la conduite et de la sécurité routière, Draft,140h de recette fictive,5modules par défaut, référentiel RNCP41862 - CCP1 + CCP2 créé par le formulaire ; offering au siteHORIZ-QA-01. Reload :1site,No manager assigned ; programme sélectionnable dans le contexte malgré Draft. IDs : programme46ce6072-ea7f-4706-a059-9059d5fe5ed6, version996d3ec0-8b41-49c6-b6cd-8d8192c24fb0. Aucun programme créé dans les trois autres centres pour ce lot.
Horizon : quatre lignes d'accès après reload : propriétaire actif, Gestion ECSR QA/Administration invité, USER02/Trainer invité, Responsable ECSR QA/Educational manager invité.1actif,0affectation,0multi. Aucun compte recréé ; aucun mot de passe changé. Invitations non acceptées, aucun email reçu prouvé. Propriétaire ne peut pas sélectionner un autre rôle via sa propre affectation examinée ; dialogue annulé.

## Couverture partielle non promue en PASS du cahier
ORG-COM création site exécutée dans les quatre centres, mais contrôle complet du pilotage après création restant ; ORG-COM formation uniquement Horizon et volume technique adapté. ACC-UI-002 soumission entièrement vide contrôlée ; toutes les omissions individuelles ne sont pas couvertes. PRO-UI-010 défaut documenté. test14/run58 : validation séance vide PASS, sauvegarde séance SKIP faute de promotion et formateur actif. Les statuts automatiques passing des runs comportant des skip ne prouvent pas le parcours complet.
Le registre campagne-20261108.json conserve les793 références et les verdicts antérieurs, avec historique pour chaque ligne modifiée. suivi-detaille-20261108.md présente attendu, observé, tests et preuves par ID ; CSV exploitable joint.

## Blocages et non-régression
Aucune promotion, aucun stagiaire et aucune séance QA créés. Responsable pédagogique/formateur actif et affecté non disponible ; invitations en attente sans boîte accessible. Les vérifications dépendantes séance→émargement→confirmation restent non exécutables actuellement. Aucun total6h/2h/4h ni statut confirmé/contesté validé. Les scénarios SIG non exécutés ne sont pas déclarés réussis ; le lot documente le blocage du parcours sans convertir en masse les751NOT_RUN en BLOCKED.
Connexion, déconnexion, retour arrière et reconnexion contrôlés ; sessions après refresh observées. Expiration naturelle JWT et comportement temps réel après expiration non exécutés. Négociations notifications200 observées après connexion, insuffisant pour prouver livraison ou gestion expiration. Pas de fuite inter-tenant démontrée dans les contextes consultés ; cela ne valide pas toute la matrice de permissions.
Historique neuf BLOCKED et troisN/A conservé : voir registre et références. Les autres menus, documents, jury, statistiques et les tickets historiques restants demandent de nouveaux lots indépendants ; aucune conclusion globale PASS.

## Prochaine reprise
Réutiliser ces données et tests : terminer configuration programmes des trois centres, obtenir une acceptation réelle des invitations et un responsable/formateur actif par UI, affecter les périmètres puis créer promotions et trois stagiaires ; poursuivre les47SIG-E2E et contrôler les totaux avec données produites. Une boîte de test accessible est indispensable aux tests de réception et liens. Continuer les tickets4,6–13 lorsque leurs préconditions et tenants d'origine sont accessibles.
**NO GO : parcours essentiel de confirmation non validé et anomalies ouvertes.** Les captures prouvent les états observés, sans preuve de livraison email. Les exports CC conservent les étapes et résultats des runs42–59 ; un seul nouveau test39, test10 enrichi, aucun doublon d'anomalie créé.
