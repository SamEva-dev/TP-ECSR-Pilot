# Suivi detaille — reprise 08/11/2026

## AUTH-UI-001 — Accès à la page de connexion

Verdict : PASS

Attendu et preconditions :
Priorité : P0   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : Visiteur déconnecté sur la page d’accueil.
Given  le navigateur ne possède aucune session PedagoraPilot active
When  je clique sur « Se connecter » ou son équivalent
Then  la page de connexion s’ouvre et permet de saisir les informations nécessaires
Résultat observable : Une interface lisible est affichée, sans page blanche ni erreur technique.

Observe : Racine staging redirigée /connexion ; champs et actions visibles. Onglet1 sans session métier active.

Test : test-29 ; anomalie : 

Preuves : Snapshot1 ; user01-contexte.png (preuve de contexte ultérieure)

## AUTH-UI-002 — Création du premier compte de référence

Verdict : PASS

Attendu et preconditions :
Priorité : P0   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : USER-01 absent et inscription ouverte.
Given  je suis un visiteur sans compte AuthGate
When  j’ouvre l’inscription et renseigne sam.user1@email.com avec Demo@123 et les champs requis
Then  je valide le formulaire
And  je poursuis sans consultation d’une boîte e-mail
Résultat observable : Le parcours confirme la prise en compte de l’inscription et permet de poursuivre vers connexion ou configuration initiale ; aucune confirmation e-mail n’est imposée en staging.
Point de vigilance : si l’interface demande de créer une organisation, saisir le nom fictif correspondant au compte (voir matrice de couverture), puis confirmer que cette organisation apparaît dans le Contexte de travail. Ne pas utiliser une organisation d’un autre propriétaire.

Observe : USER-01 absent selon orientation prelogin vers inscription ; formulaire organisation Centre Horizon ECSR, Sam Horizon QA ; retour registered=1 puis connexion réussie sans étape e-mail imposée.

Test : test-31 ; anomalie : 

Preuves : Snapshots6,8,12,13 ; user01-contexte.png

## AUTH-UI-003 — Création des trois autres comptes

Verdict : PASS

Attendu et preconditions :
Priorité : P0   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : USER-01 créé ; USER-02, USER-03 et USER-04 absents.
Given  je suis déconnecté
When  je répète le parcours d’inscription pour sam.user2@email.com, sam.user3@email.com puis sam.user4@email.com
Then  les trois parcours aboutissent sans validation d’e-mail
Résultat observable : Quatre identités distinctes ont été créées ; chaque compte peut être utilisé séparément.

Observe : Trois inscriptions UI USER-02/03/04 ; organisations Azur/Provence/Méditerranée ; chacune suivie d’une connexion puis reload ; aucune validation e-mail imposée.

Test : test-33 ; anomalie : 

Preuves : Snapshots17–38 ; user02-contexte.png ; user03-contexte.png ; user04-contexte.png

## AUTH-UI-004 — Connexion avec le premier compte

Verdict : PASS

Attendu et preconditions :
Priorité : P0   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : USER-01 inscrit et actif.
Given  j’affiche la page de connexion
When  je saisis sam.user1@email.com et Demo@123
And  je confirme la connexion
Then  l’application me redirige vers l’espace auquel mon compte est autorisé
Résultat observable : L’utilisateur accède à son espace ou, si aucun rattachement n’existe, à une étape explicite de rattachement ; aucune boucle infinie.

Observe : USER-01 connecté /accueil, Sam Horizon QA et Centre Horizon ECSR dans contexte ; reload conserve identité.

Test : test-31 ; anomalie : 

Preuves : Snapshots12–15 ; user01-contexte.png

## AUTH-UI-005 — Connexion avec les autres comptes

Verdict : PASS

Attendu et preconditions :
Priorité : P0   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : USER-02, USER-03 et USER-04 inscrits et actifs.
Given  je suis déconnecté
When  je me connecte successivement avec USER-02, USER-03 et USER-04
Then  chaque utilisateur obtient son propre espace ou une étape de configuration lisible
Résultat observable : Les identités ne sont pas mélangées ; aucun profil d’un autre compte n’apparaît.

Observe : USER-02 Sam Azur QA ; USER-03 Sam Provence QA ; USER-04 Sam Méditerranée QA. Chaque connexion/reload affiche sa seule organisation.

Test : test-33 ; anomalie : 

Preuves : Snapshots24,31,38 ; user02-contexte.png ; user03-contexte.png ; user04-contexte.png

## AUTH-UI-006 — Compte déjà existant — éviter la double inscription

Verdict : FAIL

Attendu et preconditions :
Priorité : P1   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : USER-01 créé.
Given  je suis déconnecté
When  je tente de m’inscrire de nouveau avec sam.user1@email.com
Then  l’interface signale que le compte existe ou m’oriente vers la connexion
Résultat observable : Aucune seconde identité n’est créée ; message compréhensible, sans divulgation de données privées.

Observe : Inscription du compte existant USER01 rejetée400 ; message trompeur authentication service temporarily unavailable persistant.

Test : test-34 ; anomalie : task-14

Preuves : retest-duplicate.png

## AUTH-UI-007 — E-mail connu dans AuthGate mais nouveau pour PedagoraPilot

Verdict : BLOCKED

Attendu et preconditions :
Priorité : P1   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : Préparer, si disponible, une identité AuthGate autorisée dans une autre application mais sans accès PedagoraPilot.
Given  mon adresse e-mail existe déjà dans AuthGate
And  je ne dispose pas encore d’accès PedagoraPilot
When  je tente d’accéder à PedagoraPilot par son interface
Then  l’interface me guide vers l’inscription partielle ou un rattachement autorisé
Résultat observable : Pas de création d’un deuxième mot de passe AuthGate ; parcours explicite et sans boucle.
Point de vigilance : Scénario conditionnel : bloqué si le prérequis inter-application ne peut pas être constitué depuis les UI autorisées.

Observe : Aucune identité AuthGate d’une autre application sans accès PedagoraPilot fournie. Le prérequis ne peut pas être constitué dans les UI autorisées examinées.

Test :  ; anomalie : 

Preuves : 

## AUTH-UI-008 — Retour après inscription partielle

Verdict : BLOCKED

Attendu et preconditions :
Priorité : P1   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : AUTH-UI-007 achevé si ce parcours est exposé.
Given  je dispose maintenant d’un accès PedagoraPilot
When  je me déconnecte puis me reconnecte
Then  je ne suis pas renvoyé vers une inscription partielle
Résultat observable : Connexion normale et continuité du compte.
4. Validations et erreurs utilisateur

Observe : Aucune identité AuthGate d’une autre application sans accès PedagoraPilot fournie. Le prérequis ne peut pas être constitué dans les UI autorisées examinées.

Test :  ; anomalie : 

Preuves : 

## AUTH-UI-009 — Champs obligatoires manquants

Verdict : PASS

Attendu et preconditions :
Priorité : P1   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : Page d’inscription accessible.
Given  le formulaire est ouvert
When  je soumets sans renseigner les champs obligatoires
Then  les champs concernés affichent une validation visible
Résultat observable : Pas d’inscription et message localisé, sans blocage du navigateur.

Observe : Soumission /register vide : six messages This field is required, champs invalid=true, aucune inscription.

Test : test-30 ; anomalie : 

Preuves : Snapshot3

## AUTH-UI-010 — Adresse e-mail mal formée

Verdict : PASS

Attendu et preconditions :
Priorité : P1   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : Page d’inscription ou de connexion accessible.
Given  je vois un champ e-mail
When  je saisis sam.user1-email.com
Then  l’interface refuse la valeur ou présente un message adapté
Résultat observable : L’erreur est claire ; aucune navigation inattendue.

Observe : sam.user1-email.com refusé dans /register : Enter a valid email address, aucune inscription.

Test : test-30 ; anomalie : 

Preuves : Snapshot4

## AUTH-UI-011 — Mot de passe incorrect

Verdict : PASS

Attendu et preconditions :
Priorité : P0   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : USER-01 actif.
Given  je suis sur la connexion
When  je saisis sam.user1@email.com et un mot de passe incorrect
Then  la connexion est refusée
Résultat observable : Message d’échec lisible, sans ouverture de session ni divulgation d’informations sensibles.

Observe : Une tentative USER-01 avec mauvais mot de passe refusée ; Invalid email address or password. Correction avec secret autorisé ouvre Sam Horizon QA.

Test : test-25 run35 ; anomalie : 

Preuves : Snapshots44–45 ; invalid-login.png

## AUTH-UI-012 — E-mail inconnu lors de la connexion

Verdict : PASS

Attendu et preconditions :
Priorité : P1   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : Aucun compte pour unknown.panda@example.com.
Given  je suis sur la connexion
When  je tente de me connecter avec unknown.panda@example.com
Then  la page m’informe de l’impossibilité de connexion ou me propose l’inscription
Résultat observable : Aucun accès accordé ; comportement cohérent avec le parcours d’identification de l’application.

Observe : unknown.panda@example.com mène /register avec email prérempli sans accès privé ; aucun compte créé.

Test : test-35 ; anomalie : 

Preuves : Snapshot49

## AUTH-UI-013 — Normalisation de l’adresse e-mail

Verdict : PASS

Attendu et preconditions :
Priorité : P2   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : USER-01 actif.
Given  j’affiche la connexion
When  je saisis SAM.USER1@EMAIL.COM, éventuellement avec des espaces en début/fin
Then  l’application traite l’adresse selon sa politique de normalisation
Résultat observable : Aucune identité distincte créée ; une éventuelle erreur de format est explicite.
Point de vigilance : Vérifier le comportement observé pour les espaces ; ne pas présupposer leur acceptation.
5. Sessions et navigation

Observe : Adresse USER-01 avec majuscules et espaces périphériques reconnue, connexion avec secret autorisé ouvre Sam Horizon QA.

Test : test-35 ; anomalie : 

Preuves : Snapshots51–52

## AUTH-UI-014 — Recharger une page authentifiée

Verdict : PASS

Attendu et preconditions :
Priorité : P0   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : USER-01 connecté.
Given  une page métier autorisée est affichée
When  je rafraîchis le navigateur
Then  la page demeure utilisable ou rétablit proprement la session
Résultat observable : Pas de page blanche, d’erreur infinie ni de changement de compte.

Observe : /acces actualisé reste sur compte USER-01 Sam Horizon QA, menus et données accessibles.

Test : test-4 run36 ; anomalie : 

Preuves : Snapshot46

## AUTH-UI-015 — Accès direct à une URL protégée hors connexion

Verdict : BLOCKED

Attendu et preconditions :
Priorité : P0   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : USER-01 déconnecté ; URL d’une page métier précédemment visitée.
Given  j’ouvre une fenêtre privée
When  je colle directement cette URL
Then  l’application demande la connexion
Résultat observable : Aucune donnée métier protégée n’apparaît avant authentification.

Observe : Variante même onglet exécutée : /acces après déconnexion redirige connexion sans données privées (snapshot47). Scénario exact exige fenêtre privée ; outil disponible et consigne onglet1 unique ne permettent pas ce prérequis.

Test : test-4 run36 ; anomalie : 

Preuves : Snapshot47

## AUTH-UI-016 — Déconnexion

Verdict : PASS

Attendu et preconditions :
Priorité : P0   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : USER-01 connecté.
Given  une session active est visible
When  je clique sur « Déconnexion »
Then  je reviens sur une page non authentifiée
And  je ne peux plus consulter directement une page protégée
Résultat observable : Session terminée et navigation cohérente.

Observe : Sign out retourne /connexion ; /acces direct redirige /connexion?returnUrl=%2Facces sans données privées.

Test : test-4 run36 ; anomalie : 

Preuves : Snapshots47–48

## AUTH-UI-017 — Retour arrière après déconnexion

Verdict : PASS

Attendu et preconditions :
Priorité : P1   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : AUTH-UI-016 effectué.
Given  je suis déconnecté
When  je clique sur le bouton « Précédent » du navigateur
Then  le contenu protégé n’est pas utilisable
Résultat observable : Les éventuelles pages en cache ne permettent aucune action authentifiée.

Observe : Après logout, retour navigateur puis URL /acces redirigent connexion ; aucune action protégée accessible.

Test : test-4 ; anomalie : 

Preuves : Snapshots127–129

## AUTH-UI-018 — Deux utilisateurs sur deux sessions distinctes

Verdict : BLOCKED

Attendu et preconditions :
Priorité : P0   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : USER-01 et USER-02 actifs.
Given  j’ouvre deux profils de navigateur indépendants
When  je me connecte avec USER-01 dans le premier et USER-02 dans le second
Then  chaque profil conserve sa propre identité
Résultat observable : Aucun mélange d’identité, de menu ou de données entre sessions.
6. Mot de passe et récupération

Observe : Deux profils de navigateur indépendants requis ; seuls onglet1 et session Chrome courante autorisés. Alternance séquentielle des 4 comptes effectuée, sans valider simultanéité.

Test :  ; anomalie : 

Preuves : 

## AUTH-UI-019 — Changement de mot de passe

Verdict : BLOCKED

Attendu et preconditions :
Priorité : P0   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : USER-01 connecté ; commande « Changer le mot de passe » disponible.
Given  je suis sur les paramètres de sécurité de mon compte
When  je renseigne le mot de passe actuel Demo@123
And  je saisis DemoDemo@123 en nouveau mot de passe et en confirmation
Then  je confirme la modification
And  je me déconnecte puis me reconnecte avec DemoDemo@123
Résultat observable : Le nouveau mot de passe permet la connexion et l’ancien ne la permet plus.
Point de vigilance : Si la commande n’existe pas en UI, noter « Non exposé » ; effectuer le scénario uniquement lorsque la longueur de DemoDemo@123 est acceptée par la politique affichée.

Observe : Aucune commande de changement de mot de passe actuel/nouveau dans navigation, profil affiché ou Administration > Security & retention examinés. Routes change-password/reset-password repérées dans code, mais pas parcours utilisateur actuel de changement exposé. Aucun mot de passe modifié.

Test :  ; anomalie : 

Preuves : Snapshots58–59

## AUTH-UI-020 — Confirmation du nouveau mot de passe différente

Verdict : BLOCKED

Attendu et preconditions :
Priorité : P1   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : USER-01 connecté, formulaire de changement disponible.
Given  je saisis Demo@123 comme mot de passe actuel
When  je saisis DemoDemo@123 puis une confirmation différente
Then  la validation est refusée
Résultat observable : Un message explique la discordance et le mot de passe initial reste fonctionnel.

Observe : Aucune commande de changement de mot de passe actuel/nouveau dans navigation, profil affiché ou Administration > Security & retention examinés. Routes change-password/reset-password repérées dans code, mais pas parcours utilisateur actuel de changement exposé. Aucun mot de passe modifié.

Test :  ; anomalie : 

Preuves : Snapshots58–59

## AUTH-UI-021 — Ancien mot de passe erroné

Verdict : BLOCKED

Attendu et preconditions :
Priorité : P1   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : USER-01 connecté, formulaire de changement disponible.
Given  je suis dans le formulaire de changement
When  je saisis un ancien mot de passe erroné et DemoDemo@123 comme nouveau
Then  la modification est refusée
Résultat observable : Demo@123 reste valide ; aucun changement silencieux.

Observe : Aucune commande de changement de mot de passe actuel/nouveau dans navigation, profil affiché ou Administration > Security & retention examinés. Routes change-password/reset-password repérées dans code, mais pas parcours utilisateur actuel de changement exposé. Aucun mot de passe modifié.

Test :  ; anomalie : 

Preuves : Snapshots58–59

## AUTH-UI-022 — Réinitialiser le mot de passe pour la suite

Verdict : BLOCKED

Attendu et preconditions :
Priorité : P0   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : AUTH-UI-019 réussi ; USER-01 utilise DemoDemo@123.
Given  je suis connecté avec le mot de passe modifié
When  je remplace DemoDemo@123 par Demo@123 via l’UI
Then  je peux me reconnecter avec Demo@123
Résultat observable : USER-01 revient à son état initial ; le nouveau mot de passe temporaire n’est plus valide.
Point de vigilance : Si une règle de longueur interdit Demo@123, consigner le blocage : ne pas prétendre que les quatre comptes ont été réinitialisés.

Observe : Aucune commande de changement de mot de passe actuel/nouveau dans navigation, profil affiché ou Administration > Security & retention examinés. Routes change-password/reset-password repérées dans code, mais pas parcours utilisateur actuel de changement exposé. Aucun mot de passe modifié.

Test :  ; anomalie : 

Preuves : Snapshots58–59

## AUTH-UI-023 — Mot de passe oublié — déclenchement

Verdict : PASS

Attendu et preconditions :
Priorité : P1   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : USER-02 actif ; lien « Mot de passe oublié » présent.
Given  je suis sur la page de connexion
When  je clique sur « Mot de passe oublié »
And  je renseigne sam.user2@email.com et confirme
Then  l’interface indique comment poursuivre
Résultat observable : Message non trompeur. Ne pas affirmer que l’e-mail est reçu sans boîte de réception accessible.
Point de vigilance : Ne pas changer le mot de passe de USER-02 sans moyen fiable de restauration ; marquer la finalisation du lien comme non exécutable si nécessaire.
7. SSO OIDC et parcours conditionnels

Observe : USER02 : /reset-password?email prérempli ; soumission200 et message conditionnel exact. Aucune réception ni finalisation du lien validée.

Test : test-37 ; anomalie : task-16

Preuves : retest-reset-prefill.png; retest-reset-result.png

## AUTH-UI-024 — Connexion SSO depuis PedagoraPilot

Verdict : NOT_APPLICABLE

Attendu et preconditions :
Priorité : P0   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : Le mode OIDC est actif sur staging.
Given  je suis déconnecté de PedagoraPilot
When  je lance la connexion
And  je m’authentifie sur la page AuthGate affichée
Then  je reviens automatiquement dans PedagoraPilot
Résultat observable : Pas de boucle d’authentification ni d’écran callback figé ; identité correcte affichée.

Observe : Mode legacy exposé ; configuration locale staging authMode legacy, bouton OIDC explicitement réservé à validation sans accès métier. Précondition OIDC actif non remplie. Ne valide pas le fonctionnement OIDC.

Test :  ; anomalie : 

Preuves : environment.staging.ts ; snapshots1,62

## AUTH-UI-025 — Abandon de la connexion SSO

Verdict : NOT_APPLICABLE

Attendu et preconditions :
Priorité : P1   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : Le mode OIDC est actif et la page AuthGate est ouverte.
Given  le parcours OIDC est en cours
When  je l’annule ou reviens à PedagoraPilot sans le terminer
Then  je reste non connecté ou retrouve un écran de connexion valide
Résultat observable : Aucune session métier créée par erreur.

Observe : Mode legacy exposé ; configuration locale staging authMode legacy, bouton OIDC explicitement réservé à validation sans accès métier. Précondition OIDC actif non remplie. Ne valide pas le fonctionnement OIDC.

Test :  ; anomalie : 

Preuves : environment.staging.ts ; snapshots1,62

## AUTH-UI-026 — Connexion SSO avec session AuthGate existante

Verdict : NOT_APPLICABLE

Attendu et preconditions :
Priorité : P1   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : OIDC actif ; une session AuthGate existe et l’utilisateur est autorisé dans PedagoraPilot.
Given  je suis connecté à AuthGate via une application autorisée
When  j’accède à PedagoraPilot et demande la connexion
Then  je poursuis selon le SSO proposé par AuthGate
Résultat observable : Le bon compte est reconnu et l’application cible vérifie son accès ; ne pas imposer une ressaisie inutile si la session est reconnue.
8. Campagne 02 — Contexte de travail et état initial des menus
Objet : exécuter TOUS les scénarios de cette campagne successivement avec USER-01, USER-02, USER-03 et USER-04. Après chacune des quatre connexions, le Contexte de travail affiche l’organisation propre au compte ; établissements, formations, promotions, stagiaires, planning et statistiques métier restent initialement vides.
Préconditions : staging sans données métier pour les quatre organisations ; compte ciblé connecté au rôle Direction / Responsable pédagogique dans SON organisation uniquement.
Règle générale : « vide » désigne zéro enregistrement métier (stagiaire, promotion, séance, etc.), et non une page blanche. Les titres, colonnes, filtres, boutons, catégories et messages d’état vide doivent rester visibles. Une absence de données doit produire 0, une liste vide ou un état vide lisible, jamais un faux enregistrement.

Observe : Mode legacy exposé ; configuration locale staging authMode legacy, bouton OIDC explicitement réservé à validation sans accès métier. Précondition OIDC actif non remplie. Ne valide pas le fonctionnement OIDC.

Test :  ; anomalie : 

Preuves : environment.staging.ts ; snapshots1,62

## CTX-UI-001 — Contexte de travail : organisation disponible

Verdict : PASS

Attendu et preconditions :
Priorité : P0   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : USER-01 connecté et organisation de rattachement existante.
Given  je suis connecté avec le rôle Direction / Responsable pédagogique
When  j’ouvre le sélecteur « Contexte de travail »
Then  je vois au moins une organisation correspondant à mon rattachement autorisé
Résultat observable : L’organisation est nommée, sélectionnable et aucune organisation étrangère n’est affichée. En cas d’absence d’organisation, signaler une anomalie de précondition/rattachement, sans inventer une valeur.

Observe : Contexte USER-01 propose uniquement Centre Horizon ECSR ; organisation nommée et sélectionnable.

Test : test-32 ; anomalie : 

Preuves : Snapshots13,15 ; user01-contexte.png

## CTX-UI-002 — Contexte de travail : listes métier vides

Verdict : PASS

Attendu et preconditions :
Priorité : P1   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : Une organisation existe, aucun site/formation/promotion métier n’a été créé.
Given  le contexte de travail affiche mon organisation
When  j’inspecte les sélecteurs dépendants sans créer de donnée
Then  aucun établissement, formation ou promotion fictif ne m’est proposé
Résultat observable : Les champs dépendants sont vides, désactivés ou présentent une invite explicite ; aucune sélection fantôme. Les éventuels catalogues système sont distingués des instances métier.

Observe : Colonnes Site/Training/Cohort vides avant toute création métier ; aucune valeur fantôme.

Test : test-32 ; anomalie : 

Preuves : Snapshots13,15 ; user01-contexte.png

## CTX-UI-003 — Contexte de travail : conservation et rafraîchissement

Verdict : PASS

Attendu et preconditions :
Priorité : P1   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : USER-01 connecté, organisation autorisée sélectionnée.
Given  une organisation autorisée est affichée dans le contexte de travail
When  je recharge la page
Then  le contexte demeure cohérent et ne bascule pas vers une autre organisation
Résultat observable : L’organisation autorisée est rétablie ou redemandée explicitement ; aucune erreur de chargement ni données d’un autre tenant.

Observe : Après reload et réouverture contexte : Centre Horizon ECSR et Sam Horizon QA conservés.

Test : test-32 ; anomalie : 

Preuves : Snapshot15

## MENU-UI-001 — Accueil : structure visible et données initiales vides

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : USER-01 connecté en Direction / Responsable pédagogique ; aucune donnée métier créée.
Given  le menu Accueil est visible dans la navigation
When  je clique sur « Accueil » et j’inspecte son contenu initial
Then  la page s’ouvre avec ses composants attendus, sans enregistrements métier préexistants
Résultat observable : Éléments à vérifier : indicateurs stagiaires, formateurs, présence, heures, progression, fiches ; sections progression, heures, alertes et stagiaires à surveiller. Attendu : tous les compteurs métier sont à 0 ou dans un état neutre et les listes/alertes sont vides ; actions de navigation restent visibles. Aucun écran blanc, message de succès fictif ou erreur silencieuse.

Observe : 

Test :  ; anomalie : 

Preuves : 

## MENU-UI-002 — Planning : structure visible et données initiales vides

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : USER-01 connecté en Direction / Responsable pédagogique ; aucune donnée métier créée.
Given  le menu Planning est visible dans la navigation
When  je clique sur « Planning » et j’inspecte son contenu initial
Then  la page s’ouvre avec ses composants attendus, sans enregistrements métier préexistants
Résultat observable : Éléments à vérifier : calendrier Jour/Semaine/Mois, filtres par promotion/type, séances en salle et en conduite, action Ajouter au planning. Attendu : aucune séance ni événement métier dans le calendrier ; navigation entre vues sans apparition de données fictives. Aucun écran blanc, message de succès fictif ou erreur silencieuse.

Observe : 

Test :  ; anomalie : 

Preuves : 

## MENU-UI-003 — Stagiaires : structure visible et données initiales vides

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : USER-01 connecté en Direction / Responsable pédagogique ; aucune donnée métier créée.
Given  le menu Stagiaires est visible dans la navigation
When  je clique sur « Stagiaires » et j’inspecte son contenu initial
Then  la page s’ouvre avec ses composants attendus, sans enregistrements métier préexistants
Résultat observable : Éléments à vérifier : liste, recherche, filtres, action Ajouter un stagiaire. Attendu : liste vide et compteur à 0 ; recherche/filtres utilisables, aucun dossier fictif. Aucun écran blanc, message de succès fictif ou erreur silencieuse.

Observe : 

Test :  ; anomalie : 

Preuves : 

## MENU-UI-004 — Promotions : structure visible et données initiales vides

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : USER-01 connecté en Direction / Responsable pédagogique ; aucune donnée métier créée.
Given  le menu Promotions est visible dans la navigation
When  je clique sur « Promotions » et j’inspecte son contenu initial
Then  la page s’ouvre avec ses composants attendus, sans enregistrements métier préexistants
Résultat observable : Éléments à vérifier : liste des promotions, équipe pédagogique, action Créer une promotion. Attendu : aucune promotion enregistrée ; pas de formateur ou de responsable inventé dans la liste métier. Aucun écran blanc, message de succès fictif ou erreur silencieuse.

Observe : 

Test :  ; anomalie : 

Preuves : 

## MENU-UI-005 — Séances : structure visible et données initiales vides

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : USER-01 connecté en Direction / Responsable pédagogique ; aucune donnée métier créée.
Given  le menu Séances est visible dans la navigation
When  je clique sur « Séances » et j’inspecte son contenu initial
Then  la page s’ouvre avec ses composants attendus, sans enregistrements métier préexistants
Résultat observable : Éléments à vérifier : création de séance pédagogique, séances programmées, action Créer puis faire l’appel. Attendu : aucune séance programmée ; pas d’appel ni de séance fictive. Aucun écran blanc, message de succès fictif ou erreur silencieuse.

Observe : 

Test :  ; anomalie : 

Preuves : 

## MENU-UI-006 — Conduite : structure visible et données initiales vides

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : USER-01 connecté en Direction / Responsable pédagogique ; aucune donnée métier créée.
Given  le menu Conduite est visible dans la navigation
When  je clique sur « Conduite » et j’inspecte son contenu initial
Then  la page s’ouvre avec ses composants attendus, sans enregistrements métier préexistants
Résultat observable : Éléments à vérifier : informations de séance, dernière séance, grille d’évaluation, observations, historique. Attendu : aucune séance de conduite ni historique ; les contrôles dépendants d’un stagiaire/séance ne doivent pas simuler un dossier. Aucun écran blanc, message de succès fictif ou erreur silencieuse.

Observe : 

Test :  ; anomalie : 

Preuves : 

## MENU-UI-007 — Fiches / Exposés : structure visible et données initiales vides

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : USER-01 connecté en Direction / Responsable pédagogique ; aucune donnée métier créée.
Given  le menu Fiches / Exposés est visible dans la navigation
When  je clique sur « Fiches / Exposés » et j’inspecte son contenu initial
Then  la page s’ouvre avec ses composants attendus, sans enregistrements métier préexistants
Résultat observable : Éléments à vérifier : indicateurs Préparées/Présentées/Validées/À retravailler, suivi et action Évaluer un exposé. Attendu : aucune préparation, présentation ou évaluation de stagiaire ; les 58 fiches de référence peuvent être listées comme catalogue, sans progression fictive. Aucun écran blanc, message de succès fictif ou erreur silencieuse.

Observe : 

Test :  ; anomalie : 

Preuves : 

## MENU-UI-008 — Compétences : structure visible et données initiales vides

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : USER-01 connecté en Direction / Responsable pédagogique ; aucune donnée métier créée.
Given  le menu Compétences est visible dans la navigation
When  je clique sur « Compétences » et j’inspecte son contenu initial
Then  la page s’ouvre avec ses composants attendus, sans enregistrements métier préexistants
Résultat observable : Éléments à vérifier : référentiel de compétences, progression par promotion/stagiaire, séances liées. Attendu : référentiel système éventuellement visible, mais aucune progression, acquisition ou séance liée préremplie. Aucun écran blanc, message de succès fictif ou erreur silencieuse.

Observe : 

Test :  ; anomalie : 

Preuves : 

## MENU-UI-009 — Présences : structure visible et données initiales vides

Verdict : PASS

Attendu et preconditions :
Priorité : P1   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : USER-01 connecté en Direction / Responsable pédagogique ; aucune donnée métier créée.
Given  le menu Présences est visible dans la navigation
When  je clique sur « Présences » et j’inspecte son contenu initial
Then  la page s’ouvre avec ses composants attendus, sans enregistrements métier préexistants
Résultat observable : Éléments à vérifier : appel d’une séance, états Présents/Retards/Absents/Heures manquées, motifs. Attendu : aucune feuille d’appel ni présence ; tous les indicateurs métier à 0. Aucun écran blanc, message de succès fictif ou erreur silencieuse.

Observe : Quatre comptes reconnectés séparément, propre organisation ; structure Présences visible, compteurs0, including 0 excused, sauvegarde désactivée ; aucune présence.

Test : test-38 ; anomalie : task-17

Preuves : presence-user1.png; presence-user2.png; presence-user3.png; presence-user4.png

## MENU-UI-010 — Stages : structure visible et données initiales vides

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : USER-01 connecté en Direction / Responsable pédagogique ; aucune donnée métier créée.
Given  le menu Stages est visible dans la navigation
When  je clique sur « Stages » et j’inspecte son contenu initial
Then  la page s’ouvre avec ses composants attendus, sans enregistrements métier préexistants
Résultat observable : Éléments à vérifier : périodes de stage, heures prévues/réalisées/restantes, stages incomplets, Nouvelle période de stage. Attendu : aucune période ni affectation ; heures et alertes sans données métier à 0 ou neutres. Aucun écran blanc, message de succès fictif ou erreur silencieuse.

Observe : 

Test :  ; anomalie : 

Preuves : 

## MENU-UI-011 — Documents : structure visible et données initiales vides

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : USER-01 connecté en Direction / Responsable pédagogique ; aucune donnée métier créée.
Given  le menu Documents est visible dans la navigation
When  je clique sur « Documents » et j’inspecte son contenu initial
Then  la page s’ouvre avec ses composants attendus, sans enregistrements métier préexistants
Résultat observable : Éléments à vérifier : bibliothèque, recherche, catégories, Importer/Aperçu/Télécharger. Attendu : aucun document métier importé ; catégories et modèles système peuvent exister sans être considérés comme des documents déposés. Aucun écran blanc, message de succès fictif ou erreur silencieuse.

Observe : 

Test :  ; anomalie : 

Preuves : 

## MENU-UI-012 — Rapports : structure visible et données initiales vides

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : USER-01 connecté en Direction / Responsable pédagogique ; aucune donnée métier créée.
Given  le menu Rapports est visible dans la navigation
When  je clique sur « Rapports » et j’inspecte son contenu initial
Then  la page s’ouvre avec ses composants attendus, sans enregistrements métier préexistants
Résultat observable : Éléments à vérifier : paramètres de rapport, heures, absences, compétences, stages, modifications ; Exporter PDF/Excel/Imprimer. Attendu : aucune donnée dans les rapports ; exports désactivés ou rapport vide clairement identifié, jamais de lignes fictives. Aucun écran blanc, message de succès fictif ou erreur silencieuse.

Observe : 

Test :  ; anomalie : 

Preuves : 

## MENU-UI-013 — Statistiques : structure visible et données initiales vides

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : USER-01 connecté en Direction / Responsable pédagogique ; aucune donnée métier créée.
Given  le menu Statistiques est visible dans la navigation
When  je clique sur « Statistiques » et j’inspecte son contenu initial
Then  la page s’ouvre avec ses composants attendus, sans enregistrements métier préexistants
Résultat observable : Éléments à vérifier : indicateurs consolidés, graphiques par promotion et compétence, fiches, répartitions, classements. Attendu : graphiques vides ou état vide explicite ; compteurs à 0, aucun classement inventé. Aucun écran blanc, message de succès fictif ou erreur silencieuse.

Observe : 

Test :  ; anomalie : 

Preuves : 

## MENU-UI-014 — Gestion des accès : structure visible et données initiales vides

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : USER-01 connecté en Direction / Responsable pédagogique ; aucune donnée métier créée.
Given  le menu Gestion des accès est visible dans la navigation
When  je clique sur « Gestion des accès » et j’inspecte son contenu initial
Then  la page s’ouvre avec ses composants attendus, sans enregistrements métier préexistants
Résultat observable : Éléments à vérifier : comptes, accès actifs, invitations, suspensions, recherche, Inviter/Activer/Suspendre/Révoquer. Attendu : aucun utilisateur métier supplémentaire ni invitation fictive ; le compte connecté et ses accès techniques réels peuvent être visibles. Aucun écran blanc, message de succès fictif ou erreur silencieuse.

Observe : 

Test :  ; anomalie : 

Preuves : 

## MENU-UI-015 — Administration : structure visible et données initiales vides

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : USER-01 connecté en Direction / Responsable pédagogique ; aucune donnée métier créée.
Given  le menu Administration est visible dans la navigation
When  je clique sur « Administration » et j’inspecte son contenu initial
Then  la page s’ouvre avec ses composants attendus, sans enregistrements métier préexistants
Résultat observable : Éléments à vérifier : informations du centre, utilisateurs, référentiels, catégories d’heures, fiches, droits, dernières actions. Attendu : aucune configuration métier créée artificiellement ; les données d’organisation et les catalogues/permissions système nécessaires restent affichables ; journal sans actions métier fictives. Aucun écran blanc, message de succès fictif ou erreur silencieuse.

Observe : 

Test :  ; anomalie : 

Preuves : 

## MENU-UI-016 — Navigation complète : cohérence des états vides

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : Aucune création métier durant les 15 visites.
Given  je suis dans une organisation autorisée avec les 15 menus disponibles
When  je parcours les 15 menus puis reviens à l’Accueil et rafraîchis la page
Then  les mêmes états vides persistent et aucune donnée métier n’est apparue spontanément
Résultat observable : Une navigation seule ne crée rien ; listes et compteurs cohérents sur l’ensemble des menus.
Consigne PANDA : pour chaque test, conserver une capture de la page ouverte, noter l’intitulé exact du menu, relever les composants absents ou supplémentaires et qualifier le résultat : Réussi / Échoué / Bloqué / Non exposé. Si une donnée métier est déjà présente, relever son origine si visible et signaler le prérequis non satisfait avant de poursuivre.
9. Campagne 03 — Pilotage organisation : état initial
Objectif : vérifier ce que voit la Direction avant toute création métier. Les intitulés sont des points de contrôle issus de la cartographie fonctionnelle ; le testeur relève les libellés exacts de la version déployée. Aucun contrôle de base de données ni appel API manuel : preuves uniquement via l’interface.
Ordre impératif : exécuter les vérifications initiales sur les QUATRE organisations avant la configuration progressive. Exécuter d’abord avec USER-01 puis répéter avec les trois autres comptes.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ORG-INIT-001 — Accéder au menu Pilotage organisation

Verdict : PASS

Attendu et preconditions :
Priorité : P0   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : USER-01 connecté ; organisation visible dans Contexte de travail.
Given  je suis sur un écran accessible au rôle Direction / Responsable pédagogique
When  je clique sur « Pilotage organisation »
Then  la page s’ouvre sans erreur ni redirection injustifiée
Then  le titre, les rubriques et les actions du pilotage sont visibles
Résultat observable : Menu ouvrable ; aucun écran blanc, chargement infini ou erreur technique.
Contrôle du Contexte de travail : L’organisation initiale reste présente et sélectionnée ; aucun site, formation ou promotion inventé.

Observe : Organization overview s’ouvre /organisation avec Centre Horizon ECSR, rubriques et assistant.

Test : test-36 ; anomalie : 

Preuves : Snapshot53 ; horizon-pilotage-initial.png

## ORG-INIT-002 — Assistant « Configurer votre organisation »

Verdict : PASS

Attendu et preconditions :
Priorité : P0   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : Aucune donnée métier créée.
Given  je consulte le menu Pilotage organisation
When  je développe l’assistant de configuration si nécessaire
Then  les sept étapes Responsables et accès, Établissements, Formations, Référentiels, Promotions, Stagiaires et Planning sont identifiables
Then  les actions de navigation de chaque étape sont visibles ou leur indisponibilité est expliquée
Résultat observable : Sept étapes dans un ordre intelligible ; leurs états ne doivent pas être marqués terminés à tort.
Contrôle du Contexte de travail : L’organisation existe toujours ; les quatre sélecteurs ne présentent aucune valeur métier fictive.
Consigne PANDA : Noter l’état exact de chaque étape ; « À vérifier » peut apparaître pour certaines étapes, ce n’est pas une preuve de complétion.

Observe : Sept étapes ; Managers/Learners/Schedule Verify ; sites/formations/référentiels/promotions To set up ; 0 of 4 verified prerequisites.

Test : test-36 ; anomalie : 

Preuves : Snapshot53 ; horizon-pilotage-initial.png

## ORG-INIT-003 — Indicateurs et listes à zéro

Verdict : FAIL

Attendu et preconditions :
Priorité : P0   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : Organisation neuve sans données métier.
Given  j’affiche le tableau de bord organisation
When  je lis les six indicateurs et les sections de performance
Then  Établissements, Formations actives, Stagiaires, Formateurs et Promotions actives sont à zéro
Then  la réussite certification n’affiche pas de réussite fictive
Then  les performances par site/formation, alertes et activité métier ne contiennent aucune donnée inventée
Résultat observable : Les conteneurs restent visibles ; états vides explicites, sans données factices. Une valeur « — » est acceptable pour un ratio non calculable.
Contrôle du Contexte de travail : Organisation sélectionnée ; aucun établissement / formation / promotion sélectionné.

Observe : Avant création métier Horizon : indicateurs0 sans valeurs fictives mais sections performance/alertes/activité restent sans message explicite.

Test : test-36 ; anomalie : task-15

Preuves : retest-pilotage.png

## ORG-INIT-004 — Navigation depuis les étapes et retour

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : Aucune donnée métier créée.
Given  l’assistant de configuration est visible
When  je clique sur « Ouvrir » pour chaque étape disponible puis reviens au pilotage
Then  chaque action ouvre l’écran correspondant ou informe clairement d’un prérequis
Then  aucune navigation seule ne crée d’enregistrement
Résultat observable : Liens valides, retour possible, pas de page blanche ni de création silencieuse.
Contrôle du Contexte de travail : Toujours une organisation ; aucune donnée métier apparue après navigation.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ORG-INIT-005 — Blocage de création établissement sans responsable

Verdict : BLOCKED

Attendu et preconditions :
Priorité : P0   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : Aucun responsable métier affecté à l’organisation.
Given  l’organisation est créée mais la liste de responsables éligibles est vide
When  j’ouvre la création d’établissement depuis Pilotage organisation
When  je consulte le champ « Responsable » puis tente de valider le formulaire avec les autres champs requis
Then  aucun responsable fictif ou appartenant à une autre organisation n’est proposé
Then  l’interface m’oriente vers la création ou l’affectation préalable d’un responsable, ou empêche une sauvegarde incohérente
Then  aucun établissement n’est ajouté
Résultat observable : Blocage compréhensible ; pas de succès trompeur, pas de responsable arbitraire.
Contrôle du Contexte de travail : Organisation présente ; établissements toujours vides.
Consigne PANDA : Ne pas imposer un texte d’erreur mot pour mot : relever le libellé réel et vérifier qu’il explique le prérequis.

Observe : Prérequis liste de responsables éligibles vide non rempli : Sam Horizon QA propriétaire est proposé dans Site manager. Formulaire annulé sans création ; aucune personne supprimée pour forcer état.

Test :  ; anomalie : 

Preuves : Snapshot55

## ORG-INIT-006 — Préconditions des formations et référentiels vides

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : Aucun établissement, aucune formation ni référentiel métier.
Given  je peux accéder aux écrans de création depuis l’assistant
When  j’ouvre successivement la création de formation puis de référentiel
Then  les listes de sites/formations ne contiennent aucune entrée métier fictive
Then  l’application empêche de finaliser une création nécessitant un site ou une formation absent
Then  les dépendances manquantes sont expliquées
Résultat observable : Impossible de rattacher des entités à une donnée inexistante.
Contrôle du Contexte de travail : Aucune nouvelle valeur proposée dans les sélecteurs de site et formation.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ORG-INIT-007 — Préconditions des promotions, stagiaires et planning

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0   •   Type : IHM / E2E   •   Statut : À exécuter
Préconditions : Aucune formation, aucun référentiel, aucune promotion ni formateur affecté.
Given  je suis sur l’organisation neuve
When  j’ouvre les parcours de création promotion, affectation stagiaire et séance
Then  aucune promotion, version de référentiel ou personne fictive n’est présélectionnée
Then  les actions dépendantes sont bloquées ou expliquées lorsque les prérequis sont absents
Then  aucun succès n’est affiché sans création réelle
Résultat observable : Les champs dépendants sont vides ou désactivés avec message ; aucune donnée métier créée.
Contrôle du Contexte de travail : Organisation unique ; site, formation et promotion vides.
10. Campagne 04 — Configuration progressive : quatre centres autonomes
Principe : aucun compte propriétaire d’un centre ne doit être utilisé comme responsable, formateur ou stagiaire d’un autre centre. Chaque propriétaire crée et pilote uniquement SA structure. Les personnels métiers éventuellement nécessaires sont ajoutés via l’interface de leur centre, avec des identités de test distinctes. Les quatre comptes propriétaires sont conservés dans tous les cas.
Ordre de test par centre : responsable éligible → établissement → formation → référentiel/version → promotion → stagiaire(s) → formateur et planning. Après CHAQUE création, modification ou affectation : vérifier le menu concerné, revenir à « Contexte de travail », contrôler les sélecteurs disponibles, rafraîchir la page et vérifier que la donnée persiste. Ensuite, consulter le tableau de bord « Pilotage organisation ».
Lorsque le produit ne permet pas de saisir des compétences propres au DEA, aux deux-roues ou au groupe lourd, PANDA doit signaler l’écart fonctionnel. Il ne doit pas utiliser des compétences ECSR voiture pour faire passer artificiellement un scénario.
10.1. Identités propriétaires et jeux de données cibles
Compte / centre
Formation principale et source
Promotion cible
USER-01 — Centre Horizon ECSR
TP Enseignant de la conduite et de la sécurité routièreRNCP41862 – CCP1 + CCP2
ECSR 2027 – session A
USER-02 — Académie Azur Deux-Roues
CCS Enseignement deux-rouesRNCP41862 – bloc CCS deux-roues BC03
Moto 2027 – session A
USER-03 — Institut Provence Poids Lourds
CCS Enseignement groupe lourdRNCP41862 – bloc CCS groupe lourd BC04
Groupe lourd 2027 – session A
USER-04 — Institut Méditerranée Ambulancier
Diplôme d’État d’ambulancier (DEA)Arrêté du 11 avril 2022 – référentiel DEA
DEA 2027 – session A
Référentiels et exemples de contenu : auto — préparation de séance, pédagogie en salle, conduite B, évaluation et sensibilisation ; moto — conduite hors circulation, conduite en circulation, spécificités deux-roues ; poids lourds — manœuvres hors circulation, conduite en circulation, spécificités des véhicules lourds ; ambulancier — prise en soin et surveillance, gestes d’urgence, transport sanitaire, hygiène, communication professionnelle et stages. Ce sont des intitulés réalistes pour tester les champs, non un référentiel exhaustif.
Sources des contenus métier : France compétences RNCP41862 (TP ECSR et CCS deux-roues/groupe lourd) : https://www.francecompetences.fr/recherche/rncp/41862 ; arrêté du 11 avril 2022 relatif au DEA, article 17 (801 h : 556 h d’enseignement et 245 h en milieu professionnel) : https://www.legifrance.gouv.fr/loda/article_lc/LEGIARTI000045598913 . Les établissements et promotions de recette ne sont pas des organismes agréés réels.
10.2. Règles communes à appliquer à chacun des quatre centres

Observe : 

Test :  ; anomalie : 

Preuves : 

## ORG-COM-001 — Vérifier le blocage sans responsable

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0   •   Type : parcours utilisateur / UI   •   Statut : À exécuter
Préconditions : Connexion avec l’un des USER-01 à USER-04 ; aucun responsable de centre actif.
Given  je suis sur « Pilotage organisation » de mon propre centre
And  aucun responsable pédagogique éligible n’existe dans la structure
When  j’ouvre la création d’établissement et examine le champ responsable
And  je tente d’enregistrer sans responsable si le formulaire l’autorise
Then  aucun responsable inventé ni appartenant à un autre centre n’est proposé
And  la création incohérente est refusée avec une explication compréhensible
Résultat observable / preuve : Capture du message de blocage ; aucune nouvelle fiche établissement ne doit apparaître.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ORG-COM-002 — Créer ou affecter un responsable propre au centre

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0   •   Type : parcours utilisateur / UI   •   Statut : À exécuter
Préconditions : Un des quatre comptes est connecté comme Direction ; aucun responsable éligible préexistant.
Given  le centre est identifié dans le Contexte de travail
When  j’ouvre « Responsables et accès » puis crée/invite/affecte un responsable pédagogique du même centre
And  je termine l’acceptation éventuelle par les écrans disponibles
Then  le responsable existe avec un état cohérent : invité, actif ou en attente
And  seul un responsable ACTIF et éligible est proposé lors de la création d’établissement
Résultat observable / preuve : Ne pas réutiliser USER-02/03/04 pour USER-01 ni aucun autre propriétaire inter-centres. Si le compte Direction peut être responsable, tester ce chemin ; sinon utiliser une identité additionnelle de recette propre au centre.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ORG-COM-003 — Établissement : créer et vérifier le contexte

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0   •   Type : parcours utilisateur / UI   •   Statut : À exécuter
Préconditions : Responsable propre au centre activé.
Given  le bon centre apparaît dans Contexte de travail
And  la liste établissements est encore vide
When  je crée son établissement avec le responsable éligible et le nom du site cible
And  je reviens au Contexte de travail
Then  l’établissement apparaît uniquement sous l’organisation courante
And  l’étape Établissements passe à l’état cohérent
And  le site reste visible après actualisation
Résultat observable / preuve : Capturer avant/après et comparer l’intitulé du site.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ORG-COM-004 — Formation : rattachement au bon établissement

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0   •   Type : parcours utilisateur / UI   •   Statut : À exécuter
Préconditions : Établissement du centre créé.
Given  je suis sur le bon établissement
When  je crée la formation cible du centre
And  je vérifie son rattachement et reviens au Contexte de travail
Then  la formation est proposée sous le site correct
And  aucune formation d’un autre centre n’est proposée
And  la donnée persiste après actualisation
Résultat observable / preuve : Vérifier notamment le type de certification réel et ses champs disponibles.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ORG-COM-005 — Référentiel : création conditionnée par la formation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0   •   Type : parcours utilisateur / UI   •   Statut : À exécuter
Préconditions : Formation cible existante dans le centre.
Given  la formation est disponible dans son établissement
When  je crée une version de référentiel et renseigne les compétences propres au domaine
And  je consulte le sélecteur Formation et le champ Version source
Then  la formation cible et la version sont disponibles
And  le référentiel apparaît seulement dans le périmètre du centre
And  le référentiel persiste après rechargement
Résultat observable / preuve : Si un référentiel officiel est déjà dans le catalogue système, l’associer sans créer de faux doublon réglementaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ORG-COM-006 — Promotion : version et responsable cohérents

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0   •   Type : parcours utilisateur / UI   •   Statut : À exécuter
Préconditions : Formation, version de référentiel et responsable valides.
Given  je suis dans la bonne formation
When  je crée la promotion cible avec sa version de référentiel et le responsable éligible
And  je contrôle le Contexte de travail
Then  la promotion apparaît sous la formation et le site prévus
And  l’indicateur promotions est actualisé
And  la version et le responsable affichés correspondent à mes choix
Résultat observable / preuve : Vérifier qu’une création de promotion ne modifie pas le responsable global de formation.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ORG-COM-007 — Stagiaire : inscription avec identité de test propre au centre

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1   •   Type : parcours utilisateur / UI   •   Statut : À exécuter
Préconditions : Promotion du centre créée.
Given  la promotion cible existe
When  je crée un stagiaire fictif via l’interface selon les champs réels
And  je le rattache à la promotion et rouvre son dossier
Then  le dossier est accessible et contient la bonne formation
And  l’effectif est actualisé
And  le contexte conserve le bon site, la bonne formation et la bonne promotion
Résultat observable / preuve : Créer des données de personne fictives mais plausibles, ne pas utiliser les quatre comptes Direction comme stagiaires.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ORG-COM-008 — Planning : dépendances formateur et promotion

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1   •   Type : parcours utilisateur / UI   •   Statut : À exécuter
Préconditions : Promotion créée ; personnel formateur propre au centre actif.
Given  les sélecteurs formateur et promotion doivent être alimentés par les données du centre
When  je crée une séance cohérente avec la spécialité du centre
And  je rouvre le planning et le Contexte de travail
Then  la séance apparaît dans son calendrier et sa promotion
And  la séance n’apparaît dans aucun autre centre
And  la donnée persiste après actualisation
Résultat observable / preuve : Refuser toute sélection de formateur appartenant à une autre organisation.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ORG-COM-009 — Contexte à chaque mutation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0   •   Type : parcours utilisateur / UI   •   Statut : À exécuter
Préconditions : Au moins un site et une formation sont créés.
Given  une opération de création ou de modification est terminée
When  je reviens au Contexte de travail sans déconnexion
And  je vérifie Organisation, Établissement, Formation et Promotion
And  j’actualise le navigateur
Then  les options reflètent immédiatement les créations autorisées
And  aucune sélection enfant obsolète n’est conservée
And  les listes restent correctes après rechargement
Résultat observable / preuve : Test transverse à rejouer après chaque étape et sur les quatre comptes.
10.3. Déroulés contextualisés à répéter dans l’interface
Centre 1 — Centre Horizon ECSR (USER-01)
Compte : sam.user1@email.com | mot de passe initial : Demo@123 | organisation : « Centre Horizon ECSR » | site : « Centre Horizon ECSR — Nice » | formation : « TP Enseignant de la conduite et de la sécurité routière » | référentiel : « RNCP41862 – CCP1 + CCP2 » | promotion : « ECSR 2027 – session A ».
Compétences : construire une séance ; animer une séance théorique ; enseigner la conduite B ; évaluer les acquis ; sensibiliser à la sécurité routière. Séance exemple : « Évaluation initiale B et sécurité routière ». Deux stagiaires fictifs.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ORG-SPEC-01 — Parcours complet du centre de spécialité

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0   •   Type : parcours utilisateur / UI   •   Statut : À exécuter
Préconditions : USER-01 possède son organisation, initialement sans données métier.
Given  je me connecte avec sam.user1@email.com et Demo@123
And  le Contexte de travail indique uniquement « Centre Horizon ECSR »
When  je contrôle le blocage sans responsable puis crée/affecte un responsable de CE centre
And  je crée dans l’ordre le site, la formation, son référentiel, la promotion et deux apprenants fictifs
And  je crée une séance pédagogique cohérente avec le domaine
And  après chaque création, je vérifie le Contexte de travail puis je recharge la page
Then  le centre possède « ECSR 2027 – session A » rattachée à « TP Enseignant de la conduite et de la sécurité routière »
And  les listes et indicateurs affichent les ressources réellement créées
And  aucune ressource d’un autre centre ne peut être sélectionnée
Résultat observable / preuve : Preuves à collecter : captures des étapes et de chaque état du Contexte de travail ; preuves des refus si prérequis manquant.
Centre 2 — Académie Azur Deux-Roues (USER-02)
Compte : sam.user2@email.com | mot de passe initial : Demo@123 | organisation : « Académie Azur Deux-Roues » | site : « Académie Azur Deux-Roues — Antibes » | formation : « CCS Enseignement deux-roues » | référentiel : « RNCP41862 – bloc CCS deux-roues BC03 » | promotion : « Moto 2027 – session A ».
Compétences : pédagogie moto hors circulation ; pédagogie moto en circulation ; risques spécifiques des deux-roues. Séance exemple : « Équilibre et maniabilité sur plateau ». Deux stagiaires fictifs.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ORG-SPEC-02 — Parcours complet du centre de spécialité

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0   •   Type : parcours utilisateur / UI   •   Statut : À exécuter
Préconditions : USER-02 possède son organisation, initialement sans données métier.
Given  je me connecte avec sam.user2@email.com et Demo@123
And  le Contexte de travail indique uniquement « Académie Azur Deux-Roues »
When  je contrôle le blocage sans responsable puis crée/affecte un responsable de CE centre
And  je crée dans l’ordre le site, la formation, son référentiel, la promotion et deux apprenants fictifs
And  je crée une séance pédagogique cohérente avec le domaine
And  après chaque création, je vérifie le Contexte de travail puis je recharge la page
Then  le centre possède « Moto 2027 – session A » rattachée à « CCS Enseignement deux-roues »
And  les listes et indicateurs affichent les ressources réellement créées
And  aucune ressource d’un autre centre ne peut être sélectionnée
Résultat observable / preuve : Preuves à collecter : captures des étapes et de chaque état du Contexte de travail ; preuves des refus si prérequis manquant.
Centre 3 — Institut Provence Poids Lourds (USER-03)
Compte : sam.user3@email.com | mot de passe initial : Demo@123 | organisation : « Institut Provence Poids Lourds » | site : « Institut Provence Poids Lourds — Marseille » | formation : « CCS Enseignement groupe lourd » | référentiel : « RNCP41862 – bloc CCS groupe lourd BC04 » | promotion : « Groupe lourd 2027 – session A ».
Compétences : manœuvres en sécurité hors circulation ; conduite d’un groupe lourd en circulation ; spécificités des véhicules lourds. Séance exemple : « Vérifications et manœuvres à faible vitesse ». Deux stagiaires fictifs.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ORG-SPEC-03 — Parcours complet du centre de spécialité

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0   •   Type : parcours utilisateur / UI   •   Statut : À exécuter
Préconditions : USER-03 possède son organisation, initialement sans données métier.
Given  je me connecte avec sam.user3@email.com et Demo@123
And  le Contexte de travail indique uniquement « Institut Provence Poids Lourds »
When  je contrôle le blocage sans responsable puis crée/affecte un responsable de CE centre
And  je crée dans l’ordre le site, la formation, son référentiel, la promotion et deux apprenants fictifs
And  je crée une séance pédagogique cohérente avec le domaine
And  après chaque création, je vérifie le Contexte de travail puis je recharge la page
Then  le centre possède « Groupe lourd 2027 – session A » rattachée à « CCS Enseignement groupe lourd »
And  les listes et indicateurs affichent les ressources réellement créées
And  aucune ressource d’un autre centre ne peut être sélectionnée
Résultat observable / preuve : Preuves à collecter : captures des étapes et de chaque état du Contexte de travail ; preuves des refus si prérequis manquant.
Centre 4 — Institut Méditerranée Ambulancier (USER-04)
Compte : sam.user4@email.com | mot de passe initial : Demo@123 | organisation : « Institut Méditerranée Ambulancier » | site : « Institut Méditerranée Ambulancier — Toulon » | formation : « Diplôme d’État d’ambulancier (DEA) » | référentiel : « Arrêté du 11 avril 2022 – référentiel DEA » | promotion : « DEA 2027 – session A ».
Compétences : évaluation du patient ; gestes d’urgence ; hygiène ; transport sanitaire ; communication. Séance exemple : « Prise en charge et installation du patient ». Prévoir une période en milieu professionnel ; repère réglementaire : 801 h au total (556 h + 245 h). Deux apprenants fictifs.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ORG-SPEC-04 — Parcours complet du centre de spécialité

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0   •   Type : parcours utilisateur / UI   •   Statut : À exécuter
Préconditions : USER-04 possède son organisation, initialement sans données métier.
Given  je me connecte avec sam.user4@email.com et Demo@123
And  le Contexte de travail indique uniquement « Institut Méditerranée Ambulancier »
When  je contrôle le blocage sans responsable puis crée/affecte un responsable de CE centre
And  je crée dans l’ordre le site, la formation, son référentiel, la promotion et deux apprenants fictifs
And  je crée une séance pédagogique cohérente avec le domaine
And  après chaque création, je vérifie le Contexte de travail puis je recharge la page
Then  le centre possède « DEA 2027 – session A » rattachée à « Diplôme d’État d’ambulancier (DEA) »
And  les listes et indicateurs affichent les ressources réellement créées
And  aucune ressource d’un autre centre ne peut être sélectionnée
Résultat observable / preuve : Preuves à collecter : captures des étapes et de chaque état du Contexte de travail ; preuves des refus si prérequis manquant.
11. Campagne 05 — Séparation stricte des quatre organisations
But : vérifier sur l’interface utilisateur qu’un centre de formation n’accède pas aux données métier d’un autre centre. Tester la visibilité, les listes de choix, les accès directs par URL quand elles sont visibles, et le retour au bon contexte après reconnexion.

Observe : 

Test :  ; anomalie : 

Preuves : 

## TEN-UI-001 — Quatre organisations indépendantes

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0   •   Type : parcours utilisateur / UI   •   Statut : À exécuter
Préconditions : Les quatre parcours ORG-SPEC sont terminés.
Given  je dispose des quatre comptes propriétaires
When  je me connecte successivement avec USER-01, USER-02, USER-03 et USER-04 dans des sessions séparées
And  je consulte à chaque fois le sélecteur Organisation
Then  seule l’organisation autorisée de chaque compte est visible
And  aucun changement de compte ne conserve l’organisation précédente
Résultat observable / preuve : Capturer les quatre sélecteurs.

Observe : 

Test :  ; anomalie : 

Preuves : 

## TEN-UI-002 — Filtrer les sites, formations et promotions

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0   •   Type : parcours utilisateur / UI   •   Statut : À exécuter
Préconditions : Les quatre centres contiennent des ressources différentes.
Given  je suis connecté à l’un des quatre centres
When  j’ouvre successivement les sélecteurs Site, Formation et Promotion
And  je répète le contrôle pour les autres comptes
Then  chaque liste contient exclusivement les ressources de son organisation
And  les intitulés d’un autre centre sont absents
Résultat observable / preuve : Vérifier les quatre niveaux du Contexte de travail.

Observe : 

Test :  ; anomalie : 

Preuves : 

## TEN-UI-003 — Pas de mélange dans les listes et statistiques

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0   •   Type : parcours utilisateur / UI   •   Statut : À exécuter
Préconditions : Des stagiaires et séances existent dans les quatre centres.
Given  les tableaux de bord sont chargés depuis les données métier créées
When  je consulte Stagiaires, Promotions, Séances, Planning, Pilotage organisation et Statistiques
And  je compare chaque centre à son jeu de données cible
Then  les données et compteurs correspondent au centre ouvert
And  aucun stagiaire, séance ou agrégat d’un autre centre n’est visible
Résultat observable / preuve : Conserver des captures avant/après pour chacun des quatre comptes.

Observe : 

Test :  ; anomalie : 

Preuves : 

## TEN-UI-004 — Liaison directe inter-centres interdite

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0   •   Type : parcours utilisateur / UI   •   Statut : À exécuter
Préconditions : Une URL métier de ressource du centre A a été obtenue par l’UI.
Given  je suis connecté au centre B dans un autre navigateur
When  je tente d’ouvrir l’URL observée du centre A
Then  l’accès à cette ressource est refusé ou masqué
And  aucun détail confidentiel de A n’est affiché
And  le contexte de B reste cohérent
Résultat observable / preuve : Utiliser uniquement les URL réellement rencontrées dans l’interface de staging.

Observe : 

Test :  ; anomalie : 

Preuves : 

## TEN-UI-005 — Aucun rattachement croisé dans un formulaire

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0   •   Type : parcours utilisateur / UI   •   Statut : À exécuter
Préconditions : Un responsable, un formateur et une promotion existent dans deux centres distincts.
Given  je suis en création d’une séance, promotion ou établissement
When  j’ouvre les listes déroulantes de responsables, formateurs, sites et promotions
Then  aucune identité ou ressource d’un autre centre n’est sélectionnable
And  le formulaire ne sauvegarde pas de relation inter-centres
Résultat observable / preuve : Répéter pour USER-01 à USER-04.

Observe : 

Test :  ; anomalie : 

Preuves : 

## TEN-UI-006 — Reconnexion et vérification finale des quatre identités

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0   •   Type : parcours utilisateur / UI   •   Statut : À exécuter
Préconditions : Les scénarios de changement de mot de passe sont terminés et réinitialisés.
Given  les quatre comptes existent et ont chacun leur organisation
When  je me déconnecte puis me connecte avec chacun des quatre comptes et Demo@123
And  j’ouvre Pilotage organisation puis Contexte de travail
Then  les quatre connexions réussissent
And  chacune ouvre le bon centre et conserve ses données métier
And  aucun compte propriétaire n’a été affecté à un autre centre par erreur
Résultat observable / preuve : Ne pas effacer les données sans demande explicite du responsable de recette.
12. Critères finaux de recette et traçabilité
Contrôle final
Critère d’acceptation
Comptes
USER-01, USER-02, USER-03 et USER-04 actifs, Demo@123 restauré sur chacun
Organisations
Quatre organisations fictives distinctes et autorisées, une par propriétaire
Données métier
Une configuration complète par centre : responsable, site, formation, référentiel, promotion, apprenants et séance
Blocages métier
Création incohérente sans responsable, formation ou référentiel empêchée avec message compréhensible
Contexte de travail
Contrôlé après chaque étape ; filtre organisation > établissement > formation > promotion cohérent
Isolation
Aucune lecture, modification ni sélection inter-organisation via l’UI
Qualité des preuves
Pour chaque anomalie : capture, compte, organisation, écran, étape, résultat attendu/réel
Données sensibles
Aucune donnée personnelle réelle, aucune adresse ou certification légale inventée
Champ de preuve
À renseigner par QA Panda
ID du scénario

Compte / organisation

Écran / URL

Statut
Réussi / Échoué / Bloqué / Non applicable
Action / données saisies

Résultat attendu et observé

Contexte de travail avant / après

Capture d’écran

Anomalie / sévérité

Date / heure


13. Campagne 06 — Invitations croisées et utilisateur multi-organisation
Objectif fonctionnel : faire des quatre comptes Direction des utilisateurs multi-organisation. Chacun conserve la Direction de son organisation d’origine et reçoit une invitation à rejoindre les trois autres sous un rôle différent de Stagiaire et Lecture seule. Les quatre organisations restent juridiquement et fonctionnellement distinctes : partager une identité AuthGate ne doit pas fusionner leurs données.
13.1. Comptes et prérequis
Code
Identifiant
Organisation principale
USER-01
sam.user1@email.com
Centre Horizon ECSR — Nice
USER-02
sam.user2@email.com
Académie Azur Deux-Roues — Antibes
USER-03
sam.user3@email.com
Institut Provence Poids Lourds — Marseille
USER-04
sam.user4@email.com
Institut Méditerranée Ambulancier — Toulon
Mot de passe initial commun : Demo@123. Réinitialiser à Demo@123 après les tests de changement (DemoDemo@123). Utiliser des profils fictifs uniquement. Le prérequis est que les quatre organisations aient été créées et que les comptes Direction puissent ouvrir le menu Gestion des accès.
13.2. Matrice d’invitations croisées : 12 relations à créer
Effectuer une invitation depuis l’organisation source vers chaque compte externe. Le rôle proposé doit être disponible dans l’UI et compatible avec ses prérequis. Si un rôle cible est indisponible, consigner le blocage et choisir un autre rôle autorisé hors Stagiaire / Lecture seule, sans contourner le contrôle métier.
Organisation invitante
Compte invité
Rôle cible à tester
USER-01 / ECSR
USER-02
Formateur
USER-01 / ECSR
USER-03
Secrétariat
USER-01 / ECSR
USER-04
Jury
USER-02 / Moto
USER-01
Responsable pédagogique
USER-02 / Moto
USER-03
Formateur
USER-02 / Moto
USER-04
Secrétariat
USER-03 / Poids lourds
USER-01
Jury
USER-03 / Poids lourds
USER-02
Direction établissement
USER-03 / Poids lourds
USER-04
Formateur
USER-04 / Ambulancier
USER-01
Secrétariat
USER-04 / Ambulancier
USER-02
Jury
USER-04 / Ambulancier
USER-03
Responsable pédagogique
Point de contrôle : une affectation de Responsable pédagogique ne doit pas remplacer silencieusement le responsable unique d’une formation. L’invitation à un rôle ne vaut pas affectation à une formation ou promotion spécifique tant que cette opération n’est pas finalisée.
13.3. Scénarios fonctionnels Given / When / Then

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-MULTI-001 — Inviter un utilisateur déjà présent dans AuthGate

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0/P1 selon impact | Type : E2E UI | Exécution : staging | Preuve : capture d’écran avant/après, organisation et rôle actifs, résultat après actualisation.
Given USER-01 est connecté à son organisation ECSR en tant que DirectionAnd USER-02 possède déjà un compte AuthGate et sa propre organisation MotoWhen USER-01 ouvre Gestion des accès et invite sam.user2@email.com avec le rôle FormateurThen l’UI propose le traitement d’une identité existante sans exiger une nouvelle création de compteAnd l’invitation ou le rattachement apparaît avec un état expliciteAnd l’identité et le rôle Direction de USER-02 dans Moto restent inchangés.
Verdict : À exécuter (Réussi / Échoué / Bloqué). Conserver la preuve et l’identifiant de l’anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-MULTI-002 — Réaliser toutes les invitations croisées

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0/P1 selon impact | Type : E2E UI | Exécution : staging | Preuve : capture d’écran avant/après, organisation et rôle actifs, résultat après actualisation.
Given les quatre organisations sont accessibles à leur Direction respectiveWhen PANDA exécute les 12 invitations de la matrice à partir de chaque organisation invitanteThen chaque destinataire est correctement identifiéAnd chaque invitation possède le rôle attendu ou un blocage justifié et documentéAnd aucun doublon de compte ni membre indésirable n’est créé.
Verdict : À exécuter (Réussi / Échoué / Bloqué). Conserver la preuve et l’identifiant de l’anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-MULTI-003 — Accepter une invitation depuis l’interface

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0/P1 selon impact | Type : E2E UI | Exécution : staging | Preuve : capture d’écran avant/après, organisation et rôle actifs, résultat après actualisation.
Given USER-02 possède une invitation en attente dans l’organisation ECSRWhen USER-02 ouvre le parcours d’acceptation proposé par l’interface et confirme son rattachementThen l’organisation ECSR devient accessible à USER-02 selon les droits attribuésAnd son organisation d’origine Moto reste accessibleAnd aucune confirmation d’adresse e-mail supplémentaire n’est imposée si elle est désactivée en stagingAnd les étapes de validation propres aux invitations ne sont pas présumées désactivées.
Verdict : À exécuter (Réussi / Échoué / Bloqué). Conserver la preuve et l’identifiant de l’anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-MULTI-004 — Sélectionner l’organisation après connexion

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0/P1 selon impact | Type : E2E UI | Exécution : staging | Preuve : capture d’écran avant/après, organisation et rôle actifs, résultat après actualisation.
Given USER-02 a au moins deux appartenances activesWhen USER-02 se déconnecte puis se reconnecte avec sam.user2@email.com et Demo@123Then l’interface lui permet de choisir l’organisation autorisée ou d’utiliser un sélecteur équivalentAnd la liste n’affiche que ses organisations activesAnd le Contexte de travail correspond à l’organisation sélectionnée.
Verdict : À exécuter (Réussi / Échoué / Bloqué). Conserver la preuve et l’identifiant de l’anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-MULTI-005 — Changer d’organisation sans mélange de données

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0/P1 selon impact | Type : E2E UI | Exécution : staging | Preuve : capture d’écran avant/après, organisation et rôle actifs, résultat après actualisation.
Given USER-02 consulte les données MotoWhen il choisit ECSR dans le sélecteur de contexteThen les établissements, formations, promotions, stagiaires, séances et indicateurs affichés appartiennent uniquement à ECSRAnd aucune donnée Moto ne reste affichée comme donnée ECSRAnd l’interface adapte les actions disponibles à son rôle Formateur en ECSR.
Verdict : À exécuter (Réussi / Échoué / Bloqué). Conserver la preuve et l’identifiant de l’anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-MULTI-006 — Retrouver les permissions propres à chaque organisation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0/P1 selon impact | Type : E2E UI | Exécution : staging | Preuve : capture d’écran avant/après, organisation et rôle actifs, résultat après actualisation.
Given USER-01 possède le rôle Direction dans ECSR et un rôle non Direction dans MotoWhen il navigue de ECSR vers MotoThen les menus et boutons privilégiés de Direction ne sont disponibles qu’en ECSRAnd les opérations interdites dans Moto ne peuvent pas être validéesAnd un refus affiche un message compréhensible sans faux succès.
Verdict : À exécuter (Réussi / Échoué / Bloqué). Conserver la preuve et l’identifiant de l’anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-MULTI-007 — Empêcher une création dans la mauvaise organisation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0/P1 selon impact | Type : E2E UI | Exécution : staging | Preuve : capture d’écran avant/après, organisation et rôle actifs, résultat après actualisation.
Given USER-03 est connecté à son organisation Poids lourds et appartient aussi à ECSRWhen il ouvre un formulaire de création dans ECSRThen les listes de sites, formations et promotions sont limitées à ECSRAnd aucune option propre à Poids lourds ne peut être sélectionnéeAnd la création, si permise, reste dans ECSR après rechargement.
Verdict : À exécuter (Réussi / Échoué / Bloqué). Conserver la preuve et l’identifiant de l’anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-MULTI-008 — Conserver le bon contexte après actualisation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0/P1 selon impact | Type : E2E UI | Exécution : staging | Preuve : capture d’écran avant/après, organisation et rôle actifs, résultat après actualisation.
Given USER-04 a sélectionné une de ses organisations secondairesWhen il actualise la page et navigue entre deux menusThen le contexte actif reste valide ou est explicitement demandé à nouveauAnd aucun autre centre n’est sélectionné silencieusementAnd toutes les listes reflètent le contexte effectivement actif.
Verdict : À exécuter (Réussi / Échoué / Bloqué). Conserver la preuve et l’identifiant de l’anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-MULTI-009 — Retirer une seule appartenance sans supprimer le compte

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0/P1 selon impact | Type : E2E UI | Exécution : staging | Preuve : capture d’écran avant/après, organisation et rôle actifs, résultat après actualisation.
Given USER-02 appartient à Moto et à ECSRWhen une Direction habilitée retire son accès ECSR depuis Gestion des accèsThen ECSR n’apparaît plus parmi les espaces autorisés de USER-02 après actualisation ou reconnexionAnd son compte AuthGate reste utilisableAnd son rôle Direction et ses données autorisées dans Moto sont conservés.
Verdict : À exécuter (Réussi / Échoué / Bloqué). Conserver la preuve et l’identifiant de l’anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-MULTI-010 — Retirer un accès dans le contexte actif

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0/P1 selon impact | Type : E2E UI | Exécution : staging | Preuve : capture d’écran avant/après, organisation et rôle actifs, résultat après actualisation.
Given USER-02 navigue actuellement dans ECSRWhen son accès ECSR est suspendu ou retiré par une Direction habilitéeThen toute nouvelle opération dans ECSR est refuséeAnd l’interface ne continue pas à exposer les données d’ECSR après prise en compte de la révocationAnd ses autres organisations autorisées demeurent accessibles.
Verdict : À exécuter (Réussi / Échoué / Bloqué). Conserver la preuve et l’identifiant de l’anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-MULTI-011 — Ne pas créer de doublon par invitation répétée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0/P1 selon impact | Type : E2E UI | Exécution : staging | Preuve : capture d’écran avant/après, organisation et rôle actifs, résultat après actualisation.
Given USER-02 dispose déjà d’une invitation ou d’une appartenance active à ECSRWhen USER-01 essaie de l’inviter de nouveau avec la même adresseThen l’UI empêche la duplication ou présente une action de reprise expliciteAnd aucune seconde identité AuthGate n’est crééeAnd les affectations ne sont pas ajoutées deux fois.
Verdict : À exécuter (Réussi / Échoué / Bloqué). Conserver la preuve et l’identifiant de l’anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-MULTI-012 — Contrôle transversal des quatre comptes et du Contexte de travail

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0/P1 selon impact | Type : E2E UI | Exécution : staging | Preuve : capture d’écran avant/après, organisation et rôle actifs, résultat après actualisation.
Given les invitations autorisées ont été acceptéesWhen PANDA ouvre une session distincte pour chacun des quatre comptesAnd il visite chaque organisation autorisée via le Contexte de travailThen l’organisation principale et les appartenances secondaires attendues sont visiblesAnd les droits et les données correspondent toujours au couple utilisateur–organisation sélectionnéAnd aucun utilisateur ne voit les organisations auxquelles il n’appartient pas.
Verdict : À exécuter (Réussi / Échoué / Bloqué). Conserver la preuve et l’identifiant de l’anomalie si nécessaire.
13.4. Règles d’exécution et critères de sortie
Exécuter les tests avec l’interface uniquement ; ne pas insérer directement de rattachement dans la base.
Ne pas confondre confirmation d’adresse e-mail désactivée et acceptation d’une invitation : tester le parcours réellement présenté.
Tester le changement de contexte après chaque invitation acceptée, affectation, suspension et révocation.
Une organisation doit rester autonome : le partage d’un utilisateur ne doit ni fusionner les référentiels ni déplacer les données métier.
À la fin de la recette, garder les quatre comptes principaux actifs, avec Demo@123, et documenter les appartenances croisées réellement créées.
Ne pas considérer le scénario réussi si les données sont correctes uniquement avant actualisation.

14. Campagne 07 — Gestion des accès : recette fonctionnelle complète
Objectif : clôturer le périmètre Gestion des accès avec des vérifications exclusivement réalisables dans l’interface utilisateur. Réutiliser les quatre comptes Direction et les douze invitations croisées de la campagne 06. Aucun accès direct à la base de données, aucun contournement des formulaires et aucune création d’identité dans un autre centre par erreur.
14.1. Prérequis et jeux de données
Organisation 1 : Centre Horizon ECSR — USER-01 (sam.user1@email.com). Organisation 2 : Académie Azur Deux-Roues — USER-02. Organisation 3 : Institut Provence Poids Lourds — USER-03. Organisation 4 : Institut Méditerranée Ambulancier — USER-04.
Mot de passe initial commun : Demo@123. Si une modification de mot de passe est exigée, utiliser DemoDemo@123 puis restaurer Demo@123 avant clôture.
Créer des utilisateurs auxiliaires fictifs et identifiables par centre : gestion.ecsr.qa@email.com, formateur.ecsr.qa@email.com, gestion.moto.qa@email.com, formateur.moto.qa@email.com, gestion.pl.qa@email.com, formateur.pl.qa@email.com, gestion.ambulance.qa@email.com, formateur.ambulance.qa@email.com. Ne jamais envoyer d’invitation à une personne réelle. Si la messagerie de test est indisponible, noter « bloqué » au lieu d’inventer une acceptation.
Les quatre comptes Direction doivent rester actifs dans leur organisation principale. Tester les suspensions et retraits de préférence sur les comptes auxiliaires ou une appartenance secondaire réversible, puis restaurer l’état attendu.
Après chaque mutation : vérifier l’état de la ligne, le compteur, le détail, l’actualisation, la reconnexion du compte concerné et le Contexte de travail (organisation, site, formation, promotion selon le périmètre).
14.2. Matrice de vérification des rôles
Profil à vérifier
Parcours UI
Contrôle obligatoire
Administrateur organisation
Compte auxiliaire habilité seulement
Gestion de l’organisation autorisée sans accès aux autres centres
Direction organisation
USER-01 à USER-04 dans leur centre
Menus Direction dans son centre uniquement
Direction établissement
Utilisateur affecté à un site
Pas de pilotage d’un autre site sans affectation
Responsable pédagogique
Utilisateur affecté à une formation
Actions pédagogiques limitées à son périmètre
Secrétariat
Compte invité
Actions administratives sans élévation de droits
Formateur
Compte invité
Accès aux séances et apprenants autorisés
Stagiaire
Compte d’essai séparé
Aucune gestion des accès
Jury
Compte invité selon session
Accès aux examens attribués seulement
Lecture seule
Compte d’essai séparé
Aucune création, modification ou suppression

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-UI-001 — État initial et indicateurs

Verdict : PASS

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given USER-01 est connecté à Centre Horizon ECSR et les autres membres auxiliaires ne sont pas encore créésWhen il ouvre Gestion des accèsThen le compte Direction existant apparaît dans la listeAnd les indicateurs Comptes, Accès actifs, Affectations et Multi-périmètres sont visibles et cohérents avec la listeAnd aucun compte fictif prérempli n’apparaît ; les contrôles restent utilisables.
Preuve : Capture de l’écran avant/après ; nom de l’organisation active ; résultat après actualisation ; verdict Réussi/Échoué/Bloqué.Verdict : À exécuter — Réussi / Échoué / Bloqué ; anomalie à référencer en cas d’échec.

Observe : Avant invitations, Horizon : un propriétaire réel,1compte/1actif/0affectation/0multi. Après rechargement liste cohérente.

Test : test-3 ; anomalie : 

Preuves : Snapshots117–118

## ACC-UI-002 — Formulaire d’invitation et champs obligatoires

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given la Direction ouvre Inviter un utilisateurWhen elle soumet un formulaire avec prénom, nom, e-mail ou rôle manquantThen chaque champ requis est signalé clairementAnd aucune invitation n’est créée ni comptabilisée.
Preuve : Capture de l’écran avant/après ; nom de l’organisation active ; résultat après actualisation ; verdict Réussi/Échoué/Bloqué.Verdict : À exécuter — Réussi / Échoué / Bloqué ; anomalie à référencer en cas d’échec.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-UI-003 — E-mail invalide, espaces et casse

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le formulaire d’invitation est ouvertWhen PANDA saisit un e-mail invalide puis une adresse valide avec espaces ou majusculesThen l’e-mail invalide est rejetéAnd la saisie valide est traitée de façon cohérente sans créer deux identités pour la même adresse.
Preuve : Capture de l’écran avant/après ; nom de l’organisation active ; résultat après actualisation ; verdict Réussi/Échoué/Bloqué.Verdict : À exécuter — Réussi / Échoué / Bloqué ; anomalie à référencer en cas d’échec.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-UI-004 — Invitation valide et visibilité après rafraîchissement

Verdict : PASS

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given aucun utilisateur auxiliaire ECSR n’existeWhen USER-01 invite gestion.ecsr.qa@email.com avec le rôle SecrétariatThen la ligne d’invitation ou d’accès est affichée avec un statut expliciteAnd le compteur est actualisé après confirmationAnd le résultat demeure visible après actualisation de la page.
Preuve : Capture de l’écran avant/après ; nom de l’organisation active ; résultat après actualisation ; verdict Réussi/Échoué/Bloqué.Verdict : À exécuter — Réussi / Échoué / Bloqué ; anomalie à référencer en cas d’échec.

Observe : Gestion ECSR QA invitée via UI, statut Invitation sent persistant après reload, compteur+1. Administration utilisé comme libellé UI de Secrétariat ; aucune acceptation prouvée.

Test : test-3 ; anomalie : 

Preuves : invite-aux-persisted.png

## ACC-UI-005 — Invitation d’un utilisateur AuthGate existant

Verdict : PASS

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given USER-02 existe déjà et dirige le centre MotoWhen USER-01 l’invite dans ECSR sous un rôle autoriséThen l’UI rattache une identité existante ou propose une invitation appropriéeAnd aucun deuxième compte sam.user2@email.com n’est crééAnd Moto reste accessible à USER-02.
Preuve : Capture de l’écran avant/après ; nom de l’organisation active ; résultat après actualisation ; verdict Réussi/Échoué/Bloqué.Verdict : À exécuter — Réussi / Échoué / Bloqué ; anomalie à référencer en cas d’échec.

Observe : USER02 existant invité Trainer à Horizon ; une seule ligne email, statut pending persistant. Reconnexion USER02 : propre organisation Azur reste accessible ; Horizon non accessible avant acceptation.

Test : test-5 ; anomalie : 

Preuves : invite-cross-created.png; cross-pending-azure-context.png

## ACC-UI-006 — Invitation doublon, répétition et auto-invitation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une invitation vers USER-02 existe déjà depuis ECSRWhen USER-01 réinvite USER-02, puis tente de s’inviter lui-mêmeThen le système refuse ou présente un parcours explicite de reprise sans créer de doublonsAnd les compteurs et affectations restent inchangés en cas de refus.
Preuve : Capture de l’écran avant/après ; nom de l’organisation active ; résultat après actualisation ; verdict Réussi/Échoué/Bloqué.Verdict : À exécuter — Réussi / Échoué / Bloqué ; anomalie à référencer en cas d’échec.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-UI-007 — Recherche par identité et e-mail

Verdict : PASS

Attendu et preconditions :
Priorité : P2  •  Type : E2E UI  •  Environnement : staging
Given plusieurs comptes réels ou invitations existent dans ECSRWhen la Direction recherche un prénom, un nom puis une adresse e-mail exacteThen seuls les résultats correspondants apparaissentAnd effacer la recherche rétablit la liste sans changer le Contexte de travail.
Preuve : Capture de l’écran avant/après ; nom de l’organisation active ; résultat après actualisation ; verdict Réussi/Échoué/Bloqué.Verdict : À exécuter — Réussi / Échoué / Bloqué ; anomalie à référencer en cas d’échec.

Observe : Horizon : Gestion=1, nom ECSR QA=2, email exact=1 ; recherche inconnue0 ; effacement clavier restaure4 sans changer contexte.

Test : test-39 ; anomalie : 

Preuves : access-search-final.png; snapshots recherche conservés

## ACC-UI-008 — Filtrer par rôle et état

Verdict : PASS

Attendu et preconditions :
Priorité : P2  •  Type : E2E UI  •  Environnement : staging
Given plusieurs rôles et états sont visiblesWhen PANDA applique un filtre de rôle ou de statut disponible puis l’effaceThen la liste change sans altérer les comptesAnd les filtres restent cohérents avec le contexte de l’organisation sélectionnée.
Preuve : Capture de l’écran avant/après ; nom de l’organisation active ; résultat après actualisation ; verdict Réussi/Échoué/Bloqué.Verdict : À exécuter — Réussi / Échoué / Bloqué ; anomalie à référencer en cas d’échec.

Observe : Filtres Administration/Educational manager/Trainer donnent chacun leur ligne ; All roles restaure4 et statuts inchangés.

Test : test-39 ; anomalie : 

Preuves : access-search-final.png; snapshots282–285

## ACC-UI-009 — Sélectionner un compte : détail et permissions

Verdict : PASS

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le compte auxiliaire ECSR est présentWhen la Direction sélectionne sa ligneThen les détails d’identité, état, rôle, affectations et permissions accessibles sont affichésAnd les informations correspondent à cette personne et à l’organisation ECSR.
Preuve : Capture de l’écran avant/après ; nom de l’organisation active ; résultat après actualisation ; verdict Réussi/Échoué/Bloqué.Verdict : À exécuter — Réussi / Échoué / Bloqué ; anomalie à référencer en cas d’échec.

Observe : Sélection Gestion ECSR QA : détails à son nom, rôle Administration, Invitation sent, zéro affectation, zone permissions cohérente.

Test : test-39 ; anomalie : 

Preuves : access-search-final.png

## ACC-UI-010 — Ouvrir la gestion des affectations

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le compte invité a accepté son invitationWhen la Direction ouvre Gérer les affectationsThen les périmètres organisation, établissement, formation, promotion et examen autorisés sont proposés selon l’interfaceAnd les champs dépendants ne proposent que les ressources existantes du centre.
Preuve : Capture de l’écran avant/après ; nom de l’organisation active ; résultat après actualisation ; verdict Réussi/Échoué/Bloqué.Verdict : À exécuter — Réussi / Échoué / Bloqué ; anomalie à référencer en cas d’échec.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-UI-011 — Affectation établissement valide et contexte

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un utilisateur est actif et deux établissements fictifs du même centre existentWhen la Direction l’affecte seulement au premier établissementThen l’affectation est visible après sauvegarde et rafraîchissementAnd lors de la connexion de cet utilisateur, le Contexte de travail ne propose pas le second site s’il n’y a aucun autre droit qui l’y autorise.
Preuve : Capture de l’écran avant/après ; nom de l’organisation active ; résultat après actualisation ; verdict Réussi/Échoué/Bloqué.Verdict : À exécuter — Réussi / Échoué / Bloqué ; anomalie à référencer en cas d’échec.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-UI-012 — Affectation formation valide et contexte

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un établissement dispose de deux formations distinctesWhen la Direction affecte le formateur uniquement à la formation choisieThen le détail affiche le bon établissement et la bonne formationAnd le Contexte de travail du formateur ne donne pas un accès indu à l’autre formation.
Preuve : Capture de l’écran avant/après ; nom de l’organisation active ; résultat après actualisation ; verdict Réussi/Échoué/Bloqué.Verdict : À exécuter — Réussi / Échoué / Bloqué ; anomalie à référencer en cas d’échec.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-UI-013 — Affectation promotion valide et contexte

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given deux promotions existent dans la formation du centreWhen le responsable affecte l’utilisateur à une seule promotionThen seule la promotion autorisée est accessible dans ce périmètreAnd aucun stagiaire de l’autre promotion n’est visible par effet d’un rattachement erroné.
Preuve : Capture de l’écran avant/après ; nom de l’organisation active ; résultat après actualisation ; verdict Réussi/Échoué/Bloqué.Verdict : À exécuter — Réussi / Échoué / Bloqué ; anomalie à référencer en cas d’échec.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-UI-014 — Affectation à une session d’examen pour Jury

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un compte Jury et une session d’examen du centre existentWhen la Direction associe le Jury à la session depuis l’interface disponibleThen l’affectation s’affiche et persiste après actualisationAnd le Jury ne peut pas intervenir sur une autre session non attribuée.
Preuve : Capture de l’écran avant/après ; nom de l’organisation active ; résultat après actualisation ; verdict Réussi/Échoué/Bloqué.Verdict : À exécuter — Réussi / Échoué / Bloqué ; anomalie à référencer en cas d’échec.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-UI-015 — Liste dépendante vide et affectation impossible

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given aucun établissement, formation, promotion ou examen n’existe dans le périmètre sélectionnéWhen PANDA ouvre les champs d’affectation correspondantsThen aucune valeur inventée n’est proposéeAnd l’interface empêche d’enregistrer une référence absente et explique le prérequis.
Preuve : Capture de l’écran avant/après ; nom de l’organisation active ; résultat après actualisation ; verdict Réussi/Échoué/Bloqué.Verdict : À exécuter — Réussi / Échoué / Bloqué ; anomalie à référencer en cas d’échec.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-UI-016 — Refus d’affectation inter-organisation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given USER-01 gère les accès d’ECSR et les sites de Moto existentWhen il tente de choisir un site, une formation ou une promotion de MotoThen ces ressources ne figurent pas dans les sélecteurs ECSRAnd aucun rattachement inter-centres n’est enregistré.
Preuve : Capture de l’écran avant/après ; nom de l’organisation active ; résultat après actualisation ; verdict Réussi/Échoué/Bloqué.Verdict : À exécuter — Réussi / Échoué / Bloqué ; anomalie à référencer en cas d’échec.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-UI-017 — Plusieurs affectations sans duplication

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un utilisateur est actif dans un centreWhen la Direction lui ajoute deux affectations valides distinctes puis réessaie l’une d’ellesThen les deux affectations sont visiblesAnd la répétition ne crée pas de doublon et les indicateurs Multi-périmètres sont cohérents.
Preuve : Capture de l’écran avant/après ; nom de l’organisation active ; résultat après actualisation ; verdict Réussi/Échoué/Bloqué.Verdict : À exécuter — Réussi / Échoué / Bloqué ; anomalie à référencer en cas d’échec.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-UI-018 — Retirer une affectation ciblée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un utilisateur possède deux affectations au sein d’une organisationWhen la Direction retire uniquement l’une d’ellesThen l’affectation retirée disparaît après actualisationAnd l’autre reste active et les options du Contexte de travail sont recalculées.
Preuve : Capture de l’écran avant/après ; nom de l’organisation active ; résultat après actualisation ; verdict Réussi/Échoué/Bloqué.Verdict : À exécuter — Réussi / Échoué / Bloqué ; anomalie à référencer en cas d’échec.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-UI-019 — Modification du rôle : action réellement disponible

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given la Direction affiche le détail d’un utilisateur actifWhen elle recherche une action de modification de rôle dans l’interfaceThen si l’action est exposée, elle permet un changement autorisé et persistéAnd si aucune action n’est exposée, PANDA classe le scénario Bloqué / fonctionnalité UI absente et joint une capture, sans simuler une modification technique.
Preuve : Capture de l’écran avant/après ; nom de l’organisation active ; résultat après actualisation ; verdict Réussi/Échoué/Bloqué.Verdict : À exécuter — Réussi / Échoué / Bloqué ; anomalie à référencer en cas d’échec.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-UI-020 — Modification du rôle et changement des menus

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un compte auxiliaire peut changer légalement de rôle via l’UIWhen la Direction passe ce compte de Formateur à Secrétariat, puis ce compte se reconnecteThen les menus et actions reflètent le nouveau rôleAnd les droits de l’ancien rôle ne subsistent pas abusivementAnd les autres organisations du même utilisateur conservent leurs rôles propres.
Preuve : Capture de l’écran avant/après ; nom de l’organisation active ; résultat après actualisation ; verdict Réussi/Échoué/Bloqué.Verdict : À exécuter — Réussi / Échoué / Bloqué ; anomalie à référencer en cas d’échec.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-UI-021 — Permissions individuelles : changement autorisé

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given la Direction possède une action UI de gestion des permissions d’un compteWhen elle retire une permission non indispensable à un compte auxiliaire puis valideThen la modification est visible après actualisationAnd le compte concerné ne peut plus réaliser l’action interdite après prise en compte ou reconnexionAnd les autres organisations ne perdent pas leurs droits propres.
Preuve : Capture de l’écran avant/après ; nom de l’organisation active ; résultat après actualisation ; verdict Réussi/Échoué/Bloqué.Verdict : À exécuter — Réussi / Échoué / Bloqué ; anomalie à référencer en cas d’échec.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-UI-022 — Permissions : refus d’élévation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un utilisateur est connecté avec un rôle non administrateurWhen il tente d’accéder aux permissions ou actions de gestion des accès visibles ou via navigation normaleThen aucune action de gestion interdite ne peut être finaliséeAnd aucun faux message de succès n’apparaît.
Preuve : Capture de l’écran avant/après ; nom de l’organisation active ; résultat après actualisation ; verdict Réussi/Échoué/Bloqué.Verdict : À exécuter — Réussi / Échoué / Bloqué ; anomalie à référencer en cas d’échec.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-UI-023 — Matrice des neuf rôles : menus et actions

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given les neuf rôles du tableau de cette campagne peuvent être attribués à des comptes d’essai appropriésWhen PANDA se connecte successivement avec chacun et ouvre Accueil, Gestion des accès et un menu métierThen seuls les menus et actions autorisés pour son rôle et son périmètre sont disponiblesAnd Stagiaire et Lecture seule ne peuvent effectuer aucune administrationAnd pour chaque rôle impossible à provisionner depuis l’UI, PANDA note Bloqué et le motif.
Preuve : Capture de l’écran avant/après ; nom de l’organisation active ; résultat après actualisation ; verdict Réussi/Échoué/Bloqué.Verdict : À exécuter — Réussi / Échoué / Bloqué ; anomalie à référencer en cas d’échec.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-UI-024 — Suspension ciblée d’un accès

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un compte auxiliaire appartient à ECSR et éventuellement à MotoWhen la Direction suspend son accès ECSR et confirmeThen l’état suspendu est visible et persisté après actualisationAnd le compte ne peut pas travailler sur ECSRAnd l’accès à Moto reste valide si la suspension est limitée à l’appartenance ECSR.
Preuve : Capture de l’écran avant/après ; nom de l’organisation active ; résultat après actualisation ; verdict Réussi/Échoué/Bloqué.Verdict : À exécuter — Réussi / Échoué / Bloqué ; anomalie à référencer en cas d’échec.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-UI-025 — Réactivation après suspension

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given le compte auxiliaire est suspendu dans ECSRWhen la Direction le réactive via l’interfaceThen son état redevient actif et persiste après actualisationAnd seuls les droits et affectations explicitement conservés ou rétablis sont utilisablesAnd le Contexte de travail reflète ce nouvel état.
Preuve : Capture de l’écran avant/après ; nom de l’organisation active ; résultat après actualisation ; verdict Réussi/Échoué/Bloqué.Verdict : À exécuter — Réussi / Échoué / Bloqué ; anomalie à référencer en cas d’échec.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-UI-026 — Retrait d’accès avec dépendance métier

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un responsable est affecté à une formation active ou une promotion dont il dépendWhen la Direction essaie de retirer son accèsThen l’interface bloque l’action si la dépendance métier l’exige et explique la correction attendueAnd aucune modification partielle silencieuse n’est appliquée.
Preuve : Capture de l’écran avant/après ; nom de l’organisation active ; résultat après actualisation ; verdict Réussi/Échoué/Bloqué.Verdict : À exécuter — Réussi / Échoué / Bloqué ; anomalie à référencer en cas d’échec.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-UI-027 — Protection du dernier administrateur / propriétaire

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given l’organisation n’a qu’un seul administrateur/propriétaire autoriséWhen ce dernier tente de retirer son propre accès privilégié ou de se suspendre sans remplaçantThen une règle de protection empêche de laisser l’organisation sans administrateur si cette règle est prévueAnd l’action ne supprime pas accidentellement l’accès du compte propriétaireAnd tout écart est documenté comme anomalie critique à arbitrer.
Preuve : Capture de l’écran avant/après ; nom de l’organisation active ; résultat après actualisation ; verdict Réussi/Échoué/Bloqué.Verdict : À exécuter — Réussi / Échoué / Bloqué ; anomalie à référencer en cas d’échec.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-UI-028 — Retrait d’une appartenance sans supprimer l’identité

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given USER-02 appartient à Moto et ECSRWhen USER-01 retire uniquement l’appartenance ECSR de USER-02Then USER-02 ne peut plus sélectionner ECSR après reconnexionAnd USER-02 conserve son organisation Moto avec ses données et droitsAnd son identité AuthGate unique n’est pas effacée.
Preuve : Capture de l’écran avant/après ; nom de l’organisation active ; résultat après actualisation ; verdict Réussi/Échoué/Bloqué.Verdict : À exécuter — Réussi / Échoué / Bloqué ; anomalie à référencer en cas d’échec.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-UI-029 — Mise à jour et rafraîchissement de toute la page

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given la Direction a effectué une invitation, affectation, modification, suspension et retrait validesWhen elle revient sur la liste puis recharge la page après chaque actionThen la ligne, les compteurs, le détail et les filtres affichent l’état réelAnd aucun changement n’est visible uniquement de façon optimiste ou disparaît après actualisation.
Preuve : Capture de l’écran avant/après ; nom de l’organisation active ; résultat après actualisation ; verdict Réussi/Échoué/Bloqué.Verdict : À exécuter — Réussi / Échoué / Bloqué ; anomalie à référencer en cas d’échec.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-UI-030 — Contexte de travail après toute modification des accès

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un utilisateur a plusieurs affectations, centres et rôlesWhen sa Direction modifie successivement une affectation, une permission puis une appartenanceThen après chaque opération le Contexte de travail présente uniquement les organisations, établissements, formations et promotions autorisésAnd la sélection courante invalide est réinitialisée ou rejetée explicitementAnd un changement de centre ne mélange aucune donnée métier.
Preuve : Capture de l’écran avant/après ; nom de l’organisation active ; résultat après actualisation ; verdict Réussi/Échoué/Bloqué.Verdict : À exécuter — Réussi / Échoué / Bloqué ; anomalie à référencer en cas d’échec.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-UI-031 — Recherche, liste et statistiques au-delà de 100 comptes

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P2  •  Type : E2E UI  •  Environnement : staging
Given une organisation de recette dispose de plus de 100 comptes autorisés créés par les seuls parcours UIWhen PANDA parcourt les pages ou fait une recherche et vérifie les indicateursThen tous les comptes restent accessibles via pagination ou mécanisme équivalentAnd les totaux affichés correspondent à l’ensemble du périmètre et pas seulement à la première pageAnd si les prérequis de volume ne sont pas réunis, le test est Bloqué / données insuffisantes.
Preuve : Capture de l’écran avant/après ; nom de l’organisation active ; résultat après actualisation ; verdict Réussi/Échoué/Bloqué.Verdict : À exécuter — Réussi / Échoué / Bloqué ; anomalie à référencer en cas d’échec.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ACC-UI-032 — Session concurrente et propagation des droits

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given USER-02 dispose d’une session active dans ECSR et USER-01 administre ses accès dans une autre sessionWhen USER-01 suspend ou retire l’accès ECSR de USER-02Then les nouvelles opérations de USER-02 sur ECSR échouent après prise en compte de la révocationAnd aucun accès persistant à ECSR ne demeure lors de la navigation ou du rechargementAnd Moto demeure accessible.
Preuve : Capture de l’écran avant/après ; nom de l’organisation active ; résultat après actualisation ; verdict Réussi/Échoué/Bloqué.Verdict : À exécuter — Réussi / Échoué / Bloqué ; anomalie à référencer en cas d’échec.
14.3. Contrôles de clôture — Gestion des accès
Les 4 comptes Direction sont actifs dans leur centre d’origine et leur mot de passe est redevenu Demo@123.
Les 12 invitations croisées sont réalisées, acceptées ou documentées comme bloquées avec un motif vérifiable ; aucun doublon d’identité.
Les rôles, permissions, affectations et restrictions sont testés par interaction UI et non déduits d’un libellé.
Après toute action réussie, les listes, compteurs et Contexte de travail se mettent à jour et restent cohérents après actualisation / reconnexion.
Aucun compte multi-organisation ne voit les données métier ou les actions privilégiées d’une autre organisation sans habilitation.
Les tests destructifs (suspension/retrait) ont été exécutés sur des comptes auxiliaires ou des appartenances secondaires, puis réparés ; les 4 propriétaires demeurent intacts.
Aucune anomalie critique P0 ouverte avant de déclarer le menu prêt pour validation. La campagne reste « rédigée, non exécutée » tant que PANDA ne l’a pas jouée.
CAMPAGNE 08 : Administration — scénarios détaillés ci-après. Statut de rédaction : prêt à exécuter ; aucun résultat présumé.

15. Campagne 08 — Administration : recette fonctionnelle complète
Objectif : valider l’ensemble des actions accessibles depuis le menu Administration /administration par navigation dans le navigateur, sur quatre organisations indépendantes. Ne jamais confondre un interrupteur visuellement activé avec un changement fonctionnel confirmé. Tests proposés sur staging uniquement ; aucun résultat ne doit être déclaré réussi sans observation.
15.1. Préparation et règles d’exécution
Se connecter successivement comme USER-01 (Centre Horizon ECSR, Nice), USER-02 (Académie Azur Deux-Roues, Antibes), USER-03 (Institut Provence Poids Lourds, Marseille), USER-04 (Institut Méditerranée Ambulancier, Toulon). Les comptes ont Demo@123 au démarrage et en fin de recette.
Avant toute modification, relever et capturer le Contexte de travail : organisation, établissement, formation et promotion sélectionnés. Après chaque action, vérifier les écrans liés, puis actualiser ; en cas de modification des droits ou de contexte, reconnecter le compte concerné.
Les centres, personnes et sites sont fictifs. Utiliser des noms et coordonnées de recette, et ne jamais inventer de SIRET, numéro de déclaration d’activité, agrément ni autre identifiant officiel. Laisser un champ réglementaire vide si facultatif ; si obligatoire, relever « bloqué / jeu de données de test requis ».
Les formations et référentiels de spécialité ont été créés dans la campagne 04 ; dans les tests ci-dessous, un contenu médical ne doit jamais être présenté comme compétence ECSR, et inversement.
Après chaque validation : recueillir capture avant/après, libellé de l’organisation active, indication visuelle du succès/échec, résultat après actualisation et verdict Réussi / Échoué / Bloqué. Ne pas supposer qu’un écran inaccessible est validé.
La suppression d’un module, le changement de permissions ou de sécurité peut bloquer les autres tests : effectuer ces opérations après les parcours nominaux, puis restaurer la configuration de référence.
15.2. Matrice de données administratives par centre
Compte
Nom court cible
Ville de recette
Libellé visuel / slogan de test
USER-01
Horizon ECSR
Nice
Former à une conduite responsable
USER-02
Azur Deux-Roues
Antibes
Maîtrise et sécurité sur deux roues
USER-03
Provence PL
Marseille
Former à la conduite poids lourds
USER-04
Méditerranée Ambulancier
Toulon
Former aux métiers du transport sanitaire
Ces valeurs sont des données d’essai à saisir via les formulaires disponibles. Pour les couleurs, utiliser quatre jeux de teintes nettement différenciés et relever les valeurs hexadécimales réellement acceptées par le contrôle. Ne pas réutiliser de coordonnées personnelles.
15.3. ADM-01 — Affichage et navigation

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-001 — Accéder à Administration avec la Direction

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given USER-01 est connecté en rôle Direction dans son organisationWhen il clique sur « Administration »Then la page s’ouvre sans erreur et affiche les rubriques accessibles ; l’organisation active du Contexte de travail reste affichée ; aucun contenu d’un autre centre n’apparaîtAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-002 — Indicateurs et liens vers les structures

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given la campagne 04 a créé des structures réelles de recetteWhen il ouvre Administration et active les raccourcis Établissements, Formations, Référentiels et Gestion des accèsThen les compteurs sont cohérents avec les écrans métier, chaque raccourci mène à la bonne page et le contexte reste celui de l’organisation choisieAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-003 — Premier accès sans données métier

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une organisation de test est sélectionnée sans établissement ni formationWhen il ouvre AdministrationThen les sections restent visibles ; les compteurs métier sont à zéro ou en état vide explicite ; aucune entité fictive n’apparaît ; les raccourcis fonctionnentAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-004 — Réouverture après changement d’organisation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given USER-01 a accès aux quatre organisations suite aux invitations croiséesWhen il ouvre Administration dans ECSR, passe au centre Moto via le Contexte de travail puis revientThen les données administratives et indicateurs suivent l’organisation sélectionnée ; aucune valeur ECSR ne reste dans le formulaire Moto et inversementAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.
15.4. ADM-02 — Identité administrative

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-005 — Modifier le nom court et les coordonnées

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given USER-01 est Direction de Horizon ECSR et voit la fiche d’identitéWhen il modifie le nom court et les coordonnées de test valides puis clique EnregistrerThen une confirmation réelle apparaît ; les valeurs sont conservées après rafraîchissement et retour à la page ; le Contexte de travail présente le nom courant si ce champ l’alimenteAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-006 — Vérifier les champs obligatoires

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le formulaire administratif est ouvertWhen il vide successivement les champs signalés obligatoires et tente de sauvegarderThen le formulaire explique les erreurs et ne prétend pas réussir ; les données précédemment valides restent enregistréesAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-007 — Vérifier e-mail, URL et formats numériques

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le formulaire possède les champs e-mail, site Web, code postal, SIRET et déclarationWhen il saisit successivement des valeurs de format manifestement invalideThen les champs soumis à validation refusent le format incorrect avec un message compréhensible ; si une validation n’existe pas, PANDA constate et documente l’anomalie, sans inventer une règleAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-008 — Ne pas inventer d’identifiant officiel

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given aucun numéro SIRET / NDA fictivement valide n’a été attribué par l’équipe de recetteWhen il tente de compléter les informations administratives disponiblesThen il ne renseigne aucun numéro officiel inventé ; si le champ est obligatoire, le scénario est marqué bloqué avec preuve de la contrainteAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-009 — Échec de sauvegarde et absence de faux succès

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une erreur contrôlée de sauvegarde est rencontrée dans l’UI ou l’environnement est indisponibleWhen il tente d’enregistrer une modificationThen l’interface signale l’échec, ne confirme pas une persistance inexistante et conserve ou restitue sans ambiguïté la valeur réellement enregistréeAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-010 — Identité propre à chaque organisation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given les quatre comptes ont accès à leurs organisations de formationWhen chacun modifie le nom court / la ville dans son propre centre puis les quatre comptes se reconnectentThen les quatre fiches demeurent différentes et correctes ; le Contexte de travail de chaque centre reflète uniquement sa propre identitéAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.
15.5. ADM-03 — Identité visuelle

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-011 — Prévisualiser les couleurs

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le panneau Identité visuelle est accessibleWhen il change la couleur principale puis la couleur secondaireThen la prévisualisation réagit avec les valeurs saisies et reste lisible ; aucun changement non sauvegardé ne doit être présenté comme définitifAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-012 — Enregistrer couleurs, libellé du logo et slogan

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given USER-02 travaille dans le centre MotoWhen il saisit des couleurs distinctes, le nom court Azur Deux-Roues et le slogan prévu puis sauvegardeThen les valeurs persistent après actualisation et sont reprises dans l’aperçu ; une autre organisation n’est pas modifiéeAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-013 — Activer puis désactiver la marque blanche

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le paramètre Marque blanche est disponibleWhen il active l’interrupteur, sauvegarde, recharge puis le désactive et sauvegardeThen l’état de l’interrupteur est persistant et l’effet visuel promis par le produit est observable ; sinon PANDA signale un comportement manquantAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-014 — Autoriser la personnalisation par établissement

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un établissement existe et l’option de personnalisation par site est disponibleWhen il active le paramètre puis navigue sur un établissement concernéThen l’état est persisté ; seules les personnalisations de sites prévues par l’UI deviennent possibles ; les établissements des autres organisations ne sont pas impactésAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-015 — Écran détaillé Identité visuelle

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un lien « Identité visuelle » existe dans AdministrationWhen il ouvre le lien /administration/identite-visuelle puis revientThen l’écran spécialisé s’ouvre sans erreur, charge les valeurs de l’organisation active et ne perd ni la sélection ni les modifications sauvegardéesAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-016 — Isolation des quatre identités visuelles

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given les quatre organisations ont enregistré quatre palettes et slogans distinctsWhen USER-01 change d’organisation successivement et inspecte identité et aperçuThen chaque organisme retrouve sa propre palette, son logo texte et son slogan, y compris après déconnexion / reconnexionAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.
15.6. ADM-04 — Activation et désactivation des modules

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-017 — Afficher la liste des modules configurables

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given USER-01 a ouvert AdministrationWhen il parcourt la section ModulesThen les modules affichés correspondent à la configuration effective ; PANDA relève la présence de Planning, Présences, Séances, Conduite, Plateau, Fiches, Compétences, Stages, Documents, Certification et Statistiques lorsqu’ils sont proposésAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-018 — Désactiver un module pour une organisation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given le module choisi est actif et aucun autre scénario dépendant n’est en coursWhen USER-01 désactive par exemple Statistiques depuis ECSRThen le changement est confirmé dans l’UI ; après rafraîchissement, le module reste désactivé et son accès est restreint conformément aux règles du produit, y compris par navigation directeAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-019 — Réactiver un module

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given Statistiques a été désactivé pour ECSRWhen USER-01 réactive ce moduleThen son accès est à nouveau possible avec les permissions initiales ; aucune donnée métier n’a été effacée et le Contexte de travail reste correctAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-020 — Modules indépendants entre organisations

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given USER-01 est membre de ECSR et MotoWhen il désactive un module dans ECSR puis sélectionne MotoThen l’état du module dans Moto reste identique à sa valeur initiale ; le changement de contexte actualise les modules ; le module ECSR est réactivé en fin de testAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-021 — Module désactivé et lien direct

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un module est désactivé pour l’organisation activeWhen il tente d’ouvrir le module par un raccourci, favoris ou URL connue depuis l’interfaceThen l’utilisateur ne peut pas utiliser les fonctionnalités interdites ; l’application fournit une explication et ne révèle aucune donnée d’une autre organisationAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-022 — Persistance et double-clic d’un interrupteur

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un module possède un interrupteur modifiableWhen il effectue deux modifications successives puis recharge l’interfaceThen l’état final reflète la dernière modification confirmée et le panneau ne montre ni faux succès ni état incohérentAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.
15.7. ADM-05 — Fiches et compétences pédagogiques

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-023 — Accès aux fiches sans formation sélectionnée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given le Contexte de travail ne contient aucune formation activeWhen il tente d’ouvrir la configuration des fiches pédagogiquesThen l’application demande une sélection valide ou désactive l’action ; aucune fiche ne peut être rattachée à une formation inexistanteAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-024 — Accès aux compétences sans référentiel

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une formation de test est sélectionnée sans version de référentiel exploitableWhen il tente d’accéder à la configuration des compétencesThen un blocage explicite s’affiche ; aucune compétence issue d’un autre référentiel n’est utilisée par défautAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-025 — Ouvrir les fiches et compétences avec contexte complet

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une formation, un référentiel et une promotion valides du centre ECSR existentWhen il ouvre successivement /administration/fiches et /administration/competencesThen les écrans chargent uniquement les ressources du contexte choisi ; les outils d’édition prévus sont accessibles selon les droitsAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-026 — Séparer référentiels ECSR, Moto, PL et Ambulancier

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given les quatre spécialités disposent de référentiels distincts créés en campagne 04When il change de centre et ouvre les fiches puis les compétencesThen les intitulés, listes et relations dépendent de la formation active ; aucune fiche « 58 thèmes ECSR » ne doit être imposée à la formation AmbulancierAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-027 — Modification pédagogique et rafraîchissement

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un élément de fiche / compétence modifiable est affiché pour une formation donnéeWhen il modifie un champ non critique, sauvegarde puis recharge l’écranThen la donnée modifiée est conservée pour la bonne formation et apparaît dans les écrans qui l’utilisent, sans altérer les autres référentielsAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-028 — Interdire l’édition hors périmètre pédagogique

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given USER-01 est Jury ou Formateur dans une organisation secondaire sans permission administrative de référentielWhen il tente d’ouvrir ou de modifier une fiche / compétence via l’UIThen les actions d’administration non autorisées sont absentes ou refusées, sans possibilité de modification effectiveAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.
15.8. ADM-06 — Paramètres généraux, langues et dates

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-029 — Enregistrer langue et format de date

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given l’onglet Général est accessibleWhen il sélectionne FR puis EN et change le format de date depuis les contrôles disponiblesThen les préférences sont enregistrées et restaurées après actualisation ; les libellés visibles sont traduits, sans clés techniques exposéesAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-030 — Fuseau horaire et année scolaire

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le formulaire Général contient fuseau horaire et année scolaireWhen il modifie ces valeurs à l’aide des contrôles et sauvegarde lorsque le bouton existeThen les valeurs restent correctes après rechargement ; les dates affichées respectent le paramétrage prévu sans changer les dates métier enregistréesAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-031 — Préférences propres à l’organisation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given les quatre centres ont accès aux paramètres générauxWhen il sélectionne des préférences différentes dans ECSR et Ambulancier puis alterne les contextesThen les paramètres retrouvés sont ceux de l’organisation active ; un paramètre de l’une ne remplace pas celui de l’autreAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.
15.9. ADM-07 — Notifications, sécurité et permissions

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-032 — Paramètres de notifications

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given l’onglet Notifications est visibleWhen il active puis désactive une préférence et recharge la pageThen l’état sauvegardé est retrouvé ; si l’action prétend déclencher une notification réelle, PANDA en vérifie l’effet uniquement par l’UI disponibleAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-033 — Paramètres de sécurité

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given l’onglet Sécurité est visible et le compte possède les droits requisWhen il modifie une préférence autorisée puis vérifie sa persistanceThen la nouvelle politique s’affiche correctement et son effet sur une action concernée est observable ; aucun accès interdit n’est accordé automatiquementAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-034 — Rôle secondaire sans droit administrateur

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given USER-01 travaille dans une organisation où il possède un rôle Jury, Formateur ou Secrétariat sans permission AdministrationWhen il tente d’ouvrir Administration, de modifier une préférence puis de naviguer directement à une sous-pageThen les actions interdites sont cachées ou refusées ; aucun succès de sauvegarde n’apparaît ; les paramètres de cette organisation ne changent pasAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-035 — Refus et panne réseau pendant sauvegarde

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un message d’erreur survient lors de l’enregistrement de préférencesWhen l’utilisateur tente l’opération puis actualiseThen un refus ou une erreur est présenté sans faux succès ; les anciennes préférences restent identifiables et aucun changement fantôme n’est affichéAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.
15.10. ADM-08 — Télétravail

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-036 — Afficher la politique de télétravail

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P2  •  Type : E2E UI  •  Environnement : staging
Given l’administration du centre est ouverteWhen il repère la section Télétravail et le lien /teletravailThen la politique, ses options et la valeur de jours maximum sont visibles, avec un état vide ou par défaut compréhensibleAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-037 — Enregistrer et valider les jours maximum

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given la politique de télétravail peut être éditéeWhen il modifie le nombre maximal de jours et tente une valeur hors des bornes admises par le contrôleThen la valeur valide persiste et l’entrée invalide est refusée sans faux succès ; la page Télétravail affiche une politique compatibleAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-038 — Télétravail propre à chaque organisation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given ECSR et Moto disposent de paramètres différentsWhen il change d’organisation depuis le Contexte de travail puis revientThen chaque politique et son nombre maximum restent propres à l’organisation ; les préférences ne se mélangent pasAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.
15.11. ADM-09 — Journal d’audit et export

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-039 — Afficher un journal initialement vide

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given aucune action de recette traçable n’a encore été effectuée dans l’organisation sélectionnéeWhen il ouvre Journal d’auditThen le tableau et ses colonnes Action, Acteur, Détail, Date sont visibles avec un état vide honnête ; aucune fausse activité n’apparaîtAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-040 — Traçabilité des changements administratifs

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given USER-01 vient de sauvegarder une modification administrativeWhen il consulte le journal d’audit, puis actualiseThen si ce type d’action est audité par le produit, l’entrée apparaît avec le bon acteur, la bonne organisation et un horodatage lisible ; en cas d’absence, PANDA signale l’écart à la règle attendueAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-041 — Exporter le journal

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le bouton Exporter est accessibleWhen il déclenche l’export depuis le navigateurThen un fichier est proposé ou téléchargé, son contenu correspond aux lignes et filtres affichés et n’expose pas de journal d’une autre organisationAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-042 — Isolation des journaux

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given des actions distinctes ont été réalisées dans ECSR et MotoWhen USER-01 alterne les deux organisations et consulte Journal d’auditThen les actions propres à chacune restent séparées ; les dates et acteurs se rapportent uniquement à l’organisation affichéeAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.
15.12. ADM-10 — Contrôles transversaux

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-043 — Quatre centres, quatre configurations complètes

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given les champs et options prévus ont été renseignés séparément dans les quatre centresWhen PANDA ouvre Administration pour chaque compte Direction puis fait une reconnexionThen l’identité, les préférences, les modules et les informations affichées correspondent au centre actif, sans contamination entre ECSR, Moto, Poids lourds et AmbulancierAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-044 — Retour à l’organisation précédente

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given USER-01 a des appartenances aux quatre organisations avec rôles différentsWhen il navigue ECSR → Moto → Poids lourds → Ambulancier → ECSR depuis le Contexte de travailThen les informations chargées correspondent à chaque organisation et le retour ECSR restitue sa dernière configuration enregistréeAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-045 — Mise à jour après actualisation et session croisée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given USER-01 administre ECSR tandis qu’un compte autorisé consulte ECSR dans un autre navigateurWhen USER-01 sauvegarde un paramètre puis l’autre session recharge la pageThen la seconde session observe la configuration enregistrée selon ses permissions ; aucune configuration périmée n’est présentée comme définitiveAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## ADM-UI-046 — Restaurer le jeu de données de recette

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given les tests de blocage, modules et sécurité sont terminésWhen PANDA rétablit les modules utiles, les autorisations de travail et les valeurs administratives ciblesThen les quatre comptes Direction peuvent poursuivre les autres campagnes ; les quatre Contexte de travail restent valides ; aucun compte n’est bloqué par les tests AdministrationAnd PANDA vérifie le Contexte de travail, l’état après actualisation et l’absence de données d’une autre organisation lorsque pertinent.
Preuve : capture écran avant/après ; organisation et rôle sélectionnés ; message ou blocage visible ; retour après rechargement.Verdict : À exécuter — Réussi / Échoué / Bloqué ; ticket anomalie si nécessaire.
15.13. Critères de sortie — Administration
Les 46 scénarios Administration ont été exécutés ou marqués Bloqués avec raison et capture ; aucun « succès » n’est déduit d’une simple notification visuelle.
Les paramètres des quatre centres sont indépendants ; changements d’organisation et de rôle rechargent les données et les possibilités de modification du bon périmètre.
Toutes les sauvegardes vérifiées restent persistées après rafraîchissement ; les échecs n’affichent pas un succès fictif.
Les fonctionnalités cachées, absentes ou non raccordées dans l’interface ne sont pas inventées : elles donnent lieu à un résultat Bloqué ou à une anomalie selon la spécification validée.
Les actions privilégiées sont impossibles pour les rôles secondaires sans autorisation ; les comptes Direction principaux sont conservés.
Les paramètres destructifs de test sont restaurés ; les quatre comptes ont Demo@123 et leur organisation principale reste accessible.
Aucune anomalie critique P0 ouverte avant validation de la campagne. Statut actuel : scénarios rédigés, non exécutés.
SUITE DU CAHIER : campagne 09 — Promotions (scénarios fonctionnels ci-après).

16. Campagne 09 — Promotions : recette fonctionnelle complète
Objectif : valider depuis l’interface utilisateur la consultation, la création, la gestion, la copie, les inscriptions, les droits et la séparation des promotions sur les quatre organisations de recette. Tous les scénarios sont à exécuter ; aucun résultat n’est présumé acquis.
16.1. Données de référence et règles de recette
Compte Direction
Organisation de recette
Promotion A de référence
Capacité
USER-01
Centre Horizon ECSR — Nice
ECSR 2027 — Session A
16
USER-02
Académie Azur Deux-Roues — Antibes
Enseignants Moto 2027 — Session A
12
USER-03
Institut Provence Poids Lourds — Marseille
Enseignants Groupe Lourd 2027 — Session A
14
USER-04
Institut Méditerranée Ambulancier — Toulon
DEA 2027 — Session A
20
Comptes de connexion : sam.user1@email.com, sam.user2@email.com, sam.user3@email.com et sam.user4@email.com ; mot de passe initial et final Demo@123. Les invitations croisées de la campagne 06 sont conservées.
Préconditions : au démarrage de cette campagne, la configuration progressive a créé pour chaque organisation au moins un établissement, une formation correspondante, un référentiel de cette formation et un responsable pédagogique éligible. Sinon, exécuter d’abord les tests de blocage des prérequis.
Jeu de données synthétique et réaliste : aucun nom d’établissement fictif ne doit être présenté comme accrédité ; les capacités sont des valeurs de test et non des prescriptions réglementaires. Utiliser des dates de début et de fin futures cohérentes, espacées de plusieurs mois, et enregistrer les valeurs exactes réellement saisies.
Principe UI : effectuer les actions via les menus, boutons, drawers et sélecteurs. Une action absente de l’interface doit être signalée Bloquée/Écart fonctionnel, sans substitution par une requête API.
Règle transversale : après chaque création/modification/copie/suppression/affectation, vérifier les listes, indicateurs et le Contexte de travail (Organisation > Établissement > Formation > Promotion), puis actualiser la page pour contrôler la persistance.
Les tests perturbateurs (capacité pleine, suppression, suspension, changement de rôle) s’effectuent sur des promotions B dédiées ou se concluent par la restauration de la configuration, afin de préserver les quatre promotions A de référence.
16.2. PRO-01 — État initial, indicateurs et filtres

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-001 — Ouvrir Promotions avec une liste vide

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given la Direction est connectée et aucune promotion n’existe dans sa formationWhen elle ouvre Promotions depuis la navigationThen l’écran reste visible, affiche zéro donnée métier sans carte fictive et propose les commandes prévues
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-002 — Contrôler les rubriques et états vides

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le menu Promotions est ouvert dans une formation sans promotionWhen elle parcourt les indicateurs et les filtres Toutes, Actives, Planifiées et TerminéesThen chaque filtre reste utilisable ; les indicateurs correspondent à zéro ; aucun message de réussite ni faux enregistrement
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-003 — Rechercher ou filtrer sans résultat

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P2  •  Type : E2E UI  •  Environnement : staging
Given une promotion A existe et un filtre ne correspond à aucune promotionWhen PANDA applique chaque filtre disponible puis revient à ToutesThen la liste reflète le filtre actif et la promotion A réapparaît dans Toutes sans doublon
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-004 — Consulter une carte de promotion

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given la promotion A existe dans le Contexte de travail adéquatWhen PANDA ouvre sa carte ou son détailThen nom, statut, dates, établissement, formation, référentiel, responsable et compteurs présents sont cohérents avec les données saisies
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.
16.3. PRO-02 — Création et prérequis obligatoires

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-005 — Bloquer la création sans établissement

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une organisation ne dispose pas encore d’établissement actifWhen PANDA ouvre Créer une promotionThen le parcours empêche de choisir un établissement inexistant et explique le prérequis sans enregistrer de promotion
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-006 — Bloquer la création sans formation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un établissement existe, mais aucune formation n’y est disponibleWhen PANDA tente de créer une promotionThen la formation absente n’est pas substituée par une valeur fictive ; une erreur explicite empêche la création
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-007 — Bloquer la création sans référentiel

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une formation existe sans version de référentiel compatibleWhen PANDA ouvre Créer une promotion et cherche la version du référentielThen aucune version étrangère ou inventée n’est proposée et la validation est bloquée
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-008 — Responsable pédagogique obligatoire et éligible

Verdict : PASS

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given la formation ne possède pas de responsable pédagogique éligibleWhen PANDA tente de remplir et de soumettre le formulaireThen le responsable ne peut être inventé ; la création est bloquée ou le prérequis est signalé suivant la règle métier, sans succès fictif
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : Horizon/siteHORIZ-QA-01/programECSR Draft : aucun responsable éligible ; formulaire rempli sans responsable ne crée aucune promotion, aucun faux succès. Défaut UX distinct task18.

Test : test-10 ; anomalie : task-18

Preuves : cohort-manager-silent.png

## PRO-UI-009 — Versions et responsables filtrés

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given la formation et plusieurs versions/rôles existent dans des organisations différentesWhen PANDA ouvre les listes Référentiel et Responsable pédagogiqueThen seules les options compatibles avec la formation et l’organisation du Contexte de travail sont proposées
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-010 — Contrôles de saisie obligatoires

Verdict : FAIL

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le formulaire Créer une promotion est ouvertWhen PANDA laisse le nom vide et soumet, puis renseigne successivement les champs requisThen chaque omission est signalée dans l’UI ; aucun enregistrement incomplet n’apparaît dans la liste
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : Nom/dates/effectif signalés à vide ; après saisie valide et responsable absent, Create cohort reste actif mais clic silencieux, aucun marqueur ni message, aucune requête de création. Pas de promotion créée.

Test : test-10 ; anomalie : task-18

Preuves : cohort-manager-silent.png

## PRO-UI-011 — Dates incohérentes

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given le formulaire est accessibleWhen PANDA choisit une fin antérieure au début puis tente de validerThen la saisie est rejetée ou corrigée explicitement et aucune promotion invalide n’est créée
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-012 — Capacité invalide

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given le formulaire est accessibleWhen PANDA tente une capacité négative, nulle, non numérique et trop grande si une limite est affichéeThen les valeurs non admissibles sont rejetées avec un message compréhensible ; aucune persistance invalide
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-013 — Créer les quatre promotions A

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given les quatre centres disposent chacun des prérequis pédagogiques et responsablesWhen PANDA se connecte successivement comme Direction de chaque centre et crée la promotion A avec son nom et sa capacité de référenceThen quatre promotions différentes sont créées une seule fois, chacune dans la bonne organisation et le bon contexte ; elles persistent après actualisation
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-014 — Créer deux sessions dans une formation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given la promotion A ECSR existe et les prérequis restent validesWhen PANDA crée dans ECSR une promotion B avec un autre nom, d’autres dates et un responsable de promotion éligible si disponibleThen les promotions A et B coexistent, gardent leurs paramètres et sont visibles dans le bon filtre
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-015 — Ne pas modifier le responsable global de formation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une formation a un responsable défini et un responsable distinct est disponible pour une promotionWhen PANDA crée ou affecte une promotion sous le second responsable puis consulte la formationThen le responsable de formation reste inchangé ; les deux responsabilités ne sont pas confondues
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-016 — Éviter les doubles créations

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un formulaire complet est prêt à être validéWhen PANDA double-clique sur Enregistrer ou reproduit une soumission rapide puis revient à la listeThen une action unique n’entraîne pas de doublons et l’UI indique correctement le résultat
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.
16.4. PRO-03 — Modification et cycle de vie

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-017 — Trouver la commande de modification

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une promotion B sans inscription est présenteWhen PANDA cherche depuis son détail, sa carte ou le menu d’actions une commande ModifierThen la commande ouvre le formulaire et reflète les valeurs existantes, ou son absence est consignée comme écart fonctionnel
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-018 — Modifier les propriétés autorisées

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given la commande Modifier est visible pour une promotion BWhen PANDA change le nom, les dates et la capacité dans les bornes autorisées et enregistreThen la carte et le détail présentent les nouvelles valeurs après fermeture et actualisation
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-019 — Annuler une modification

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P2  •  Type : E2E UI  •  Environnement : staging
Given PANDA a ouvert l’édition d’une promotion BWhen il modifie un champ puis ferme ou annule sans confirmerThen la donnée demeure inchangée et aucune notification de succès ne s’affiche
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-020 — Statut planifiée, active, terminée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given des promotions tests ont des dates compatibles avec chaque état ou une action de statut autorisée existeWhen PANDA examine les cartes et change un statut uniquement si l’UI le permetThen le statut affiché concorde avec la règle métier et les filtres ; les transitions interdites sont bloquées
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-021 — Préserver les données après erreur d’enregistrement

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given la promotion B est éditableWhen PANDA provoque une validation invalide et tente de sauvegarderThen l’UI explique l’échec, ne montre pas de faux succès et conserve les anciennes données après actualisation
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.
16.5. PRO-04 — Copie et duplication

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-022 — Ouvrir la copie de promotion

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une promotion A existe et le rôle le permetWhen PANDA utilise Copier une promotionThen un panneau présente les champs de destination, nom/code, dates, capacité et responsable, sans exécuter immédiatement la copie
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-023 — Copier dans un établissement compatible

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given deux établissements du même centre proposent la même formation et un responsable éligible existeWhen PANDA copie la promotion A vers un autre établissement en adaptant nom, dates et capacitéThen la nouvelle promotion apparaît dans l’établissement de destination, sans modifier l’original, et le contexte est cohérent
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-024 — Refuser une destination incompatible

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un établissement ne propose pas la formation de la promotion sourceWhen PANDA cherche cette destination dans le formulaire CopierThen l’UI ne permet pas de valider une copie incompatible ou affiche un refus clair sans création
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-025 — Pas de copie inter-organisation non autorisée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given USER-01 est membre de plusieurs organisationsWhen PANDA tente depuis ECSR de sélectionner une destination du centre Moto dans CopierThen aucun établissement de l’autre tenant non autorisé n’est sélectionnable ; aucune ressource croisée n’est créée
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-026 — Vérifier les doublons lors de la copie

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une promotion a déjà été copiée avec un identifiant/code métier donnéWhen PANDA réessaie de copier avec le même code si ce champ est uniqueThen l’application respecte les contraintes d’unicité, explique l’échec et ne crée pas de doublon
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.
16.6. PRO-05 — Stagiaires et capacité

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-027 — Inscrire un stagiaire dans une promotion

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une promotion A existe et un stagiaire éligible appartient à la même organisationWhen PANDA utilise le parcours d’inscription depuis le menu Stagiaires ou la promotionThen la promotion affiche le stagiaire, son compteur augmente et le Contexte de travail reste correct
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-028 — Bloquer une inscription étrangère

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un stagiaire existe dans le centre Moto et une promotion existe dans ECSRWhen PANDA cherche à inscrire le stagiaire Moto à ECSR sans transfert autoriséThen le stagiaire étranger n’est pas proposé ou l’opération est refusée, sans mélange des listes
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-029 — Ne pas dépasser la capacité

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une promotion B de capacité 2 contient déjà deux stagiaires actifsWhen PANDA tente d’inscrire un troisième stagiaire via l’UIThen l’ajout est refusé avec explication et la capacité affichée reste respectée
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-030 — Suivre la disponibilité après retrait

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une promotion B de capacité 2 est pleineWhen PANDA retire ou réaffecte un stagiaire via l’action autorisée puis inscrit un autre stagiaireThen les compteurs et places disponibles reflètent les opérations enregistrées, y compris après actualisation
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.
16.7. PRO-06 — Suppression et dépendances

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-031 — Supprimer une promotion de test vide

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une promotion B ne contient ni stagiaire ni séance ni dépendance bloquanteWhen PANDA utilise Supprimer, confirme et rechargeThen la promotion B disparaît des listes et des choix de contexte, sans affecter la promotion A
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-032 — Annuler la confirmation de suppression

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P2  •  Type : E2E UI  •  Environnement : staging
Given une promotion test peut être suppriméeWhen PANDA clique Supprimer puis Annuler dans la confirmationThen aucune donnée n’est supprimée ; la promotion reste visible après actualisation
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-033 — Bloquer la suppression avec dépendances

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une promotion contient des inscriptions ou séancesWhen PANDA tente SupprimerThen la suppression est bloquée ou traitée conformément à une règle explicite sans données orphelines ; l’UI montre l’explication
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-034 — Contexte actif après suppression

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une promotion B est sélectionnée et peut être suppriméeWhen PANDA la supprime depuis l’interfaceThen le sélecteur ne conserve pas la promotion supprimée ; les niveaux parents restent cohérents
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.
16.8. PRO-07 — Permissions selon les rôles

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-035 — Direction de l’organisation principale

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given chaque compte principal est Direction de son propre centreWhen PANDA ouvre Promotions, crée et gère une promotion test selon ses permissionsThen les actions attendues pour Direction sont disponibles et fonctionnent uniquement dans le bon périmètre
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-036 — Rôle secondaire dans une autre organisation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given USER-01 est membre du centre Moto avec un rôle différent de DirectionWhen PANDA sélectionne Moto, ouvre Promotions et tente les actions de création/modification/suppressionThen les actions suivent les permissions du rôle Moto, sans hériter des droits de Direction ECSR
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-037 — Accès interdit depuis une URL directe

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un utilisateur ne possède pas la permission de gérer les promotions dans une organisationWhen PANDA ouvre directement une URL de création ou de détail protégéeThen l’écran bloque ou limite les opérations sans permettre de contournement par la navigation directe
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.
16.9. PRO-08 — Multi-organisation et Contexte de travail

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-038 — Changer entre les quatre organisations

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given les invitations croisées sont acceptées et chaque centre possède une promotion AWhen USER-01 change ECSR → Moto → Poids lourds → Ambulancier → ECSRThen chaque liste et sélection de promotion correspond au centre courant et aucune promotion étrangère ne subsiste
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-039 — Changer établissement et formation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une organisation possède plusieurs établissements et formationsWhen PANDA change de site puis de formation dans le Contexte de travailThen la promotion sélectionnée est effacée si elle n’appartient plus au contexte et les listes se réactualisent
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-040 — Restaurer une sélection valide après reconnexion

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given USER-01 a choisi une promotion et dispose de plusieurs organisationsWhen PANDA actualise puis se déconnecte et se reconnecteThen le contexte restauré ou demandé est autorisé, jamais celui d’une organisation inaccessible
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-041 — Contrôler les indicateurs par organisation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given chaque centre a des capacités et effectifs différentsWhen PANDA compare les cartes et indicateurs lors des changements d’organisationThen les totaux et listes sont recalculés selon le centre actif, sans addition d’un autre tenant
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.
16.10. PRO-09 — Indicateurs et rafraîchissement

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-042 — Mettre à jour après création

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une liste Promotions est ouverteWhen PANDA crée une promotion valide via l’UI puis ferme le formulaireThen la carte et les compteurs se mettent à jour sans nécessiter de rafraîchissement manuel et persistent après F5
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-043 — Mettre à jour après inscription

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une promotion A est visible dans le menu PromotionsWhen PANDA inscrit un stagiaire depuis le menu Stagiaires puis revient à PromotionsThen le compteur de stagiaires et le détail reflètent l’inscription enregistrée
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-044 — Cohérence des compteurs heures et progression

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given des séances, présences et évaluations ont été enregistrées dans la promotion testWhen PANDA ouvre la promotion et compare les compteurs aux données métier des écrans concernésThen les heures, l’assiduité, la progression et le reste à rattraper, lorsqu’ils sont exposés, sont cohérents et non fictifs
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-045 — Rechargement sur un deuxième navigateur

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given la même promotion est consultée par deux utilisateurs autorisés de la même organisationWhen l’un effectue une modification puis l’autre recharge sa pageThen la seconde session affiche la modification confirmée, avec les bons droits et le même contexte
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRO-UI-046 — Rejet d’une action sans faux succès

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un champ invalide ou un prérequis manquant empêche une action sur la promotion BWhen PANDA soumet l’action bloquée puis consulte la listeThen aucune notification de réussite trompeuse ni modification persistée ; l’erreur reste compréhensible
Preuve : capture de la page avant/après ; organisation, établissement, formation et promotion sélectionnés ; notification ou message affiché ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable ; anomalie et capture si nécessaire.
16.11. Critères de sortie — Promotions
Les 46 scénarios Promotions doivent être exécutés ou justifiés comme Bloqués/Non applicables avec preuve et référence du défaut.
Les quatre promotions A existent en fin de campagne, liées aux quatre bonnes organisations, aux formations et aux référentiels corrects.
Les promotions B servant aux tests destructifs ont été nettoyées, ou leur présence et leur état sont précisément documentés.
Toute action métier est confirmée par un changement observable, cohérent dans les autres menus et persistant après actualisation.
Aucun mélange de promotions, utilisateurs, responsables ou référentiels n’est observé lors du changement d’organisation et de Contexte de travail.
Les créations sans prérequis, les dépassements de capacité, les modifications non autorisées et les suppressions interdites sont refusées correctement.
Les fonctionnalités de modification, de copie ou de suppression non exposées dans l’UI sont marquées Bloquées/Écart fonctionnel, pas inventées.
Les quatre comptes Direction restent utilisables avec Demo@123, sans retrait des invitations croisées et avec leurs données de référence intactes.
Statut : campagne rédigée, non exécutée. Aucun menu ne peut être déclaré validé sans résultats d’exécution.
Étape suivante : menu Stagiaires (chapitre 17).

17. Campagne 09 — Stagiaires : parcours fonctionnels complets
Périmètre : navigation UI, création/invitation, rattachement, dossier individuel, progression, statut, contrôles métier et isolation des quatre organisations. Les tests sont rédigés, NON exécutés.
Précondition commune : les comptes USER-01 à USER-04 sont Direction de leurs centres respectifs ; les quatre centres, établissements, formations, référentiels et promotions A existent après les campagnes 04–08. Les invitations croisées ont été acceptées pour les tests multi-organisations. Aucun stagiaire métier n’est présent avant la création des jeux de données de cette campagne (hors éventuelles données de recette des campagnes antérieures, à nettoyer ou répertorier).
Règle commune : chaque opération impliquant une inscription ou un rattachement déclenche un contrôle du Contexte de travail. Vérifier l’actualisation sans rechargement manuel, puis la persistance après actualisation ; ne jamais utiliser une réponse HTTP/DB comme seule preuve. Si une fonctionnalité n’existe pas dans l’UI, consigner Bloqué / Écart fonctionnel, sans inventer un bouton.
17.1. Jeu de données réaliste et traçable
Organisation / compte
Promotion A
Apprenant 1 (e-mail)
Apprenant 2 (e-mail)
USER-01 · Horizon ECSR · Nice
ECSR 2027 — Session A
Camille Martincamille.martin.ecsr@qa.example
Lina Bernardlina.bernard.ecsr@qa.example
USER-02 · Azur Deux-Roues · Antibes
Enseignants Moto 2027 — Session A
Nolan Perrinnolan.perrin.moto@qa.example
Inès Vidalines.vidal.moto@qa.example
USER-03 · Provence Poids Lourds · Marseille
Enseignants Groupe Lourd 2027 — Session A
Adam Moreladam.morel.pl@qa.example
Sarah Fabresarah.fabre.pl@qa.example
USER-04 · Méditerranée Ambulancier · Toulon
DEA 2027 — Session A
Emma Rouxemma.roux.dea@qa.example
Yanis Lambertyanis.lambert.dea@qa.example
Ces identités, domaines qa.example et centres sont fictifs. Ne pas attribuer les comptes USER-01 à USER-04 au rôle Stagiaire ; ils servent à tester les rôles Direction et les appartenances croisées. Les huit apprenants ci-dessus restent dans leurs promotions A pour les campagnes ultérieures. Utiliser des apprenants temporaires distincts pour les tests de suppression et de capacité.
17.2. STG-01 — État initial, recherche et filtres

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-001 — Ouvrir un menu vide

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given USER-01 est connecté à Horizon ECSR et aucun stagiaire n’est encore inscritWhen PANDA ouvre StagiairesThen la page est accessible, ses filtres et son action Ajouter un stagiaire sont visibles ; aucun stagiaire fictif n’est listé ; les indicateurs/compteurs restent cohérents
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-002 — Afficher les promotions autorisées

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given la promotion A ECSR existe dans le centre actifWhen PANDA ouvre le filtre PromotionThen seules les promotions de la formation et de l’organisation autorisées sont proposées ; aucune promotion Moto/PL/DEA n’est visible
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-003 — Bloquer l’ajout sans promotion

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une organisation ou formation ne possède aucune promotion admissibleWhen PANDA ouvre Ajouter un stagiaire et essaie de validerThen l’absence de promotion est expliquée et aucun stagiaire ni inscription n’est créé
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-004 — État vide après recherche

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given la liste Stagiaires est vide ou aucun stagiaire ne correspondWhen PANDA recherche un nom inexistantThen un état vide explicite apparaît, sans carte fictive ni erreur bloquante
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-005 — Afficher compteur et filtres

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given les deux apprenants du centre ECSR sont créésWhen PANDA compare le total affiché, filtre une promotion et efface les filtresThen les cartes visibles et les compteurs correspondent aux seules données du contexte choisi
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-006 — Rechercher nom et courriel

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given les deux stagiaires ECSR existentWhen PANDA recherche successivement Camille, Bernard et des fragments d’e-mail si la recherche les accepteThen les résultats correspondent aux critères supportés, puis reviennent à la liste complète après effacement
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-007 — Filtrer sur statuts pédagogiques

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given au moins deux stagiaires présentent des statuts de progression différentsWhen PANDA utilise les filtres de statut disponibles (bon, vigilance, retard)Then les cartes obtenues respectent le statut affiché ; aucun résultat d’une autre organisation n’apparaît
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________
17.3. STG-02 — Création, invitation et validations

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-008 — Créer les huit apprenants de référence

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given chaque compte Direction a sélectionné son organisation, établissement, formation et promotion AWhen PANDA crée les deux apprenants correspondant à chacun des quatre centres avec identité, e-mail et date de débutThen chaque profil apparaît une seule fois dans la bonne promotion ; la carte et le contexte reflètent le rattachement ; les huit profils restent accessibles après actualisation
Précision QA : L’invitation et l’inscription sont deux états distincts : documenter explicitement le statut visible au terme de la création.
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-009 — Valider les champs obligatoires

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le panneau Ajouter un stagiaire est ouvertWhen PANDA laisse prénom, nom, e-mail, promotion ou date de début vides puis soumetThen les champs requis sont signalés individuellement ; aucune invitation ni inscription n’est confirmée
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-010 — Refuser une adresse e-mail mal formée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le formulaire est ouvertWhen PANDA saisit successivement une adresse sans @, sans domaine et une chaîne invalideThen le formulaire refuse l’enregistrement et explique le champ incorrect
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-011 — Tester normalisation du courriel

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une adresse de recette n’est pas encore utiliséeWhen PANDA saisit un e-mail avec majuscules et espaces périphériques lorsque l’UI le permetThen un seul compte logique est retenu et une nouvelle tentative avec la forme normalisée ne crée pas de doublon
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-012 — Empêcher le double clic de création

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un formulaire valide de stagiaire temporaire est prêtWhen PANDA clique rapidement deux fois sur Enregistrer / InviterThen un seul résultat métier est créé ; le bouton est neutralisé ou l’opération idempotente ; aucun doublon en liste
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-013 — Refuser un doublon dans la même promotion

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given Camille Martin existe dans ECSR AWhen PANDA tente d’ajouter Camille avec le même e-mail dans la même promotionThen l’interface signale la situation et n’ajoute pas une seconde inscription identique
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-014 — Réutiliser une identité existante sans doublon

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un e-mail existe déjà dans AuthGate ou une autre organisation, sous réserve de disponibilité du flux UIWhen PANDA tente de l’inscrire dans une promotion admissibleThen le parcours réutilise l’identité ou indique explicitement l’action autorisée ; aucune seconde identité globale n’est créée
Précision QA : Vérifier la distinction identité AuthGate / profil d’apprenant / inscription à une promotion.
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-015 — Annuler le panneau d’ajout

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le formulaire contient des informations non enregistréesWhen PANDA clique Annuler ou ferme le panneauThen aucun nouveau stagiaire ni invitation n’apparaît après rechargement
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-016 — Changer de contexte avant la validation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given le formulaire est ouvert pour ECSR AWhen PANDA change de formation ou de promotion avant soumission, si l’interface le permetThen une promotion devenue hors contexte n’est pas acceptée ; aucun rattachement implicite incorrect n’est enregistré
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-017 — Créer sans envoi d’e-mail si l’option existe

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le formulaire propose l’interrupteur Envoyer une invitationWhen PANDA crée un apprenant de test avec cette option désactivée, puis avec cette option activéeThen le résultat visible distingue correctement profil créé et invitation envoyée ou en attente ; aucun faux succès
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-018 — Capacité atteinte

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une promotion temporaire de capacité 2 contient déjà deux inscriptions activesWhen PANDA tente d’ajouter un troisième stagiaireThen le dépassement est refusé avec message compréhensible, sans création d’inscription supplémentaire
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-019 — Retirer la dernière place disponible puis réinscrire

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une promotion temporaire est pleine et un retrait autorisé a libéré une placeWhen PANDA inscrit un autre apprenant temporaireThen l’inscription réussit sur une place disponible et les effectifs sont mis à jour
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________
17.4. STG-03 — Dossiers individuels et onglets

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-020 — Ouvrir le dossier depuis une carte

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given Camille existe dans le contexte ECSRWhen PANDA clique sa carte dans StagiairesThen le dossier affiché possède la bonne identité, le bon courriel, la bonne promotion et les dates de parcours
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-021 — Vérifier synthèse et progression initiale

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given le dossier d’un stagiaire nouvellement inscrit est ouvert et aucune séance n’a été effectuéeWhen PANDA consulte l’onglet Vue d’ensembleThen les heures effectuées, validations, évaluations et progrès partent des valeurs initiales réelles ; aucun historique fictif
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-022 — Vérifier l’onglet Heures

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un stagiaire possède une répartition d’heures prévue par la formationWhen PANDA consulte les heures prévues, réalisées, restantes et à rattraperThen les totaux et catégories sont cohérents, sans valeurs négatives ni heures inventées
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-023 — Vérifier l’onglet Conduite

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given aucune séance pratique n’est enregistrée pour le stagiaireWhen PANDA ouvre l’onglet ConduiteThen l’historique est vide ou affiche un état explicite ; aucune observation d’un autre apprenant n’est affichée
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-024 — Vérifier l’onglet Compétences

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given le stagiaire est inscrit à une promotion liée à un référentielWhen PANDA ouvre CompétencesThen les compétences proviennent du bon référentiel métier et les niveaux initiaux sont non évalués ou à zéro selon les libellés métier
Précision QA : Le référentiel Ambulancier ne doit pas afficher les 58 fiches ECSR comme s’il s’agissait du même programme.
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-025 — Vérifier l’onglet Fiches

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le dossier est initialement sans fiche évaluéeWhen PANDA ouvre Fiches / Exposés dans le dossierThen les fiches éventuellement définies par le référentiel sont visibles dans l’état initial ; aucune date de présentation ou validation fictive
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-026 — Vérifier l’onglet Présences

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given aucun appel n’a été réalisé pour ce stagiaireWhen PANDA ouvre PrésencesThen aucune absence ou retard inventé ; compteurs et historique cohérents
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-027 — Vérifier l’onglet Stages

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given aucune période de stage n’est encore associée au stagiaireWhen PANDA ouvre StagesThen l’état vide est explicite, aucune entreprise fictive n’apparaît
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-028 — Vérifier documents et historique si exposés

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un dossier de stagiaire est ouvertWhen PANDA parcourt les onglets complémentaires présents, notamment documents et journal de modificationsThen les sections ouvrent correctement, sont initialement vides si aucune donnée n’existe et n’affichent que des informations du stagiaire
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-029 — Retourner à la liste sans perte de contexte

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un dossier ECSR A est ouvert depuis StagiairesWhen PANDA utilise Retour aux stagiairesThen la liste précédente réapparaît dans l’organisation autorisée sans basculer vers une autre promotion
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________
17.5. STG-04 — Cycle de vie et cohérence métier

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-030 — Modifier les coordonnées depuis l’UI si disponible

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un dossier de stagiaire autorisé est ouvertWhen PANDA recherche une action Modifier, met à jour un téléphone de recette et enregistreThen la modification apparaît après actualisation et reste limitée au bon profil ; si aucune action UI n’existe, signaler Bloqué / Écart fonctionnel
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-031 — Changer le statut d’une inscription si l’UI le permet

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un stagiaire temporaire possède un statut modifiableWhen PANDA essaie une transition autorisée (suspendre, réactiver ou clôturer selon l’UI)Then le statut est mis à jour dans dossier, liste et promotions, sans transition illogique
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-032 — Refuser une transition interdite

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une inscription possède un état terminal ou incompatibleWhen PANDA tente un retour d’état non autorisé depuis les commandes UI disponiblesThen la transition est refusée ou indisponible sans écriture partielle
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-033 — Réaffecter à une promotion autorisée si disponible

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un stagiaire temporaire et une autre promotion admissible existentWhen PANDA effectue la réaffectation depuis l’UIThen la promotion source et destination mettent à jour leurs effectifs, et le Contexte de travail reste cohérent
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-034 — Empêcher réaffectation hors formation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un stagiaire ECSR appartient à une formationWhen PANDA tente de le déplacer vers une promotion Moto d’une autre organisationThen aucun choix illégitime n’est proposé et aucune réaffectation inter-tenant n’est acceptée
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-035 — Retirer ou archiver un stagiaire temporaire

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un stagiaire temporaire ne possède aucune dépendance bloquanteWhen PANDA exécute Retirer / Archiver / Supprimer si une action est exposée, puis confirmeThen les listes, statuts et effectifs sont cohérents ; les stagiaires de référence ne sont pas affectés
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-036 — Annuler une suppression ou un retrait

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une action destructive nécessite confirmationWhen PANDA ouvre puis annule la confirmationThen aucune donnée ni appartenance n’est modifiée
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-037 — Bloquer un retrait avec dépendances

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un stagiaire temporaire possède des séances, évaluations ou preuves historiquesWhen PANDA essaie de le retirer via l’UIThen les contraintes métier sont appliquées et l’historique n’est pas supprimé silencieusement
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________
17.6. STG-05 — Échanges avec les autres menus

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-038 — Mise à jour Promotions après inscription

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une promotion A est affichée et un nouveau stagiaire y est inscritWhen PANDA revient à PromotionsThen l’effectif de la promotion reflète la nouvelle inscription et persiste après actualisation
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-039 — Mise à jour après appel

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un stagiaire appartient à une séance planifiée et un formateur autorisé effectue l’appelWhen PANDA revient au dossier du stagiaire puis à PrésencesThen l’assiduité, les absences ou retards affichés correspondent aux enregistrements réels et sont cohérents entre menus
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-040 — Mise à jour après évaluation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un formateur habilité évalue une compétence du bon référentielWhen PANDA consulte le dossier puis les indicateurs de progressionThen le niveau ou état d’acquisition reflète l’évaluation enregistrée, sans modifier un stagiaire d’une autre promotion
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-041 — Mise à jour après création d’un stage

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un stage est créé et associé à un apprenantWhen PANDA revient au dossier individuel et ouvre StagesThen le stage et ses heures s’affichent uniquement pour l’apprenant visé
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-042 — Unicité du parcours depuis Gestion des accès

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un stagiaire a été créé depuis le menu StagiairesWhen PANDA recherche la même identité dans Gestion des accèsThen l’identité et son statut d’invitation ou d’accès sont cohérents ; aucune deuxième identité parasite
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________
17.7. STG-06 — Permissions, multi-organisation et qualité

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-043 — Direction de chaque centre voit ses propres apprenants

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given les huit stagiaires de référence sont créésWhen PANDA se connecte successivement avec USER-01 à USER-04 dans leur organisation principaleThen chaque utilisateur voit exclusivement les deux apprenants de son centre et leurs bons référentiels
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-044 — Changer quatre fois d’organisation dans une session

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given USER-01 dispose des invitations croisées acceptéesWhen PANDA alterne ECSR → Moto → PL → DEA → ECSR dans le Contexte de travailThen la liste Stagiaires, les filtres, les dossiers et les compteurs se recalculent au bon périmètre, sans mélange
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-045 — Limiter les actions au rôle secondaire

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given USER-01 est Jury, Formateur ou Secrétariat dans une autre organisationWhen PANDA ouvre Stagiaires dans ce contexte et tente les actions de création, consultation, modification et retraitThen les seules actions permises au rôle local sont exécutables ; les autres sont cachées ou refusées côté interface et serveur
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-046 — Refuser l’accès à un dossier d’un autre centre

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un identifiant de dossier ECSR est connu et le contexte actif est Moto avec droits insuffisantsWhen PANDA tente d’ouvrir le lien du dossier ECSR directement dans l’interfaceThen l’accès est refusé sans fuite de données et le contexte ne change pas silencieusement
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-047 — Vérifier restrictions du profil Stagiaire

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un apprenant de recette est authentifié selon le parcours exposéWhen PANDA ouvre son propre dossier puis tente de consulter celui d’autruiThen son accès se limite à ses propres données, sans pouvoir créer ou modifier les autres stagiaires
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-048 — Valider les états 401, 403 et erreur métier

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une session a expiré ou un droit vient d’être révoquéWhen PANDA tente une action Stagiaires qui exige ce droitThen l’écran reste utilisable, affiche une erreur compréhensible et ne prétend jamais avoir sauvegardé
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-049 — Vérifier la fraîcheur entre deux sessions

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given deux utilisateurs autorisés consultent le même centreWhen PANDA crée ou modifie un stagiaire dans une session et rafraîchit la secondeThen la seconde session montre l’état réellement sauvegardé, sans doublon ni données périmées
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-050 — Conserver le contexte après rechargement

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un compte multi-organisation a choisi une promotion autoriséeWhen PANDA actualise la page puis se reconnecteThen le contexte restauré ou redemandé appartient à ses autorisations et les stagiaires affichés correspondent à ce contexte
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STG-UI-051 — Ne pas afficher les données des autres secteurs

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given les quatre centres ont chacun des référentiels et fiches différentsWhen PANDA compare les dossiers ECSR, Moto, PL et DEAThen les libellés, compétences et activités proviennent de chaque formation, sans injection automatique des fiches ECSR dans les autres
Preuves : captures avant/après ; organisation, établissement, formation, promotion et compte connectés ; résultat de l’action ; contrôle après actualisation.Verdict : À exécuter — Réussi / Échec / Bloqué / Non applicable. Défaut : __________
17.8. Critères de sortie — Stagiaires
Les 51 scénarios STG-UI doivent être exécutés ou documentés comme Bloqué/Non applicable avec preuve et numéro de défaut.
Deux stagiaires de référence existent dans chacune des quatre promotions A (huit au total), avec identité et e-mail fictifs distincts.
La même création/invitation depuis Stagiaires et Gestion des accès ne produit pas deux identités incohérentes.
Tous les onglets d’un dossier affichent des données réelles ou des états vides explicites avant les actions métier ; aucun historique mocké.
Après chaque modification, vérifier la cohérence du Contexte de travail, les listes, les totaux, le menu Promotions et la persistance après rafraîchissement.
Aucun rôle secondaire ne reçoit les privilèges Direction de son autre organisation ; aucun dossier ne fuit d’un tenant à l’autre.
Les dossiers tests destructifs sont nettoyés ou tracés ; les huit apprenants de référence sont conservés pour les prochaines campagnes.
Les actions non exposées dans l’UI sont signalées comme écarts fonctionnels, pas déclarées réussies.
Statut de la campagne : rédigée, NON exécutée ; aucun test n’est déclaré réussi à ce stade.


18. CAMPAGNE 09 — PLANNING : RECETTE FONCTIONNELLE
Objet : valider l’utilisation du menu Planning exclusivement depuis l’interface de PedagoraPilot et ses parcours accessibles. Les quatre organisations pilotes ECSR, Moto, Poids lourds et Ambulancier sont constituées par les campagnes précédentes. Aucun scénario n’est réputé réussi avant exécution réelle par QA Panda.
18.1. Jeu de données et règles d’exécution
Comptes : USER-01 sam.user1@email.com / ECSR Nice ; USER-02 sam.user2@email.com / Moto Antibes ; USER-03 sam.user3@email.com / Poids lourds Marseille ; USER-04 sam.user4@email.com / Ambulancier Toulon. Mot de passe initial : Demo@123.
Préconditions : organisation, établissement, formation, référentiel, promotion A, responsable pédagogique et au moins un formateur éligible par centre ; invitations croisées acceptées pour les tests de changement d’organisation.
Noms de séances proposés : ECSR — Réglementation et risque routier ; Moto — Plateau et maîtrise à basse vitesse ; Poids lourds — Contrôles et manœuvres ; Ambulancier — Gestes d’urgence et prise en charge. Ne pas inventer de conformité réglementaire de ces contenus.
Dates de recette : choisir des dates futures visibles dans le calendrier, deux jours ouvrés consécutifs ; heures suggérées 09:00–11:00 et 14:00–16:00. Éviter les événements réels ; noter la date exacte choisie.
Après toute action créant ou changeant une séance : contrôler le calendrier, les listes programmées, le bon Contexte de travail, puis actualiser la page. Aucune donnée fictive ne doit apparaître.
Tests des fonctions non visibles : constater l’absence de contrôle dans l’UI et classifier comme écart fonctionnel ou non applicable selon le cahier des charges ; ne pas simuler des requêtes API pour forcer l’action.
18.2. PLN-01 — État initial, contenu et calendrier

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-001 — Accès au menu et rubriques

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given le compte Direction de chaque centre est connecté et un Contexte de travail autorisé est actif
When PANDA ouvre le menu Planning
Then le titre, le bouton d’ajout, les filtres promotion/type, les vues Jour/Semaine/Mois, la navigation de période et les zones des séances programmées sont présents sans erreur
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-002 — Planning initial sans séances

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given la promotion A existe mais aucune séance n’a été créée
When PANDA sélectionne cette promotion et parcourt les vues
Then le calendrier et les listes de séances affichent des états vides explicites, sans événement inventé ni erreur technique
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-003 — Vue Jour

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une date de recette a été fixée
When PANDA choisit Jour et navigue vers la date retenue
Then seules les séances de la journée choisie sont affichées et le libellé de date correspond
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-004 — Vue Semaine

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given des événements existent sur deux dates distinctes
When PANDA choisit Semaine
Then les événements sont placés aux dates de la semaine correcte ; aucune séance hors semaine ne pollue la vue
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-005 — Vue Mois

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given des séances sont présentes dans deux mois consécutifs
When PANDA choisit Mois
Then les jours du mois affiché correspondent au calendrier et les séances du mois suivant sont exclues
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-006 — Navigation période précédente/suivante

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une vue Jour, Semaine ou Mois est ouverte
When PANDA clique sur les flèches précédente puis suivante
Then la période varie d’une unité adaptée à la vue, puis revient à la période de départ sans déplacer les événements
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-007 — Filtre promotion

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given au moins deux promotions distinctes existent dans un même centre
When PANDA filtre successivement sur chaque promotion puis Toutes
Then les séances présentées appartiennent uniquement à la promotion choisie, puis la vue globale est restaurée
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-008 — Filtre type de séance

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given plusieurs séances de types différents existent
When PANDA sélectionne chaque type disponible puis Tous les types
Then le calendrier et les listes respectent le type choisi, sans perdre les séances des autres types
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-009 — Combiner les filtres

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given deux promotions et plusieurs types contiennent des événements
When PANDA filtre sur une promotion et un type en même temps
Then seule l’intersection des deux filtres apparaît, sans résultat provenant d’une autre promotion
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-010 — États d’absence de données sur autre centre

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given le centre Ambulancier est encore sans séance alors que le centre ECSR en possède
When PANDA bascule du Contexte de travail ECSR vers Ambulancier puis ouvre Planning
Then le planning Ambulancier n’affiche aucune séance ECSR et reste utilisable avec ses filtres et son action d’ajout
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______
18.3. PLN-02 — Création depuis l’interface et validation

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-011 — Ouverture du panneau Ajouter au planning

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given la promotion et le formateur de recette sont disponibles
When PANDA clique sur Ajouter au planning
Then un panneau/formulaire accessible s’ouvre avec date, début, fin, promotion, type, titre, responsable/formateur et champs complémentaires visibles
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-012 — Blocage si aucune promotion disponible

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un établissement n’a aucune promotion valide dans le contexte
When PANDA ouvre Ajouter au planning et tente une création
Then aucune création ne peut aboutir avec une promotion inexistante ; un message ou contrôle explicite guide vers le prérequis
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-013 — Blocage si aucun formateur éligible

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given la formation ne possède aucun formateur disponible dans la liste
When PANDA ouvre la création et tente de soumettre sans formateur
Then le formulaire refuse l’enregistrement et avertit qu’aucun formateur n’est disponible ; aucune séance fantôme ne s’affiche
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-014 — Champs obligatoires vides

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given le formulaire de planning est ouvert
When PANDA efface les champs obligatoires puis clique sur Créer
Then les champs requis sont signalés, l’envoi est refusé et le panneau reste exploitable
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-015 — Plage horaire inversée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une date valide est saisie
When PANDA saisit début 11:00 et fin 09:00 puis soumet
Then une erreur de période apparaît et aucune séance n’est créée
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-016 — Heures identiques

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le formulaire est ouvert
When PANDA renseigne début 09:00 et fin 09:00
Then une durée nulle est refusée ; aucune sauvegarde silencieuse ne se produit
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-017 — Date incorrecte ou manquante

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le formulaire est ouvert
When PANDA retire la date ou saisit une valeur invalide si le contrôle l’autorise
Then une validation compréhensible apparaît ; aucune séance sans date n’est créée
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-018 — Titre obligatoire et taille limite

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le formulaire est ouvert
When PANDA soumet un titre vide puis un titre dépassant la longueur permise
Then les validations sont explicites, sans troncature silencieuse ni faux succès
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-019 — Type de séance

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une promotion autorisée est sélectionnée
When PANDA ouvre le choix Type et parcourt les valeurs proposées
Then les types visibles sont compréhensibles et sélectionnables ; un type choisi est correctement restitué après création
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-020 — Champs lieu et compétence

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le formulaire est ouvert et une formation est active
When PANDA remplit lieu et compétence avec des libellés spécifiques au domaine
Then les valeurs sont conservées si elles font partie du modèle d’enregistrement et ne se propagent pas aux autres centres
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-021 — Création séance ECSR

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given USER-01 est Direction d’Horizon ECSR avec promotion et formateur autorisés
When PANDA crée « Réglementation et risque routier » sur une date future 09:00–11:00
Then la séance ECSR apparaît dans la bonne promotion et à la bonne date, sans devoir recharger manuellement
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-022 — Création séance Moto

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given USER-02 est Direction d’Azur Deux-Roues
When PANDA crée « Plateau et maîtrise à basse vitesse » sur la promotion Moto 09:00–11:00
Then l’événement apparaît dans le planning Moto uniquement et persiste après actualisation
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-023 — Création séance Poids lourds

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given USER-03 est Direction de Provence Poids Lourds
When PANDA crée « Contrôles et manœuvres » sur sa promotion 14:00–16:00
Then l’événement apparaît dans le centre PL uniquement et persiste après actualisation
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-024 — Création séance Ambulancier

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given USER-04 est Direction de Méditerranée Ambulancier
When PANDA crée « Gestes d’urgence et prise en charge » sur sa promotion 09:00–11:00
Then l’événement apparaît dans le centre Ambulancier uniquement ; les contenus ECSR ne sont pas proposés comme valeurs de ce contexte
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-025 — Annulation ou fermeture sans sauvegarde

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le panneau contient des valeurs non enregistrées
When PANDA clique sur Annuler ou Fermer et revient au calendrier
Then aucune séance n’est créée ; si une confirmation de perte de saisie existe, elle fonctionne correctement
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-026 — Double clic sur Enregistrer

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given le formulaire est rempli avec une nouvelle séance
When PANDA clique rapidement deux fois sur le bouton de création
Then une seule séance est enregistrée ; aucun doublon visible n’apparaît
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-027 — Erreur de sauvegarde visible

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given le service est indisponible ou une erreur de validation métier est retournée pendant l’essai autorisé
When PANDA soumet la création
Then un message d’erreur exploitable s’affiche, aucun succès fictif ni événement non persisté ne reste à l’écran
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______
18.4. PLN-03 — Dépendances, conflit et cohérence métier

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-028 — Conflit d’horaire d’un même formateur

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un formateur dispose d’une séance 09:00–11:00 dans une promotion
When PANDA tente d’affecter le même formateur à une autre séance 10:00–12:00 le même jour
Then la règle de conflit métier est appliquée avec retour visible ; si un chevauchement est autorisé, signaler le comportement et faire valider la règle
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-029 — Conflit pour une même promotion

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une séance existe sur une promotion 09:00–11:00
When PANDA ajoute à cette promotion une séance 10:00–12:00
Then le système applique la règle de chevauchement attendue ; toute incohérence de planning est signalée
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-030 — Responsable non rattaché à la formation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un formateur existe dans l’organisation mais n’est pas éligible pour la formation active
When PANDA ouvre la liste des responsables pour cette formation
Then l’utilisateur non éligible est absent ou la soumission est refusée explicitement
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-031 — Actualisation des menus liés

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une séance a été enregistrée dans Planning
When PANDA ouvre Séances puis revient sur Planning et la promotion liée
Then la séance figure dans les vues pertinentes, avec mêmes titre, date, horaire, formateur et promotion
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-032 — Modification d’un événement si exposée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une séance existe et une commande Modifier est visible dans l’UI
When PANDA ouvre cette commande, modifie l’horaire puis enregistre
Then le calendrier reflète la nouvelle valeur sans duplication et la conserve après actualisation
Points de contrôle : Ne pas déclarer Réussi une modification/suppression si le contrôle UI n’existe pas.
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-033 — Annulation ou suppression si exposée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une séance de recette sans participation est sélectionnée et l’action Annuler/Supprimer est visible
When PANDA réalise l’action et confirme le dialogue
Then l’événement est retiré ou marqué annulé selon la règle métier, les listes et indicateurs sont cohérents
Points de contrôle : Ne pas déclarer Réussi une modification/suppression si le contrôle UI n’existe pas.
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-034 — Séance avec stagiaires et dépendances

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une séance comporte des présences ou évaluations
When PANDA tente une suppression via une action disponible
Then la dépendance est signalée et l’intégrité des présences et évaluations est maintenue
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-035 — Navigation vers les séances programmées

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une séance de salle et une séance de conduite ont été planifiées
When PANDA consulte les deux sections programmées
Then chaque type apparaît au bon endroit avec ses informations cohérentes ; le passage au module Conduite ne mélange pas les données
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______
18.5. PLN-04 — Permissions, multi-organisation et contexte

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-036 — Direction multi-organisation et changement de contexte

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given USER-01 possède ses quatre rattachements acceptés avec des rôles différents
When PANDA passe ECSR → Moto → PL → Ambulancier → ECSR et examine le calendrier
Then les événements, listes des promotions et noms des formateurs se recalculent à chaque fois sans mélange de données
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-037 — Permissions selon le rôle secondaire

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given USER-01 est Direction dans ECSR et dispose d’un rôle non-Direction dans un autre centre
When PANDA tente d’ajouter ou de modifier une séance depuis chaque contexte
Then les actions accessibles correspondent au rôle local ; le statut Direction d’ECSR n’accorde aucun privilège dans les autres organisations
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-038 — Session révoquée durant la planification

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un administrateur autorisé révoque l’appartenance d’un compte dans un centre secondaire
When PANDA tente de créer une séance dans le contexte révoqué sans fermer son navigateur
Then l’opération est refusée et l’organisation révoquée disparaît des contextes disponibles après synchronisation/reconnexion
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-039 — Retrait de formation du Contexte de travail

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given le compte a plusieurs établissements ou formations autorisés
When PANDA sélectionne successivement un établissement, une formation puis une promotion
Then les listes Planning et les choix de création ne contiennent que des ressources appartenant à cette chaîne contextuelle
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-040 — Ouverture directe du planning après changement de tenant

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given le compte dispose d’accès à deux organisations et une ancienne URL de Planning est conservée
When PANDA change d’organisation puis rouvre Planning à partir de l’URL
Then aucune séance ni formulaire prérempli de l’ancien centre ne reste visible
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-041 — Contexte restauré après actualisation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un contexte de promotion a été sélectionné et des séances existent
When PANDA recharge puis se reconnecte
Then le contexte conservé ou redemandé est autorisé et les séances correspondent au contexte finalement actif
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-042 — Rechercher des données d’un centre tiers

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given les quatre centres ont chacun une séance portant un titre différent
When PANDA filtre dans le centre ECSR puis tente d’afficher une séance du centre Ambulancier via les contrôles UI
Then aucun événement étranger n’est accessible à l’écran ; toute tentative via URL publique d’un autre tenant est refusée si l’application expose un tel lien
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-043 — Actualisation depuis deux sessions

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given deux comptes disposant des droits consultent la même promotion autorisée
When PANDA crée une séance dans la première session et actualise la seconde
Then les deux calendriers donnent une représentation cohérente après synchronisation sans doublon
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-044 — Langue et libellés de planning

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P2  •  Type : E2E UI  •  Environnement : staging
Given le changement FR/EN est exposé dans l’UI
When PANDA bascule la langue puis parcourt les filtres, vues et messages de validation
Then les libellés visibles sont traduits et dates/heures restent compréhensibles
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______

Observe : 

Test :  ; anomalie : 

Preuves : 

## PLN-UI-045 — Rendu sur écran réduit

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P2  •  Type : E2E UI  •  Environnement : staging
Given PANDA dispose d’une fenêtre navigateur étroite
When PANDA ouvre Planning et son formulaire puis navigue sur le calendrier
Then les commandes restent accessibles et le calendrier est consultable sans action impossible ni chevauchement bloquant
Preuves : captures avant/après ; compte et organisation actifs ; établissement, formation, promotion et période sélectionnés ; résultat visible après actualisation.Verdict : À exécuter / Réussi / Échec / Bloqué / Non applicable ; anomalie : ______
18.6. Critères de sortie — Planning
Les 45 scénarios PLN-UI sont exécutés ou classés Bloqué / Non applicable avec capture, justification et référence de défaut.
Quatre séances représentatives persistent dans leurs organisations respectives, avec dates futures et formateurs distincts ; elles restent disponibles pour les campagnes Séances et Présences.
Les vues Jour/Semaine/Mois, filtres promotion/type, navigation temporelle, validation des champs et création sont opérationnels depuis la seule UI.
Aucun faux succès, doublon de création, ressource non autorisée ou événement d’un autre tenant ne doit être observé.
Toute modification ou suppression non exposée doit être signalée comme écart à arbitrer, et jamais considérée comme validée.
Après chaque opération pertinente, le Contexte de travail et les menus liés sont cohérents avec les données réellement enregistrées.
Statut de campagne : RÉDIGÉE — NON EXÉCUTÉE. Prochain menu : Séances.

19. Campagne 10 — Séances pédagogiques (SES-UI)
Statut : RÉDIGÉE — NON EXÉCUTÉE | Priorité : P0–P2 | Périmètre : /seances et interactions /planning, /presences et Contexte de travail.
Objet : vérifier exclusivement depuis l’interface les formulaires de séances, leur persistance, leur affichage, la cohérence des promotions et des formateurs, les modalités, l’appel, les droits et l’isolation des quatre centres. Les fonctionnalités absentes ou non exposées doivent être déclarées « Bloqué / Écart UI », jamais « Réussi ».
19.1. Prérequis et jeux de données de recette
Comptes Direction : sam.user1@email.com (ECSR Nice), sam.user2@email.com (Moto Antibes), sam.user3@email.com (Poids lourds Marseille), sam.user4@email.com (Ambulancier Toulon). Mot de passe initial Demo@123 ; DemoDemo@123 uniquement pour les essais de changement, puis retour à Demo@123.
Chaque organisation possède un établissement, une formation, une version de référentiel, une promotion active et deux stagiaires fictifs issus des campagnes précédentes. Les invitations croisées entre quatre comptes sont acceptées ; les rôles varient selon l’organisation.
Disposer, dans chaque centre, d’au moins un compte Formateur actif et affecté au périmètre éligible (créé/invité par Gestion des accès). Ne jamais utiliser automatiquement la Direction à la place du formateur.
Exemples de séances (fictifs) : ECSR « Risques liés à la vitesse » ; Moto « Trajectoires de sécurité en virage » ; Poids lourds « Angles morts et gabarit » ; Ambulancier « Hygiène et prévention des infections ». Planifier à une date future différente des séances déjà créées.
Pour chaque test : enregistrer capture avant/après, compte, organisation active, établissement, formation, promotion, date, résultat UI, persistance après actualisation et référence de défaut lorsque nécessaire. Ne pas conclure à la réussite depuis un simple toast.
19.2. Inventaire de l’interface vérifiée dans les sources Angular
Le formulaire comporte date, heure début/fin, formateur, promotion, type, modalité, thème, objectifs, supports et commentaires. Les types visibles sont Salle, Exposé/Présentation, Évaluation, Sensibilisation, Rattrapage, Événement (libellés dépendant des traductions). Les modalités sont Présentiel, Distanciel synchrone, Distanciel asynchrone et Pratique. Le panneau « Séances programmées » affiche titre, date/heures, formateur, promotion, badges type/modalité, objectif, supports, compteur présence et lien « Faire l’appel ».
Point d’attention confirmé au niveau du HTML : « Créer puis faire l’appel » est un lien de navigation indépendant, sans création automatique dans le clic. La campagne prévoit un test d’intégrité de ce parcours. La création côté store est limitée à une promotion autorisée et à un formateur actif du répertoire ; le formulaire ne sélectionne pas individuellement les participants (séance prévue pour la promotion entière).
19.3. État initial et visibilité

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-001 — Écran initial sans séance

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le compte est connecté dans une organisation sans séance créée
When PANDA ouvre Séances
Then les sections de création et séances programmées sont visibles, la liste est vide, sans fausses lignes ou erreur bloquante
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-002 — Champs et valeurs par défaut

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given l’écran Séances vient de s’ouvrir
When PANDA inspecte tous les champs et les choix de type/modalité
Then date, heures et valeurs par défaut sont visibles, modifiables et cohérentes ; aucun faux formateur ou promotion n’est présélectionné
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-003 — Liste des promotions autorisées

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given deux promotions appartiennent à des formations ou établissements distincts
When PANDA ouvre le sélecteur Promotion dans chacun des contextes
Then seules les promotions autorisées par le périmètre actif sont proposées
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-004 — Liste des formateurs autorisés

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given des formateurs actifs, invités et suspendus existent
When PANDA ouvre le sélecteur Formateur
Then seuls les formateurs actifs et éligibles apparaissent ; aucun invité ou suspendu ne peut être sélectionné
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-005 — Absence de promotion

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given aucune promotion éligible n’existe dans le contexte actif
When PANDA ouvre Séances et essaie de créer
Then la création est impossible avec un message compréhensible ; aucune séance n’apparaît
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-006 — Absence de formateur

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given aucune personne active éligible n’est disponible
When PANDA ouvre le formulaire puis essaie de sauvegarder
Then la création est bloquée et le besoin de formateur est explicite
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-007 — Navigation vers Présences

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given aucune séance n’est sélectionnée ou créée
When PANDA clique sur le lien vers Présences
Then la page Présences s’ouvre sans inventer de séance ou d’appel
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________
19.4. Création, saisie et validation

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-008 — Création ECSR

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given Horizon ECSR dispose des prérequis
When PANDA saisit une séance « Risques liés à la vitesse » avec formateur actif et valide
Then la séance apparaît une seule fois avec ses informations, est conservée après actualisation et dans Planning
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-009 — Création Moto

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given Azur Deux-Roues est le contexte actif avec formateur et promotion autorisés
When PANDA crée « Trajectoires de sécurité en virage »
Then la séance est enregistrée dans Moto uniquement et reste visible après actualisation
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-010 — Création Poids lourds

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given Provence PL dispose des prérequis
When PANDA crée « Angles morts et gabarit »
Then la séance est enregistrée dans Poids lourds uniquement et apparaît au planning associé
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-011 — Création Ambulancier

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given Méditerranée Ambulancier dispose des prérequis
When PANDA crée « Hygiène et prévention des infections »
Then la séance est enregistrée exclusivement dans Ambulancier et reste consultable
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-012 — Thème obligatoire

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given les autres champs sont valides
When PANDA laisse Thème vide ou composé d’espaces et clique Créer
Then une erreur de validation est visible et aucune séance n’est ajoutée
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-013 — Date obligatoire

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given les autres données sont valides
When PANDA efface la date et tente de créer
Then la création est refusée et une erreur visible explique le champ requis
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-014 — Horaires absents

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un formulaire valide sauf heure de début ou de fin
When PANDA tente d’enregistrer
Then la création est refusée sans données partielles
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-015 — Heure de fin identique au début

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given le début est à 09:00
When PANDA règle la fin à 09:00 et valide
Then une erreur visible empêche la création
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-016 — Heure de fin antérieure

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given le début est à 12:00
When PANDA règle la fin à 08:00 et valide
Then le formulaire refuse la séance avec une erreur explicite
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-017 — Aucun formateur sélectionné

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une promotion et des horaires valides existent
When PANDA retire le formateur si l’UI le permet et crée
Then le système refuse la création plutôt que d’attribuer la Direction par défaut
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-018 — Promotion non sélectionnée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given plusieurs promotions sont accessibles
When PANDA n’en sélectionne aucune puis valide
Then le formulaire bloque la création, sans promotion de substitution
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-019 — Objectifs et supports

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une promotion et un formateur sont sélectionnés
When PANDA saisit objectifs, supports et commentaires puis crée
Then les informations saisies sont conservées et les champs affichés correspondent à la séance
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-020 — Tous les types de séance

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une promotion valide existe
When PANDA crée une séance pour chaque type exposé dans l’interface
Then les types sélectionnés sont conservés et représentés correctement dans la liste, sans libellés techniques
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-021 — Toutes les modalités

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given les quatre modalités sont proposées
When PANDA crée une séance pour chaque modalité
Then le badge modalité est correct et l’enregistrement persiste ; les fonctions supplémentaires non exposées restent identifiées comme écarts
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-022 — Double clic sur Créer

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given le formulaire est complet
When PANDA clique rapidement deux fois sur Créer
Then une seule séance métier est créée ou un doublon est explicitement empêché
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-023 — Échec réseau au moment de créer

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given l’application ne reçoit pas de confirmation serveur (simulation navigateur si autorisée)
When PANDA lance la création
Then aucun faux succès n’est affiché et la liste ne présente pas de séance fantôme
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-024 — Nettoyage après succès

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P2  •  Type : E2E UI  •  Environnement : staging
Given une séance vient d’être créée avec succès
When PANDA inspecte le formulaire
Then le thème, les objectifs, les supports et les commentaires sont réinitialisés sans altérer la séance sauvegardée
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________
19.5. Liste, liens et suivi de l’appel

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-025 — Correspondance carte et saisie

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une séance existe dans la promotion active
When PANDA consulte sa carte dans Séances
Then titre, date, heures, formateur, promotion, type, modalité, objectifs et supports affichés correspondent à la création
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-026 — Présences initiales à zéro

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une séance a été créée mais aucun appel réalisé
When PANDA inspecte son indicateur de présence
Then aucune présence fictive n’est affichée ; l’effectif attendu reflète les inscriptions réellement éligibles
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-027 — Faire l’appel sur la bonne séance

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given deux séances distinctes sont affichées
When PANDA clique Faire l’appel sur la seconde
Then l’écran Présences permet d’identifier ou sélectionner la seconde séance, jamais automatiquement la première
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-028 — Créer puis faire l’appel

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given le formulaire est rempli mais non enregistré
When PANDA clique « Créer puis faire l’appel »
Then le parcours doit créer et sélectionner effectivement la séance avant l’appel ; si seul /presences s’ouvre sans création, déclarer anomalie bloquante, ne pas créer de faux succès
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-029 — Actualisation du compteur d’appel

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given des présences ont été enregistrées dans Présences
When PANDA revient sur Séances puis actualise
Then le nombre de présents et le taux correspondent aux données enregistrées ; aucune donnée d’une autre séance n’est reprise
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-030 — Cohérence avec Planning

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une séance est créée dans Séances
When PANDA consulte Planning à la date de cette séance
Then elle apparaît une seule fois avec horaire, promotion et type cohérents
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-031 — Cohérence après création depuis Planning

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une séance a été créée dans le menu Planning
When PANDA ouvre Séances avec le même Contexte de travail
Then la séance est visible sans duplication et peut servir de support à l’appel
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-032 — Modification par l’UI si exposée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une séance existe
When PANDA cherche une action de modification dans Séances ou Planning
Then si elle existe, les changements persistent dans les deux menus ; sinon consigner l’absence de commande comme écart non testé
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-033 — Suppression/annulation si exposée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une séance existe sans appel bloquant
When PANDA cherche supprimer ou annuler depuis l’UI
Then si l’action existe, dépendances et confirmation sont respectées et les listes se synchronisent ; sinon signaler Écart UI
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________
19.6. Contexte, permissions et séparation des centres

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-034 — Vérification du contexte après création

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given PANDA vient de créer une séance dans un centre
When PANDA ouvre Contexte de travail puis recharge Séances
Then organisation, établissement, formation et promotion sont cohérents et la séance reste dans ce périmètre
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-035 — Changement d’organisation avec formulaire saisi

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un formulaire de séance est partiellement rempli dans ECSR
When PANDA change vers l’organisation Moto avant enregistrement
Then aucun enregistrement ne part dans le mauvais centre ; les choix formateur/promotion deviennent valides pour Moto seulement
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-036 — Changement de promotion

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une séance appartient à la promotion A
When PANDA sélectionne la promotion B dans Contexte de travail
Then les séances filtrées sont cohérentes et la séance A n’est pas faussement rattachée à B
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-037 — Identité multi-organisation à rôles distincts

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given sam.user1 possède Direction dans ECSR et un rôle différent dans Moto
When PANDA bascule l’organisation
Then les menus et droits de création de séances reflètent uniquement le rôle de l’organisation active
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-038 — Formateur suspendu après chargement

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un formateur est visible puis suspendu par un administrateur
When PANDA tente de créer une séance avec lui sans recharger le formulaire
Then la création est refusée et aucun enregistrement inéligible n’apparaît
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-039 — Retrait d’accès pendant la session

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given l’utilisateur dispose de l’accès à une organisation puis celui-ci est révoqué
When PANDA tente de créer ou consulter des séances dans cette organisation
Then les actions non autorisées sont refusées et le contexte ne révèle plus de données interdites
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-040 — Isolation entre les quatre centres

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given les quatre séances thématiques ont été créées
When PANDA parcourt successivement les quatre organisations
Then chaque centre n’affiche que ses séances et sa promotion, sans mélange de résultats
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-041 — Rôle non autorisé

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given PANDA se connecte avec un profil sans permission d’édition des séances
When il essaie de créer via les contrôles visibles
Then l’action est absente/désactivée ou refusée clairement, sans écriture
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-042 — Deux comptes dans le même centre

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given deux utilisateurs autorisés consultent le même périmètre
When le premier crée une séance et le second actualise
Then la même séance est visible de façon cohérente sans doublon
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SES-UI-043 — Libellés FR/EN et affichage mobile

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P2  •  Type : E2E UI  •  Environnement : staging
Given la langue et une largeur mobile sont configurables
When PANDA bascule FR/EN et ouvre le formulaire sur petit écran
Then les libellés et erreurs sont compréhensibles, les actions restent accessibles et aucune clé brute n’apparaît
Preuves : captures avant/après ; compte, rôle et organisation actifs ; établissement, formation, promotion ; résultat visible après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable | Ticket : __________
19.7. Critères de sortie — Séances
Les 43 scénarios SES-UI sont exécutés ou classés Bloqué / Non applicable avec justification et capture.
Une séance représentative par centre subsiste avec les bons titre, formateur, promotion, dates et modalités ; aucune fuite inter-organisation.
Les listes Séances et Planning sont cohérentes après création et actualisation ; le lien vers Présences rattache l’appel à la bonne séance.
Les validations de thème, date, horaires, promotion et formateur actif sont effectives ; aucun faux succès ni doublon.
Les permissions et le Contexte de travail sont recalculés lors des changements de rôle, organisation, promotion et statut du formateur.
Toute capacité absente de l’UI, notamment l’édition, l’annulation, le choix individuel des participants ou la création suivie d’appel, est signalée comme écart et non validée.
Statut : RÉDIGÉE — NON EXÉCUTÉE. Prochain menu : Conduite.

20. Campagne 10 — Menu Conduite : séances pratiques, évaluations et observations
Périmètre : écran /conduite dans le frontend Angular de référence. Tests fonctionnels exécutables depuis la seule interface Web. Toutes les campagnes précédentes restent applicables.
État de départ : les quatre organisations, promotions, utilisateurs et stagiaires fictifs sont configurés par les campagnes précédentes. Chaque contrôle est mené dans le Contexte de travail courant ; PANDA relève le rôle, l’organisation, l’établissement, la formation et la promotion actifs.
20.1. Règles d’exécution et limites connues de l’interface
Utiliser exclusivement des identités et observations fictives. Pour les parcours ECSR, Moto et Poids lourds, sélectionner une formation et un référentiel de compétences réellement configurés ; ne pas imposer des critères ECSR au centre Ambulancier.
Le menu Conduite est spécifique à l’enseignement pratique de conduite. Pour Ambulancier, vérifier sa disponibilité selon les modules actifs et le référentiel propre à la formation ; si le module n’est pas applicable, noter Non applicable avec preuve plutôt que fabriquer des évaluations.
Dans la version Angular inspectée, le champ Véhicule est désactivé et aucune flotte n’est exposée par le formulaire : ne pas déclarer une affectation de véhicule réussie ; consigner l’absence de fonctionnalité si elle est attendue.
L’écran affiche des dates, heures, durée et un objectif, mais il faut vérifier séparément ce qui est réellement conservé dans l’historique après sauvegarde. Un message “Enregistré” ne constitue pas une preuve suffisante.
Les évaluations ont trois niveaux visibles : Acquis, En progression et À travailler. Les compétences, sous-compétences et critères doivent provenir du référentiel du bon centre.
L’écran possède un bloc “Observations quotidiennes” pour sélectionner des observations et demander une signature ; les droits peuvent en limiter l’accès. Les demandes de signature ne doivent pas partir vers des personnes réelles.
PANDA conserve la capture avant action, après action et après actualisation ; toute fonction non disponible dans l’UI doit être signalée Bloqué / Non applicable selon la cause.
20.2. Ouverture, état initial et sélecteurs

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-001 — Menu visible avec droit Conduite

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un utilisateur Direction autorisé est connecté à Horizon ECSR
When il ouvre le menu Conduite
Then le titre, les informations de séance, la grille d’évaluation, les observations et l’historique sont affichés sans erreur
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-002 — État vide sans apprenant

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given aucun stagiaire n’est inscrit dans une promotion de recette temporaire
When PANDA ouvre Conduite dans ce contexte
Then aucun stagiaire fictif n’est proposé ; l’enregistrement est indisponible et aucun historique inventé n’apparaît
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-003 — Affichage des stagiaires du périmètre

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given deux stagiaires existent dans Horizon ECSR
When PANDA ouvre la liste des stagiaires depuis Conduite
Then seuls les apprenants autorisés dans le Contexte de travail apparaissent, sans stagiaire d’un autre centre
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-004 — Changement d’apprenant

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given deux stagiaires ECSR ont des historiques distincts
When PANDA sélectionne successivement chacun d’eux
Then l’historique et les informations changent avec l’apprenant, les commentaires non enregistrés du premier ne passent pas au second
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-005 — Sélecteur de formateur

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un responsable et un formateur actifs ont été affectés au périmètre
When PANDA consulte la liste Formateur
Then seuls les intervenants éligibles sont affichés et le changement est contrôlé selon les permissions
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-006 — Véhicule indisponible

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le formulaire Conduite est ouvert
When PANDA tente d’utiliser le champ Véhicule
Then le champ est clairement inactif et ne prétend pas enregistrer un véhicule ; l’écart est tracé si le besoin métier exige cette affectation
Précision QA : Comportement explicitement relevé dans le code Angular ; ne pas compter comme une fonctionnalité de gestion de flotte.
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-007 — Dernière séance absente

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given l’apprenant n’a encore aucune évaluation de conduite
When PANDA consulte la carte Dernière séance
Then aucune fausse date, compétence ou observation métier n’est présentée comme issue d’une séance réelle
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-008 — Historique initial vide

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given aucune évaluation n’a été créée pour l’apprenant
When PANDA utilise le bouton Historique
Then l’emplacement historique est accessible et indique l’absence de données sans erreur
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
20.3. Saisie et validation d’une séance pratique

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-009 — Création d’une première évaluation ECSR

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given USER-01 est Direction ECSR et un stagiaire, un formateur et un référentiel éligibles existent
When PANDA choisit la compétence et les critères, complète objectif et observations puis clique Valider
Then l’évaluation apparaît dans l’historique du bon stagiaire après sauvegarde et après actualisation
Précision QA : Exemple fictif : objectif “recherche des indices utiles et anticipation des risques”.
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-010 — Évaluation Moto adaptée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given USER-02 travaille dans son centre Moto avec un référentiel adapté
When PANDA évalue un stagiaire sur une compétence de conduite moto prévue dans ce référentiel
Then le libellé et les critères affichés sont liés à Moto ; aucun critère ECSR ou Ambulancier étranger ne remplace le référentiel
Précision QA : Utiliser seulement les compétences réellement configurées dans le centre.
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-011 — Évaluation Poids lourds adaptée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given USER-03 est dans le centre Groupe Lourd
When PANDA crée une évaluation sur un objectif pratique autorisé par le référentiel
Then l’évaluation est conservée dans la promotion poids lourds et visible uniquement dans son périmètre
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-012 — Ambulancier : module applicable ou non

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given USER-04 sélectionne sa formation DEA
When PANDA consulte la visibilité du menu Conduite puis son éventuel référentiel
Then la disponibilité du menu respecte l’activation des modules et aucune grille ECSR n’est imposée ; le test est Non applicable si la conduite n’est pas gérée pour cette formation
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-013 — Sélection obligatoire du stagiaire

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given aucun stagiaire valide n’est disponible dans le contexte courant
When PANDA tente de valider une évaluation
Then l’enregistrement est bloqué et un message compréhensible oriente vers un stagiaire éligible
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-014 — Compétence obligatoire

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given aucune compétence valide n’est disponible dans le référentiel actif
When PANDA tente de valider
Then la sauvegarde est refusée ; aucune ligne d’historique n’est créée
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-015 — Critères obligatoires

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given la compétence sélectionnée ne possède aucun critère de grille
When PANDA clique Valider
Then l’action est bloquée avec une explication sans faux succès
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-016 — Formateur requis selon habilitation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un utilisateur avec droit d’affectation formateur ouvre un dossier mais aucun formateur actif n’est proposé
When il tente de valider une évaluation
Then l’absence de formateur éligible bloque l’enregistrement et indique le prérequis
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-017 — Date et horaires cohérents

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le formulaire propose date, heure de début, heure de fin et durée
When PANDA renseigne une heure de fin antérieure au début puis tente la validation
Then l’UI ou le serveur refuse les horaires incohérents ou signale une anomalie si la valeur incohérente est acceptée
Précision QA : Vérifier aussi ce qui est effectivement persisté : l’UI peut afficher des champs non transmis.
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-018 — Durée négative ou non numérique

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un apprenant et une compétence valides sont sélectionnés
When PANDA saisit une durée négative, puis du texte arbitraire et valide
Then aucune durée incohérente n’est présentée comme enregistrée ; documenter précisément le comportement observé
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-019 — Objectif pédagogique libre

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un stagiaire valide est sélectionné
When PANDA saisit un objectif fictif identifiable puis enregistre
Then l’objectif exact est retrouvé dans le bon dossier après actualisation, sans être remplacé par du texte d’un autre stagiaire
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-020 — Deux clics rapides sur Valider

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given le formulaire d’évaluation est complet
When PANDA clique deux fois rapidement sur Valider
Then une seule évaluation métier est créée ; un état de sauvegarde empêche les doublons
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-021 — Erreur d’enregistrement

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un incident réseau survient au moment de sauvegarder
When PANDA clique Valider et revient au dossier
Then une erreur visible est affichée, aucun succès n’est annoncé et aucune fausse évaluation n’apparaît
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
20.4. Compétences, critères et observations

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-022 — Changement de compétence

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un référentiel possède au moins deux compétences et leurs critères
When PANDA évalue un critère puis choisit une autre compétence
Then les sous-compétences et critères sont recalculés ; les notes de l’ancienne compétence ne sont pas réutilisées
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-023 — Changement de sous-compétence

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une compétence possède plusieurs sous-compétences
When PANDA sélectionne un critère puis change de sous-compétence
Then la grille correspond uniquement à la sous-compétence active et ne conserve pas des évaluations inappropriées
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-024 — Trois niveaux d’évaluation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un critère évaluable est affiché
When PANDA sélectionne successivement À travailler, En progression et Acquis
Then le niveau actif est identifiable, les autres désélectionnés, et seul le niveau final est sauvegardé
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-025 — Critères multiples

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given au moins trois critères sont présents
When PANDA attribue des niveaux différents à trois critères puis enregistre
Then chaque critère conserve son niveau propre dans l’historique, sans inversion
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-026 — Observations complètes

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une séance d’essai est prête
When PANDA remplit points positifs, difficultés, erreurs, conseils, objectif suivant et observation libre
Then les six champs restent associés au bon stagiaire et consultables après sauvegarde et actualisation
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-027 — Texte libre et caractères particuliers

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given les zones d’observation sont éditables
When PANDA saisit accents, apostrophes, retours à la ligne et caractères particuliers usuels
Then le texte est affiché correctement et sans exécution de code ; la sauvegarde et la lecture restent utilisables
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-028 — Changement d’apprenant après brouillon

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une évaluation non sauvegardée contient notes et observations
When PANDA change de stagiaire puis revient
Then le brouillon du premier n’est jamais appliqué au second ; le comportement de conservation ou d’abandon est explicite
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-029 — Progression après évaluation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une compétence de stagiaire était non évaluée
When PANDA enregistre une évaluation puis ouvre Compétences et le dossier Stagiaires
Then les indicateurs concernés sont cohérents avec l’évaluation enregistrée et n’affichent pas de progression fictive
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
20.5. Historique, observations quotidiennes et signatures

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-030 — Historique après validation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une séance a été enregistrée sur le stagiaire de référence
When PANDA ouvre Historique
Then la nouvelle entrée présente le bon apprenant, la bonne date, la compétence, l’évaluateur et les niveaux de critères disponibles
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-031 — Historique propre à chaque stagiaire

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given deux stagiaires ont des évaluations différentes
When PANDA alterne les deux sélections
Then chaque historique contient uniquement les évaluations du stagiaire sélectionné
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-032 — Observations du jour vides

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given aucune observation en attente n’existe pour la date choisie
When PANDA ouvre Observations quotidiennes et actualise
Then un état vide explicite apparaît, sans proposition fictive de signature
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-033 — Filtrer les observations par date

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given des observations de deux dates distinctes existent
When PANDA change la date du filtre des observations quotidiennes
Then la liste correspond à la date choisie et ne mélange pas les résultats
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-034 — Sélectionner une observation à signer

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une observation est à l’état Signature non demandée
When PANDA coche sa ligne
Then le compteur de sélection se met à jour et l’envoi devient disponible si ses permissions l’autorisent
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-035 — Demande groupée de signatures

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given au moins deux observations fictives sont éligibles à une demande de signature
When PANDA coche les deux puis utilise Envoyer la sélection
Then le résultat indique les demandes envoyées, les lignes changent d’état et une actualisation confirme la persistance
Précision QA : Ne pas transmettre une demande à des destinataires réels.
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-036 — Exclure une observation déjà demandée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une observation a déjà une signature demandée ou acquise
When PANDA tente de la sélectionner à nouveau
Then la sélection est désactivée et aucune demande dupliquée n’est envoyée
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-037 — Échec partiel d’envoi

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given deux observations sont sélectionnées et l’une échoue côté service
When PANDA lance l’envoi groupé
Then le bilan envoyé/échoué est lisible, la ligne échouée n’est pas présentée comme réussie et un nouvel essai reste maîtrisé
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-038 — Sans droit de signature

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given le compte possède driving.view mais pas le droit de demander une signature
When PANDA ouvre Conduite et tente de transmettre des observations
Then aucune demande n’est envoyée ; l’accès est refusé ou les contrôles sont indisponibles sans exposer de données interdites
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
20.6. Permissions, isolation et changements de contexte

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-039 — Lecture seule du stagiaire

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un stagiaire fictif dispose d’un accès à son propre dossier
When il ouvre Conduite
Then il consulte uniquement ses informations et son historique, sans pouvoir modifier les critères, observations ou apprenant
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-040 — Formateur autorisé

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un formateur a une affectation active à la promotion ECSR
When il ouvre Conduite et évalue un stagiaire de sa promotion
Then les actions de saisie autorisées fonctionnent dans son périmètre et l’identité de l’évaluateur est correcte
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-041 — Jury sans permission Conduite

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un compte Jury ne possède pas de permission spécifique de modification de conduite
When il consulte les menus et tente les actions proposées
Then aucun droit de modification n’est obtenu du seul fait du rôle Jury
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-042 — Rôles distincts selon organisation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given sam.user1 est Direction ECSR et dispose d’un autre rôle dans Moto
When il change d’organisation depuis le Contexte de travail
Then le menu et les actions Conduite reflètent les droits du nouveau rôle, sans hériter des permissions Direction ECSR
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-043 — Contexte ECSR vers Moto

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given des séances distinctes existent dans Horizon ECSR et Azur Deux-Roues
When PANDA passe d’ECSR à Moto puis revient
Then la liste d’apprenants, les référentiels, les critères et l’historique basculent entièrement avec l’organisation
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-044 — Promotion A vers promotion B

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given deux promotions coexistent dans la même formation
When PANDA change de promotion dans Contexte de travail
Then les apprenants et leurs évaluations sont filtrés correctement ; aucun dossier ne migre d’une promotion à l’autre
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-045 — Révocation d’accès en cours de session

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un utilisateur a perdu son affectation à une organisation pendant que Conduite était ouvert
When il tente une nouvelle évaluation ou actualise la page
Then l’opération est refusée, l’ancien périmètre est nettoyé et les données protégées ne restent pas accessibles
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-046 — Absence de fuite entre quatre centres

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given les quatre organisations disposent de jeux de données pédagogiques distincts
When PANDA parcourt leurs Contexte de travail successifs
Then aucun stagiaire, formateur, critère ou historique d’un centre ne figure dans un autre sans autorisation explicite
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-047 — Désactivation du module Conduite

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un administrateur désactive le module Conduite pour une organisation
When PANDA se reconnecte dans cette organisation et tente d’ouvrir Conduite
Then la navigation et les actions respectent le paramétrage du module, sans modifier les autres centres
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## CON-UI-048 — Cohérence inter-écrans et rechargement

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une évaluation a été sauvegardée dans ECSR
When PANDA actualise Conduite puis consulte Stagiaires, Compétences et Rapports lorsque concernés
Then les données persistées sont cohérentes entre écrans et aucune donnée non enregistrée ne compte dans les indicateurs
Preuves : captures avant/après, utilisateur et rôle, Contexte de travail, résultat après actualisation.Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
20.7. Critères de sortie — Conduite
Les 48 scénarios CON-UI sont exécutés ou classés Bloqué / Non applicable avec une justification et une preuve.
Au moins une évaluation de conduite représentative est persistée pour ECSR, Moto et Poids lourds lorsque le module et le référentiel s’y appliquent ; aucun contenu ECSR n’est injecté de force dans Ambulancier.
Chaque évaluation appartient au bon apprenant et conserve les critères, niveaux, commentaires, dates et informations réellement prises en charge ; aucune réussite purement cosmétique.
L’historique, les observations quotidiennes et les signatures fonctionnent dans les limites des permissions et ne créent aucun doublon.
Les quatre organisations, leurs promotions et leurs rôles restent strictement isolés à chaque changement de Contexte de travail.
Les écarts de fonctionnalités visibles sont documentés, notamment la sélection du véhicule désactivée et l’éventuelle non-persistance des champs de durée et horaires.
Statut : RÉDIGÉE — NON EXÉCUTÉE. Prochain menu : Fiches / Exposés.

21. Campagne 11 — Fiches / Exposés
Version 1.3 • Tests fonctionnels E2E dans l’interface • 45 scénarios • Statut : rédigée, non exécutée.
Périmètre confirmé dans les écrans Angular : indicateurs Préparées/Présentées/Validées/À retravailler, progression, recherche et filtre de statut, choix du stagiaire, tableau numéroté, action Évaluer un exposé, tiroir d’évaluation (stagiaire, fiche, date, durée, évaluateur, grille de critères, synthèse, décision et enregistrement). La configuration du catalogue (aperçu, édition, ajout, suppression et réinitialisation) est accessible dans Administration sous conditions de contexte et de permissions.
Règle de données : les 58 fiches sont propres au programme ECSR si le référentiel correspondant est disponible. Ne pas imposer 58 fiches au centre Moto, Poids lourds ou Ambulancier : utiliser uniquement le catalogue effectivement rattaché à leur formation. Des données métier initialement vides ne signifient pas qu’un catalogue de référence système doit être vide.
Préconditions : utiliser les quatre comptes sam.user1@email.com à sam.user4@email.com (mot de passe initial Demo@123) ; chacun dispose de son organisation de recette et des promotions/stagiaires créés lors des campagnes précédentes. Les utilisateurs possèdent aussi des accès croisés, avec des rôles différents. Si une fonctionnalité n’est pas exposée dans l’UI, marquer Bloqué / écart fonctionnel, jamais Réussi.
21.1. État initial et navigation

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-001 — Ouverture du menu depuis Direction

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given sam.user1 est connecté au centre ECSR avec un Contexte de travail valide
When il ouvre Fiches / Exposés
Then le menu, les quatre indicateurs, la progression et le tableau sont visibles sans erreur
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-002 — Aucune évaluation créée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une promotion et ses apprenants existent, mais aucune évaluation de fiche n’a été créée
When PANDA affiche le menu puis actualise
Then aucune présentation, validation ni évaluation fictive ne s’affiche ; les compteurs reflètent uniquement les données réelles
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-003 — Catalogue référentiel distinct des résultats

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le référentiel de la formation contient des fiches prédéfinies et aucun stagiaire n’a encore été évalué
When PANDA ouvre le tableau
Then les fiches du catalogue peuvent apparaître, mais leurs dates, évaluateurs et résultats restent vides/non démarrés
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-004 — Affichage des indicateurs cohérents

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given des fiches sont présentes dans la formation sélectionnée
When PANDA relève les quatre KPI et statuts du tableau
Then les totaux sont cohérents avec les fiches de l’apprenant et aucun nombre négatif n’apparaît
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-005 — Choix d’un stagiaire

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given au moins deux stagiaires existent dans la promotion sélectionnée
When PANDA change le stagiaire dans le filtre
Then les statuts, évaluations, indicateurs et progression correspondent au stagiaire choisi
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-006 — Recherche par numéro

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une fiche numérotée existe dans le catalogue
When PANDA recherche son numéro
Then la fiche correspondante s’affiche et la recherche n’invente aucun résultat
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-007 — Recherche par titre et absence de résultat

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given plusieurs titres distincts sont disponibles
When PANDA recherche une partie d’un titre puis une expression inexistante
Then les fiches correspondantes sont affichées puis un état vide compréhensible apparaît
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-008 — Filtre par statut et réinitialisation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given plusieurs statuts existent ou seront créés lors de la campagne
When PANDA choisit un statut puis Tous les statuts
Then le tableau respecte le filtre et la réinitialisation restaure le périmètre sélectionné
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-009 — Affichage responsive

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P2  •  Type : E2E UI  •  Environnement : staging
Given le menu est ouvert avec un compte autorisé
When PANDA consulte le tableau dans une fenêtre mobile puis sur bureau
Then les filtres, colonnes et commandes restent exploitables sans perte de données
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
21.2. Évaluation et validations

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-010 — Ouverture du tiroir Évaluer

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un utilisateur Direction ou Formateur éligible est connecté
When PANDA clique Évaluer un exposé
Then le tiroir présente les champs Stagiaire, Fiche, Date, Durée, Évaluateur, grille, synthèse et décision
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-011 — Sélection obligatoire de la bonne fiche

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le tiroir est ouvert avec la formation ECSR sélectionnée
When PANDA choisit une fiche du référentiel actif
Then son numéro et intitulé correspondent au catalogue de la formation et aux critères associés
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-012 — Évaluateur autorisé

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given des formateurs sont affectés à la formation
When PANDA ouvre la liste des évaluateurs
Then seuls les évaluateurs autorisés dans le périmètre sont proposés ; aucun utilisateur d’un autre centre n’est proposé
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-013 — Date d’évaluation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le formulaire est ouvert sur un stagiaire
When PANDA saisit une date valide puis tente une valeur non valide si le contrôle l’accepte
Then l’enregistrement conserve une date valide et refuse une date invalide sans faux succès
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-014 — Durée : borne minimale

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le champ Durée propose une borne de 1 minute dans l’UI
When PANDA saisit 0 puis tente d’enregistrer
Then la valeur invalide est refusée et aucun résultat ne change
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-015 — Durée : borne maximale

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le champ Durée propose une borne de 180 minutes dans l’UI
When PANDA saisit 181 puis tente d’enregistrer
Then la valeur invalide est refusée sans évaluation persistée
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-016 — Grille et niveau de chaque critère

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une fiche possède plusieurs critères à évaluer
When PANDA sélectionne différents niveaux sur plusieurs critères
Then les sélections visuelles et les nombres Acquis/En cours/À revoir correspondent aux réponses
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-017 — Modification d’un niveau avant sauvegarde

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un critère a été noté dans le tiroir
When PANDA change sa note avant d’enregistrer
Then l’ancienne sélection est remplacée et les compteurs de synthèse se recalculent
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-018 — Saisie des points positifs

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le tiroir est ouvert
When PANDA complète les points positifs
Then le texte demeure dans la synthèse et sera restitué après sauvegarde
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-019 — Saisie des améliorations

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le tiroir est ouvert
When PANDA saisit une piste d’amélioration
Then la saisie est enregistrée pour le bon stagiaire et la bonne fiche
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-020 — Commentaire et prochain objectif

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le tiroir est ouvert
When PANDA renseigne le commentaire général et le prochain objectif
Then ces deux éléments restent attachés à l’évaluation après réouverture
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-021 — Décision Validée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given la grille et les éléments obligatoires sont renseignés
When PANDA sélectionne Validée puis enregistre
Then le statut validé est affiché, les compteurs sont mis à jour et les données persistent après actualisation
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-022 — Décision À retravailler

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une seconde fiche est évaluée
When PANDA choisit À retravailler puis enregistre
Then le statut à retravailler et son compteur évoluent sans augmenter celui des validations
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-023 — Enregistrement sans décision

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given les champs du tiroir sont renseignés mais aucune décision n’est sélectionnée
When PANDA clique Enregistrer
Then une validation cohérente empêche la création d’une décision indéterminée ou signale clairement l’état réellement enregistré
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-024 — Annulation de saisie

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une évaluation non enregistrée a été saisie
When PANDA clique Annuler ou ferme le tiroir
Then aucune modification n’est persistée ; à la réouverture, seules les données confirmées figurent
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-025 — Double clic sur Enregistrer

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une évaluation complète est prête
When PANDA clique rapidement deux fois Enregistrer
Then une seule évaluation métier est créée et aucun doublon ne figure dans les indicateurs
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
21.3. Cycle de vie, cohérence pédagogique

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-026 — Évaluation de deux stagiaires indépendants

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given deux stagiaires sont inscrits dans la même promotion
When PANDA évalue la même fiche pour chacun avec des décisions différentes
Then leurs dossiers, dates, notes et compteurs restent indépendants
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-027 — Changement de fiche sans contamination

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une fiche a été évaluée puis une autre est sélectionnée
When PANDA change le numéro dans le tiroir
Then les critères et résultats ne sont pas mélangés entre les deux fiches
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-028 — Mise à jour d’une évaluation existante

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une fiche dispose déjà d’une évaluation enregistrée
When PANDA tente d’ouvrir le parcours UI permettant de la réviser
Then les modifications permises remplacent ou historisent correctement l’évaluation sans créer de doublon ; si aucun parcours UI n’existe, signaler l’écart
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-029 — Progression après validation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une fiche du stagiaire passe de non validée à validée
When PANDA retourne au menu Fiches puis au dossier Stagiaires
Then la progression, les indicateurs et le statut du dossier reflètent le résultat réellement enregistré
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-030 — Préparée et présentée ne signifient pas validée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une fiche a une date de présentation mais une décision À retravailler
When PANDA consulte les KPI et statuts
Then les états Préparée/Présentée/Validée/À retravailler restent sémantiquement cohérents
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-031 — Respect du catalogue de la formation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une promotion est associée à une version précise du référentiel
When PANDA ouvre une fiche et son évaluation
Then seules les fiches de cette version sont utilisables ; aucune fiche hors référentiel ne peut être validée
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-032 — Référentiel modifié après évaluation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une fiche déjà évaluée dépend d’une version de référentiel
When PANDA consulte le même dossier après une modification de catalogue autorisée
Then l’évaluation historique reste lisible et correctement rattachée à sa version ; aucune réattribution silencieuse
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
21.4. Configuration et spécificités des centres

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-033 — Catalogue ECSR : 58 fiches

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given la formation ECSR a le référentiel correspondant actif
When PANDA ouvre la configuration et la liste du module
Then le catalogue présente les 58 fiches attendues si elles ont été fournies par cette version du référentiel, sans fiches inventées
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-034 — Catalogue Moto

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given sam.user2 travaille dans son centre Moto et sa formation est sélectionnée
When PANDA ouvre Fiches / Exposés et la configuration
Then les thèmes correspondent au référentiel Moto configuré, sans imposer les 58 fiches ECSR
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-035 — Catalogue Poids lourds

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given sam.user3 travaille dans son centre Poids lourds
When PANDA consulte les fiches et grilles disponibles
Then les contenus concernent la formation Poids lourds sélectionnée, sans réutilisation automatique du catalogue ECSR
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-036 — Catalogue Ambulancier

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given sam.user4 travaille dans le centre Ambulancier
When PANDA ouvre le module Fiches / Exposés
Then seuls les supports liés à la formation Ambulancier configurée sont affichés ; si aucun catalogue n’existe, l’état vide est cohérent
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-037 — Ajouter une fiche depuis Administration

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un utilisateur autorisé ouvre Configurer les fiches avec une formation valide
When PANDA utilise Ajouter, renseigne les champs exposés puis enregistre
Then la fiche est créée seulement dans le catalogue de la formation et apparaît dans les listes après actualisation
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-038 — Modifier et prévisualiser une fiche

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une fiche de recette modifiable existe dans le catalogue
When PANDA ouvre Aperçu puis Modifier et enregistre une modification
Then l’aperçu et la liste reflètent les changements de cette fiche sans altérer les autres
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-039 — Supprimer et réinitialiser le catalogue

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une fiche de recette et des évaluations sont présentes
When PANDA teste les demandes de suppression et de réinitialisation via les dialogues UI
Then les confirmations, dépendances et protections sont appliquées ; aucune donnée évaluée n’est détruite silencieusement
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
21.5. Permissions, multi-organisation et qualité

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-040 — Stagiaire sans action d’évaluation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un compte Stagiaire est authentifié dans sa promotion
When PANDA ouvre Fiches / Exposés
Then il consulte seulement les données permises et ne voit pas ou ne peut pas utiliser Évaluer
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-041 — Jury, Secrétariat et Lecture seule

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un utilisateur possède successivement ces rôles dans des organisations distinctes
When PANDA tente d’ouvrir et de sauvegarder une évaluation
Then chaque rôle peut uniquement exercer les actions autorisées dans le contexte choisi
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-042 — Changement d’organisation en cours d’écran

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given sam.user1 possède quatre appartenances avec rôles différents
When PANDA passe successivement par les quatre organisations
Then les fiches, élèves, évaluateurs, permissions et statuts changent selon le contexte sans fuite inter-centres
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-043 — Changement de formation et promotion

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une organisation dispose de plusieurs formations/promotions
When PANDA change Formation puis Promotion dans Contexte de travail
Then la liste des stagiaires et le catalogue actif sont recalculés et aucune ancienne sélection incompatible ne subsiste
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-044 — Révocation pendant l’évaluation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given l’affectation du compte évaluateur est retirée pendant que son tiroir est ouvert
When PANDA clique Enregistrer ou actualise
Then l’opération non autorisée est refusée et aucune évaluation n’est enregistrée sur l’ancien contexte
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## FIC-UI-045 — Persistance et état après reconnexion

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une évaluation a été enregistrée dans une organisation
When PANDA actualise, se déconnecte, puis se reconnecte dans la même organisation
Then la donnée est retrouvée uniquement dans le périmètre autorisé et aucun succès n’était seulement visuel
Preuves : captures avant/après, identité et rôle, Contexte de travail complet, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
21.7. Critères de sortie — Fiches / Exposés
Les 45 scénarios FIC-UI sont exécutés ou classés Bloqué / Non applicable avec justification et capture.
Au moins une fiche validée et une fiche à retravailler sont enregistrées sur les stagiaires fictifs de chaque formation disposant d’un catalogue adapté.
Les quatre organisations conservent des référentiels, évaluations, indicateurs et permissions isolés, y compris lors d’invitations croisées.
Le Contexte de travail (organisation, établissement, formation, promotion) est vérifié après toute opération pertinente et après reconnexion.
Aucun résultat d’évaluation ne doit être considéré comme confirmé sans vérification après rechargement.
Toute fonctionnalité absente, toute grille non adaptée à la formation ou toute action non branchée est signalée comme anomalie ou blocage.
Statut : RÉDIGÉE — NON EXÉCUTÉE. Prochain menu : Présences.

22. Campagne 13 — Compétences : consultation, progression et référentiels
Périmètre : menu Compétences et interactions avec Administration, Stagiaires, Conduite, Fiches / Exposés, Planning et Séances. Campagne exclusivement fonctionnelle, exécutée par QA Panda dans le navigateur. Les quatre organisations et leurs invitations croisées, créées dans les campagnes précédentes, sont conservées.
Base observée dans le frontend Angular : sélection du stagiaire (hors profil Stagiaire), cartes des compétences et pourcentages, détails des critères et niveaux, séances pédagogiques liées, tableau de la promotion, états chargement/erreur/absence de données. Aucun bouton de saisie directe d’évaluation n’est présent dans cet écran examiné : les changements sont provoqués depuis les écrans métier qui les exposent.
Préconditions : les promotions et huit stagiaires fictifs des quatre organisations ont été créés ; les référentiels sont associés à chaque formation. Les scénarios d’état vide doivent être exécutés avant création ou sur un périmètre de test neuf. Ne jamais supprimer des données déjà nécessaires aux campagnes précédentes pour recréer un état vide.
Exigence transverse : après chaque changement susceptible de toucher le périmètre ou la progression, relever Organisation > Établissement > Formation > Promotion dans « Contexte de travail » ; comparer les valeurs après actualisation. Les pourcentages ne sont pas présumés suivre une formule non documentée : vérifier leur cohérence avec les données réelles et les règles affichées.
22.1. État initial, affichage et états vides

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-001 — Ouverture du menu Compétences

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given USER-01 est connecté dans Centre Horizon ECSR et aucun stagiaire n’a encore été inscrit
When PANDA ouvre Compétences
Then L’écran reste visible, présente un état vide explicite pour les stagiaires et n’affiche aucun stagiaire ou pourcentage fictif
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-002 — Aucun référentiel disponible

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un stagiaire existe dans la promotion sélectionnée mais aucun référentiel de compétences applicable n’est disponible
When PANDA ouvre Compétences
Then Un état vide « aucune définition » ou équivalent est affiché ; aucune compétence inventée n’apparaît
Consigne : Si le jeu de données a déjà été configuré, utiliser une nouvelle formation sans référentiel, sans supprimer les données existantes.
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-003 — États de chargement et erreur

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le menu Compétences est accessible depuis l’interface
When PANDA ouvre puis recharge la page
Then L’écran n’est ni blanc ni bloqué ; chargement puis contenu ou message d’erreur compréhensible, sans faux pourcentages
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-004 — Sélecteur de stagiaires du profil Direction

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une promotion comporte deux stagiaires actifs
When PANDA ouvre Compétences en Direction
Then Le sélecteur propose uniquement les stagiaires du contexte autorisé et affiche clairement l’identité sélectionnée
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-005 — Liste et cartes des compétences

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une formation possède un référentiel et deux stagiaires rattachés
When PANDA sélectionne chaque stagiaire
Then Les cartes montrent le code, le titre et un pourcentage de progression pour les compétences réellement définies
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-006 — Indication du niveau par critère

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given des critères appartiennent à la compétence sélectionnée
When PANDA clique sur la carte de compétence
Then La zone détail affiche les critères et leurs niveaux lisibles, sans les confondre avec le pourcentage global
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-007 — Bloc des séances liées vide

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le stagiaire et la compétence n’ont aucune séance associée
When PANDA sélectionne cette compétence
Then La section séances liées présente un état vide explicite, sans historique artificiel
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-008 — Tableau de la promotion

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une promotion compte deux stagiaires et des compétences définies
When PANDA descend jusqu’au tableau de promotion
Then Le tableau affiche une ligne par stagiaire autorisé et une colonne par compétence applicable
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-009 — Accessibilité de la navigation par cartes

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P2  •  Type : E2E UI  •  Environnement : staging
Given plusieurs compétences sont affichées
When PANDA sélectionne successivement chaque carte avec souris et clavier si possible
Then La sélection active est identifiable, les détails correspondants changent et aucune carte n’entraîne d’erreur
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
22.2. Consultation individuelle et progression

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-010 — Changement de stagiaire

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given deux stagiaires de la même promotion ont des progressions différentes
When PANDA sélectionne le premier puis le second
Then Le sous-titre, les cartes, les critères, les séances liées et les pourcentages suivent le bon stagiaire
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-011 — Changement de compétence

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le stagiaire possède au moins deux compétences
When PANDA clique sur la première puis sur la seconde carte
Then La fiche détaillée et la liste de séances liées correspondent à la compétence sélectionnée
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-012 — Absence d’évaluation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une compétence est définie mais n’a aucune évaluation
When PANDA sélectionne cette compétence
Then Le niveau est non évalué ou neutre, et le taux affiché ne prétend pas que la compétence est acquise
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-013 — Niveaux de maîtrise distincts

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un même stagiaire possède des critères non évalués, en progression et acquis
When PANDA consulte la fiche correspondante
Then Chaque niveau est restitué distinctement avec libellé et style lisible
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-014 — Cohérence du pourcentage sur une compétence

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given des évaluations connues ont été enregistrées pour plusieurs critères
When PANDA observe le pourcentage avant et après un nouvel enregistrement depuis un écran d’évaluation
Then La progression évolue conformément aux règles métier et n’excède jamais 100 %
Consigne : Ne pas imposer un algorithme de calcul non confirmé ; consigner toute incohérence manifeste et les valeurs observées.
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-015 — Cohérence des taux dans le tableau

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un stagiaire présente une compétence à un taux connu
When PANDA compare la carte du stagiaire et la cellule correspondante du tableau de promotion
Then Le même stagiaire et la même compétence présentent le même taux dans les deux vues
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-016 — Séances pédagogiques liées

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une séance réelle est rattachée à une compétence et à un stagiaire
When PANDA consulte la compétence concernée
Then La séance apparaît avec sa date, son sujet, les points positifs, axes de travail et prochain objectif lorsqu’ils sont renseignés
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-017 — Pas de séance liée à une autre compétence

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given deux compétences distinctes existent et une seule possède une séance liée
When PANDA sélectionne l’autre compétence
Then La séance de la première compétence n’apparaît pas dans la seconde sans rattachement réel
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-018 — Évaluation d’un stagiaire distinct

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given le stagiaire A est évalué et le stagiaire B ne l’est pas
When PANDA compare leurs fiches et lignes du tableau
Then La progression de A ne modifie pas celle de B
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-019 — État conservé après actualisation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le stagiaire et une compétence précise sont affichés
When PANDA recharge la page
Then Les données réelles restent disponibles et l’éventuelle sélection réinitialisée correspond à une valeur autorisée
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
22.3. Référentiel et paramétrage pédagogique

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-020 — Référentiel correspondant à la formation ECSR

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given Centre Horizon ECSR utilise un référentiel ECSR valide
When PANDA consulte les codes et libellés dans Compétences
Then Les compétences affichées sont celles de la version du référentiel rattachée à la formation/promotion sélectionnée
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-021 — Référentiel propre à la moto

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given Académie Azur Deux-Roues dispose d’un référentiel adapté
When PANDA passe sur l’organisation et la formation Moto et ouvre Compétences
Then Les intitulés et critères proviennent du référentiel Moto et ne sont pas remplacés automatiquement par les compétences ECSR
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-022 — Référentiel propre au poids lourd

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given Institut Provence Poids Lourds dispose d’un référentiel adapté
When PANDA ouvre les compétences de sa promotion
Then Les compétences et critères correspondent au parcours groupe lourd réellement configuré
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-023 — Référentiel propre aux ambulanciers

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given Institut Méditerranée Ambulancier dispose de son référentiel
When PANDA affiche les compétences de sa formation DEA
Then Les compétences relèvent du référentiel de cette formation ; aucun catalogue ECSR/moto/poids lourd n’est injecté
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-024 — Changement de version du référentiel

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given deux promotions de la même formation utilisent des versions distinctes
When PANDA change de promotion dans Contexte de travail
Then Les critères et intitulés correspondent à la bonne version ; ceux d’une autre version ne sont pas mélangés
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-025 — Modification de définition depuis Administration

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un responsable habilité peut modifier une définition non verrouillée depuis Administration
When PANDA modifie un titre ou critère puis revient à Compétences
Then La modification autorisée est visible dans le contexte concerné après actualisation
Consigne : Si l’UI bloque légitimement la modification d’un référentiel utilisé, consigner le blocage attendu et utiliser un brouillon de référentiel.
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-026 — Suppression d’une compétence déjà évaluée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une définition de compétence comporte des résultats pédagogiques historiques
When PANDA tente la suppression depuis Administration si l’action existe
Then L’interface applique les dépendances et protège l’historique, sans disparition silencieuse des évaluations
Consigne : Test conditionnel : ne pas inventer une action inexistante.
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-027 — Absence de bouton de modification directe

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P2  •  Type : E2E UI  •  Environnement : staging
Given un compte Direction consulte la page Compétences
When PANDA cherche les actions d’édition sur la page
Then La page correspond au modèle de consultation ; la configuration est accessible via Administration si les droits l’autorisent
Consigne : Tout bouton inattendu doit être documenté comme écart fonctionnel et testé selon son comportement réel.
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
22.4. Interactions avec les autres menus

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-028 — Évaluation en Conduite reflétée dans Compétences

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une évaluation de conduite liée à une compétence est enregistrée pour un stagiaire
When PANDA retourne dans Compétences et sélectionne le même stagiaire
Then La progression correspondante reflète l’évaluation persistée, si cette évaluation contribue au calcul configuré
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-029 — Évaluation Fiches / Exposés reflétée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une évaluation de fiche est associée à une compétence du même référentiel
When PANDA enregistre la fiche puis ouvre Compétences
Then Le résultat est cohérent avec l’évaluation et ses liens pédagogiques réels, sans variation d’une compétence sans relation
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-030 — Programmation seule sans validation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une séance est programmée dans Planning mais non réalisée/évaluée
When PANDA consulte Compétences avant et après la programmation
Then La planification seule ne valide pas automatiquement une compétence
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-031 — Consulter dossier du stagiaire

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une compétence a été évaluée pour le stagiaire A
When PANDA compare son dossier Stagiaires et Compétences
Then Les acquis et les tendances présentés restent cohérents entre les deux écrans
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-032 — Correction d’une évaluation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une évaluation modifiable existe et le rôle est autorisé
When PANDA corrige son résultat depuis l’écran source puis revient à Compétences
Then Les progrès affichés sont recalculés selon le nouveau résultat, sans conserver l’ancienne valeur en cache
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-033 — Suppression autorisée d’une évaluation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une évaluation est supprimable et n’a pas été définitivement validée
When PANDA la supprime par l’UI source puis ouvre Compétences
Then La contribution supprimée n’est plus présentée comme acquise, sans effacer les autres résultats
Consigne : Conditionnel selon la politique de conservation et les actions UI disponibles.
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-034 — Évaluation refusée ne modifie rien

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un compte sans permission tente d’évaluer une compétence depuis le module source
When PANDA déclenche l’action interdite puis consulte Compétences
Then Aucun taux ni critère n’a changé à la suite du refus
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
22.5. Permissions, multi-organisation et contexte

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-035 — Stagiaire ne peut changer d’identité

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un compte Stagiaire est connecté et rattaché à sa formation
When PANDA ouvre Compétences
Then Il voit uniquement ses compétences autorisées et ne peut sélectionner un autre stagiaire
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-036 — Direction sélectionne un stagiaire autorisé

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given USER-01 est Direction de son propre centre
When PANDA sélectionne successivement les deux stagiaires ECSR
Then L’accès est permis et le contenu correspond à chacun sans exposition d’autres centres
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-037 — Rôle Jury ou Secrétariat

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given USER-01 possède une appartenance à un autre centre avec rôle Jury ou Secrétariat
When PANDA ouvre Compétences et tente les actions visibles
Then Les lectures et actions sont limitées aux permissions du rôle dans cette organisation
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-038 — Lecture seule et formateur

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given des comptes dotés des rôles Lecture seule et Formateur existent
When PANDA ouvre Compétences et les écrans sources d’évaluation
Then La consultation et les actions d’évaluation sont accordées ou refusées selon les permissions effectives, sans accès implicite à l’écriture
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-039 — Basculement entre les quatre organisations

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given USER-01 a quatre appartenances croisées actives
When PANDA change d’organisation successivement et ouvre Compétences
Then Stagiaires, référentiels, progressions et permissions se réinitialisent selon l’organisation choisie
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-040 — Changement établissement et formation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une organisation contient plusieurs établissements ou formations
When PANDA change successivement établissement et formation dans Contexte de travail
Then Les stagiaires et compétences hors périmètre disparaissent et les sélections invalides sont effacées
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-041 — Changement de promotion

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given deux promotions ont des inscriptions et référentiels distincts
When PANDA change de promotion dans Contexte de travail
Then Le tableau et le sélecteur de stagiaires sont limités à la promotion choisie
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-042 — Accès direct par URL après changement d’organisation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given le navigateur possède l’URL d’une ancienne vue Compétences
When PANDA passe dans une autre organisation puis recharge cette URL
Then Aucune information du centre précédent ne réapparaît ; le contexte courant est respecté
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-043 — Retrait d’une appartenance en session

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un compte conserve Compétences ouvert pendant qu’un autre administrateur retire son accès au centre
When PANDA actualise la page puis tente de consulter l’ancien contexte
Then Les données du centre retiré deviennent inaccessibles ; ses autres organisations restent disponibles
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-044 — Persistance après reconnexion

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une évaluation existe dans l’organisation ECSR uniquement
When PANDA se déconnecte, se reconnecte et compare ECSR et Moto
Then L’évaluation reste uniquement visible dans le bon centre et la progression ne fuit pas
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## COM-UI-045 — Mise à jour de la page après changement du référentiel

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un responsable autorisé a changé la configuration d’un référentiel
When PANDA retourne à Compétences puis actualise
Then La page affiche la nouvelle configuration autorisée ou un message de version incompatible, sans conserver d’anciennes données trompeuses
Preuves : capture avant/après, identité et rôle, Contexte de travail complet, valeurs observées, résultat après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
22.6. Critères de sortie — Compétences
Les 45 scénarios COM-UI sont exécutés ou classés Bloqué / Non applicable avec justification et captures.
Les quatre centres présentent uniquement les référentiels et critères réellement associés à leurs formations ; les 8 stagiaires fictifs conservent chacun leur propre progression.
Les mêmes évaluations produisent des résultats cohérents entre Compétences et les autres écrans pédagogiques ; aucune séance simplement planifiée n’est considérée comme compétence acquise.
Chaque bascule d’organisation, établissement, formation ou promotion réinitialise les sélections incompatibles et n’expose aucune donnée d’un autre centre.
Les droits de consultation et d’évaluation sont vérifiés depuis l’interface pour les rôles réellement disponibles ; aucun résultat n’est considéré confirmé sans réouverture ou rechargement.
Statut : RÉDIGÉE — NON EXÉCUTÉE. Campagne Présences ajoutée en section 23.
23. Campagne Présences — appel, assiduité et émargement
Version 1.5 — Recette fonctionnelle depuis la seule interface Web, après les campagnes Promotions, Stagiaires, Planning et Séances. Exécution par QA Panda sur staging, sans accès direct à la base ou aux API.
Données : conserver les quatre comptes sam.user1@email.com à sam.user4@email.com, mot de passe initial Demo@123, et les centres fictifs ECSR, Moto, Poids lourds et Ambulancier. Utiliser les huit stagiaires de recette déjà créés (deux par centre), leurs promotions respectives et au moins une séance planifiée par centre. Les noms de formations, référentiels et séances doivent correspondre à la spécialité du centre.
Règle transversale : valider le Contexte de travail après chaque transition significative et toute écriture. Une organisation peut avoir plusieurs établissements, formations et promotions ; aucun apprenant ne doit être mélangé à un autre périmètre. Les résultats d’une action doivent être visibles après actualisation, sans se contenter du toast de succès.
Portée réelle de l’interface examinée : les quatre états Présent / Retard / Absent / Justifié, les horaires d’arrivée et départ, la durée calculée en lecture seule, le commentaire/justificatif, l’enregistrement et les demandes de signature individuelle ou groupée pour les utilisateurs autorisés. Le profil Stagiaire possède une vue de consultation personnelle. La sélection de séance peut dépendre d’un écran précédent : ne pas inventer de sélecteur sur cette page.
23.1. Affichage initial, séance et données de présence

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-001 — Ouverture du menu sans séance valide

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given une organisation existe mais aucune séance exploitable n’est sélectionnée
When PANDA ouvre Présences depuis le menu
Then la page affiche un état vide ou un prérequis explicite ; aucun appel fictif n’est affiché et l’enregistrement n’invente pas de séance
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-002 — Séance et promotion affichées

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given la séance ECSR de recette est ouverte depuis Planning ou Séances
When PANDA consulte l’en-tête Présences
Then la date, le début, la fin et la promotion correspondent à la séance choisie
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-003 — Quatre indicateurs principaux

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given la séance a deux stagiaires, sans appel enregistré
When PANDA observe les cartes Présents, Retards, Absents et Heures manquées
Then les valeurs reflètent l’état réellement chargé ; les comptes en attente ne sont pas comptés comme présents
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-004 — Liste des stagiaires de la séance

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given une promotion possède deux inscriptions actives
When PANDA ouvre l’appel correspondant
Then seuls les stagiaires inscrits et admissibles à cette séance apparaissent avec leur identité et le suivi d’assiduité
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-005 — Aucune contamination entre promotions

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given deux promotions existent dans le même centre
When PANDA bascule de la séance de la première promotion vers celle de la seconde
Then la liste des inscrits et les indicateurs sont recalculés pour la bonne promotion
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-006 — Aucun stagiaire dans une séance vide

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given une séance existe dans une promotion sans inscription
When PANDA ouvre Présences
Then un état vide est lisible, aucun stagiaire fictif n’apparaît et la sauvegarde ne produit pas de faux succès
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-007 — Accès à Présences depuis Séances

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given une séance créée par le parcours Séances est enregistrée
When PANDA utilise le parcours « Créer puis faire l’appel » ou le lien vers Présences
Then l’appel correspond à la séance réellement créée ; aucune redirection ne remplace la sauvegarde préalable
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-008 — Contexte conservé après actualisation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given la séance Moto est affichée dans son organisation
When PANDA actualise le navigateur
Then l’organisation, la formation, la promotion, la séance et ses stagiaires restent cohérents
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
23.2. Statuts, calculs horaires et sauvegarde

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-009 — Déclarer un stagiaire présent

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given une séance de deux heures possède un inscrit en attente
When PANDA sélectionne Présent puis enregistre
Then l’état Présent persiste et la durée attendue est prise en compte selon le barème de la séance
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-010 — Déclarer un retard

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given une séance de deux heures possède un stagiaire en attente
When PANDA choisit Retard, saisit une arrivée et un départ cohérents, puis enregistre
Then le statut et la durée réelle sont conservés ; les heures manquées se calculent sur l’écart avec la séance
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-011 — Déclarer une absence

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given une séance planifiée possède un stagiaire en attente
When PANDA sélectionne Absent puis enregistre
Then la durée réalisée est nulle et les heures manquées correspondent à la durée prévue, sans valeur négative
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-012 — Déclarer une absence justifiée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given un stagiaire est absent de la séance
When PANDA sélectionne Justifié, saisit un motif et enregistre
Then le statut justifié et le motif persistent ; les heures perdues sont visibles selon la règle métier sans rattrapage automatique indu
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-013 — Modifier un statut avant enregistrement

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given un stagiaire est marqué Absent mais non sauvegardé
When PANDA le bascule à Présent puis sauvegarde
Then un seul état final Présent est enregistré et les indicateurs sont recalculés une seule fois
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-014 — Corriger un appel déjà sauvegardé

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given un stagiaire est enregistré comme Absent
When PANDA le passe à Retard avec horaires valides puis enregistre
Then la correction remplace l’ancien état et les totaux de présence et d’heures sont rectifiés
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-015 — Départ antérieur à arrivée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given un stagiaire est marqué en Retard
When PANDA saisit une heure de départ antérieure à l’arrivée et tente d’enregistrer
Then la durée incohérente n’est pas comptabilisée ni conservée comme valeur valide ; une erreur claire ou un blocage de saisie est présenté
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-016 — Horaire incomplet

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given un stagiaire est marqué en Retard
When PANDA saisit uniquement l’arrivée et tente d’enregistrer
Then une durée réalisée erronée n’est pas validée et les heures à rattraper ne sont pas calculées sur une valeur obsolète
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-017 — Durée supérieure à celle de la séance

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given une séance de deux heures est sélectionnée
When PANDA renseigne un intervalle de présence de trois heures puis tente de sauvegarder
Then la durée comptabilisée respecte la règle serveur et ne dépasse pas les bornes admissibles de la séance
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-018 — Champ durée non éditable

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given un stagiaire en Retard possède des horaires valides
When PANDA tente de modifier directement le champ Durée réelle
Then le champ reste en lecture seule ; seul un changement des horaires autorisés peut modifier le calcul
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-019 — Retard à cheval sur l’horaire de séance

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given une séance de 09:00 à 11:00 existe
When PANDA indique une arrivée 09:30 et un départ 11:00 puis sauvegarde
Then la durée réalisée est 1 h 30 et les heures manquées 0 h 30, sous réserve du même intervalle sans pause
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-020 — Absence et cumul des heures à rattraper

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given un stagiaire possède déjà des heures à rattraper
When PANDA enregistre une nouvelle absence non justifiée sur une séance distincte
Then le cumul évolue du seul montant admissible, sans compter deux fois la même séance
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-021 — Aucune double comptabilisation sur sauvegarde répétée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given un appel complet vient d’être enregistré
When PANDA clique plusieurs fois sur Enregistrer ou actualise puis sauvegarde sans modification
Then aucun doublon de présence ni heure manquée supplémentaire n’apparaît
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-022 — Échec de sauvegarde et message exact

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given une panne réseau ou un rejet serveur est observé pendant un enregistrement
When PANDA vérifie le retour utilisateur puis actualise la page
Then aucune confirmation trompeuse n’est affichée et les valeurs non enregistrées ne sont pas présentées comme persistantes
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-023 — Sauvegarde pendant un état en attente

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given tous les inscrits sont encore en attente
When PANDA consulte le bouton Enregistrer
Then le comportement de désactivation correspond à l’interface ; aucun appel fictif ne peut être sauvegardé
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-024 — Commentaires de retard et absence

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given un élève est en retard puis un autre absent
When PANDA renseigne les commentaires des deux lignes et enregistre
Then les commentaires restent attachés à la bonne personne et à la bonne séance après rechargement
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
23.3. Signatures d’émargement et consultation stagiaire

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-025 — Demander une signature individuelle

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given un élève Présent a un appel enregistré et le compte possède signatures.request
When PANDA demande sa signature depuis Présences
Then une demande est créée pour le bon stagiaire et la bonne séance ; l’état s’affiche dans l’historique
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-026 — Envoyer plusieurs demandes de signature

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given deux stagiaires Présents ou en Retard sont enregistrés sans demande active
When PANDA coche les deux personnes puis utilise Envoyer la sélection
Then deux demandes ciblées sont créées ; le bilan des envois correspond aux résultats
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-027 — Signature impossible avant enregistrement

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given une modification d’appel n’a pas été sauvegardée
When PANDA tente de demander une signature
Then l’interface exige d’enregistrer d’abord et n’émet aucune demande prématurée
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-028 — Exclure les absents et justifiés

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given une séance comporte un Présent, un Retard, un Absent et un Justifié
When PANDA observe les candidats à la signature
Then seuls les états admissibles apparaissent pour l’envoi de signature
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-029 — Empêcher un doublon de demande active

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given une demande de signature est déjà en attente ou signée
When PANDA retourne sur la liste et tente de renvoyer la même demande
Then le système ne multiplie pas les demandes pour une même séance et un même stagiaire
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-030 — Historique des demandes et lien

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given une demande de signature a été envoyée
When PANDA actualise l’historique et ouvre son lien
Then le détail consulté appartient au bon stagiaire et à la bonne séance, avec un statut cohérent
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-031 — Échec partiel des demandes groupées

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given une partie des demandes groupées échoue
When PANDA observe le bilan et rouvre l’historique
Then le nombre envoyé et échoué est cohérent ; les succès existants ne sont pas masqués et les échecs sont signalés
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-032 — Vue personnelle Stagiaire

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given un stagiaire de recette est connecté avec le rôle Stagiaire
When PANDA ouvre Présences et consulte sa séance
Then seuls son statut, ses heures et ses demandes de signature personnelles sont affichés, sans liste des autres inscrits
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-033 — Interdiction de modifier en tant que stagiaire

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given un utilisateur Stagiaire visualise sa présence
When PANDA cherche à changer un statut ou sauvegarder l’appel
Then aucune commande de modification n’est accessible ou acceptée
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-034 — Demande de signature visible côté stagiaire

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given une signature a été demandée au stagiaire connecté
When PANDA ouvre Présences puis la demande
Then la demande personnelle est accessible et pointe vers le bon émargement, sans document d’un tiers
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
23.4. Permissions, quatre centres et Contexte de travail

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-035 — Rôle Secrétariat et justificatifs

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given un utilisateur a le rôle Secrétariat dans le centre Moto
When PANDA ouvre l’appel et renseigne le champ Justification
Then la saisie administrative fonctionne uniquement selon ses permissions et n’ouvre pas de droits d’autres organisations
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-036 — Formateur affecté et absence de droit hors périmètre

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given un compte est formateur dans une promotion et non affecté à une autre
When PANDA tente l’appel de la première puis l’accès à celui de la seconde
Then les actions permises restent limitées au périmètre réel du formateur
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-037 — Rôle Jury sans autorisation d’appel

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given sam.user1 possède le rôle Jury dans une autre organisation
When PANDA ouvre directement /presences dans cette organisation
Then aucune modification non autorisée ne peut être enregistrée même via une URL directe
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-038 — Rôle Lecture seule

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given un compte de recette autorisé a seulement un droit de consultation
When PANDA ouvre Présences et tente de modifier les états
Then la lecture est permise uniquement si prévue, mais toute écriture non autorisée est refusée
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-039 — Bascule entre les quatre organisations

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given sam.user1 est membre des centres ECSR, Moto, Poids lourds et Ambulancier
When PANDA change successivement d’organisation pendant la consultation de Présences
Then les séances, promotions, inscrits, indicateurs, droits et signatures sont recalculés sans donnée résiduelle du centre précédent
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-040 — Changement de promotion dans une organisation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given un centre possède deux promotions et deux séances différentes
When PANDA change de promotion et de séance
Then les listes et heures suivent uniquement le contexte sélectionné ; aucune ligne modifiée non enregistrée n’est reportée ailleurs
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-041 — Accès direct à une ancienne séance étrangère

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given une URL de présence ECSR est conservée par le navigateur
When PANDA passe en contexte Ambulancier puis ouvre cette ancienne URL
Then l’accès est refusé ou recontextualisé sans afficher de données ECSR dans Ambulancier
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-042 — Révocation d’affectation pendant une session

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given un administrateur retire l’accès d’un utilisateur à la promotion en cours
When PANDA actualise puis tente de sauvegarder
Then l’écriture est refusée, les données privées disparaissent et les autres appartenances restent disponibles
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-043 — Concordance des heures dans les autres menus

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given une absence et un retard ont été enregistrés sur une séance
When PANDA consulte dossier Stagiaires, Promotions et statistiques disponibles
Then les cumuls d’heures et d’assiduité concordent, sans mise à jour seulement locale à Présences
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-044 — Séances distinctes pour ECSR, Moto, PL et Ambulancier

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given chaque centre dispose de sa propre séance et deux inscrits
When PANDA réalise un appel nominal pour chaque centre puis revient à ECSR
Then les quatre appels persistent indépendamment, chaque personne conserve son statut et son historique
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-045 — Dates et durées cohérentes après reconnexion

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given un appel a été enregistré puis l’utilisateur se déconnecte
When PANDA se reconnecte et retrouve exactement la même séance
Then statuts, commentaires, heures et demandes de signature persistent sans erreur de contexte
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## PRE-UI-046 — Retrait des données fictives

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Préconditions : Compte Direction et données de recette de son organisation accessibles.
Given le jeu de données de recette ne comprend que les quatre organisations et les inscriptions créées
When PANDA compare tous les appels disponibles et les comptes
Then aucune séance ou personne d’exemple codée en dur n’apparaît hors des données créées en UI
Preuves : capture avant/après, compte et rôle, organisation / établissement / formation / promotion actifs, valeurs calculées et résultat après actualisation. Lorsqu’une action change les données, vérifier aussi le dossier stagiaire et les écrans liés.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
23.5. Critères de sortie — Présences
Les 46 scénarios PRE-UI sont exécutés, ou classés Bloqué / Non applicable avec justification, et aucune anomalie critique ouverte n’est déclarée réussie.
La création d’un appel, sa correction, sa sauvegarde, son rechargement et sa cohérence avec les modules liés sont démontrés depuis l’UI.
Les horaires incohérents, durées négatives ou excessives, doublons et comptes non autorisés ne peuvent pas produire de données valides trompeuses.
Les signatures individuelles et groupées ne sont demandées qu’après sauvegarde et pour des stagiaires admissibles ; la vue stagiaire est strictement personnelle.
Chaque bascule de Contexte de travail entre quatre organisations vérifie la séparation des séances, statuts, personnes, totaux, signatures et permissions.
Statut : RÉDIGÉE — NON EXÉCUTÉE. Prochain menu : Stages.

24. Campagne Stages — périodes en entreprise et tuteurs
Version 1.6 — Scénarios fonctionnels Given / When / Then réalisables depuis l’interface Web par QA Panda, en staging. Conserver l’intégralité des campagnes précédentes. Statut initial : RÉDIGÉE — NON EXÉCUTÉE.
Jeu de données : sam.user1@email.com (ECSR), sam.user2@email.com (Moto), sam.user3@email.com (Poids lourds), sam.user4@email.com (Ambulancier), chacun Direction de son centre et membre des trois autres selon les invitations croisées. Mot de passe initial Demo@123 ; DemoDemo@123 pour les seuls essais de modification de mot de passe. Les huit stagiaires fictifs et les promotions des campagnes précédentes sont réutilisés.
Précondition transversale : vérifier à chaque étape le Contexte de travail (Organisation / Établissement / Formation / Promotion), le compte connecté et ses permissions. Après toute écriture, contrôler la liste, la réouverture de la fiche et la persistance après actualisation ; les données métier proviennent de l’API et ne sont pas simulées. Ne jamais considérer un message de succès seul comme preuve.
Périmètre confirmé du frontend examiné : indicateurs heures prévues / réalisées / restantes / stages incomplets, cartes de période, actions de réaffectation du tuteur, annulation / suppression / archivage avec motif selon action, panneau « Nouvelle période » (stagiaire, entreprise, ville, tuteur, e-mail, téléphone, dates, heures prévues, convention reçue, notes), espace Tuteur (heures, observation, activités, évaluation). Les fonctionnalités documentaires non exposées sont signalées Bloqué / Non applicable, pas inventées.
24.1. État initial et navigation

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-001 — Ouverture initiale et état vide

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given aucune période de stage n’a été créée dans le centre sélectionné
When PANDA ouvre Stages
Then les indicateurs sont à zéro, la liste est vide et aucune période fictive n’apparaît
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-002 — Indicateurs sans stage

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given aucune période n’existe
When PANDA contrôle Heures prévues, Heures réalisées, Heures restantes et Stages incomplets
Then les quatre valeurs représentent l’absence de données sans erreur ni NaN
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-003 — Ouverture du panneau Nouvelle période

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given le compte Direction a le droit de créer une période
When PANDA clique Nouvelle période
Then le panneau s’ouvre et présente stagiaire, entreprise, ville, tuteur, coordonnées, dates, heures, convention et notes
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-004 — Liste stagiaires contextualisée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given le centre ECSR contient deux stagiaires inscrits et le centre Moto en contient deux autres
When PANDA ouvre le sélecteur Stagiaire dans ECSR
Then seuls les stagiaires éligibles du contexte ECSR apparaissent
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-005 — Fermeture du panneau sans création

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P2  •  Type : E2E UI  •  Environnement : staging
Given PANDA a saisi des informations non enregistrées
When PANDA ferme le panneau ou annule
Then aucune période n’est créée et la liste reste inchangée
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-006 — Rechargement écran vide

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le centre Ambulancier ne possède pas de période
When PANDA actualise la page Stages
Then les indicateurs et la liste restent vides et l’interface demeure utilisable
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-007 — Navigation depuis dossier stagiaire

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un stagiaire du centre est sélectionné
When PANDA accède à son suivi de stage depuis la fiche individuelle si un lien UI existe
Then la navigation affiche uniquement les périodes de ce stagiaire ou le manque de lien est classé Bloqué
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
24.2. Création et contrôle du formulaire

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-008 — Création d’une période ECSR réaliste

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une promotion ECSR et un stagiaire y sont inscrits
When PANDA crée un stage dans une auto-école fictive de Nice, tuteur fictif, dates cohérentes et heures prévues positives
Then la période apparaît dans Stages et dans le dossier du stagiaire avec toutes les valeurs saisies
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-009 — Création d’une période Moto

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given la formation Moto et un stagiaire existent
When PANDA crée une période en entreprise de formation deux-roues à Antibes
Then le stage est associé seulement à l’organisation Moto et à son stagiaire
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-010 — Création d’une période Poids lourds

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given la formation Poids lourds est configurée
When PANDA crée une période dans un organisme fictif de transport à Marseille
Then le stage est visible uniquement dans le contexte Poids lourds
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-011 — Création d’une période Ambulancier

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given la formation Ambulancier et un inscrit existent
When PANDA crée une période dans une entreprise fictive de transport sanitaire à Toulon
Then le stage conserve son type et ses données propres sans imposer les compétences ECSR
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-012 — Champs obligatoires manquants

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given le panneau Nouvelle période est ouvert
When PANDA soumet sans stagiaire, entreprise, ville, tuteur, dates ni heures
Then l’enregistrement est refusé et les erreurs sont visibles près des champs concernés
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-013 — Email tuteur invalide

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le panneau est ouvert avec les champs obligatoires valides
When PANDA saisit un e-mail tuteur de format invalide puis soumet
Then une erreur de validation est affichée et aucune donnée incorrecte n’est enregistrée
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-014 — Période avec date de fin antérieure

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given le panneau de création est accessible
When PANDA saisit une date de fin antérieure au début
Then la création est bloquée avec une explication explicite
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-015 — Heures prévues négatives ou nulles

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une période est en préparation
When PANDA renseigne 0 puis une valeur négative dans Heures prévues
Then aucun stage à durée invalide n’est enregistré
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-016 — Saisie décimale et précision des heures

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le formulaire autorise des heures décimales
When PANDA saisit un total de 35,5 heures, puis sauvegarde
Then la valeur persiste sans troncature ni arrondi incohérent ou la règle admise est explicitée
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-017 — Convention reçue non cochée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le stage est prêt à être enregistré
When PANDA laisse Convention reçue décochée puis valide
Then le statut documentaire est fidèlement conservé ; aucun document ne se déclare reçu implicitement
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-018 — Convention reçue cochée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une période avec convention disponible est créée
When PANDA coche Convention reçue, enregistre, puis rouvre la période
Then l’indicateur de réception reste exact et persistant
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-019 — Notes et coordonnées du tuteur

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given les champs facultatifs sont accessibles
When PANDA renseigne téléphone, e-mail et notes avec des valeurs fictives
Then ces informations sont restituées fidèlement dans les vues correspondantes
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-020 — Double clic sur Enregistrer

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given le formulaire complet est valide
When PANDA double-clique rapidement sur Valider / Créer
Then une seule période est créée ; aucune duplication ni faux succès
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-021 — Période d’un stagiaire non inscrit

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given le contexte ne comporte pas de stagiaire inscrit à la promotion
When PANDA tente de créer une période
Then la création est empêchée et la raison apparaît dans l’interface
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
24.3. Suivi, heures et cycle de vie

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-022 — Affichage des détails après création

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une période ECSR existe
When PANDA ouvre la carte de période
Then stagiaire, entreprise, tuteur, dates, statut, heures, activités et observations concordent
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-023 — Heures et progression initiale

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une période de 140 heures vient d’être créée sans heure réalisée
When PANDA consulte les compteurs et la jauge
Then heures réalisées 0, restantes 140 et progression 0 % ou règle métier correctement expliquée
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-024 — Mise à jour heures par le tuteur

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un tuteur autorisé possède la période
When PANDA, connecté comme tuteur, saisit 35 heures réalisées et enregistre
Then la période affiche 35 réalisées, 105 restantes et la progression cohérente après actualisation
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-025 — Refus d’heures négatives

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given l’espace Tuteur est accessible
When PANDA tente de saisir −1 heure réalisée
Then le bouton est désactivé ou l’enregistrement est refusé sans modifier les compteurs
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-026 — Refus heures au-delà du prévu

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given la période prévoit 140 heures
When PANDA saisit 141 heures réalisées
Then l’application empêche la validation et ne dépasse pas le plafond prévu
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-027 — Observation tuteur persistante

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le tuteur a accès à une période
When PANDA rédige une observation et sauvegarde les heures
Then l’observation réapparaît dans l’espace Tuteur et Stages après actualisation
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-028 — Changement état d’activité

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une activité de stage est proposée au tuteur
When PANDA passe l’activité de En attente à Réalisée puis enregistre
Then le statut est mis à jour sans modifier les autres activités
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-029 — Activité non applicable

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une activité n’est pas pertinente pour le stage
When PANDA choisit Non applicable et ajoute un commentaire
Then le statut et le commentaire persistent et la progression ne compte pas l’activité comme réalisée à tort
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-030 — Réaffectation du tuteur

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une période possède un tuteur initial et une autre personne éligible existe
When PANDA ouvre Réaffecter et saisit le nom et l’e-mail du nouveau tuteur
Then la réaffectation réussit, le nouveau tuteur voit la période et l’ancien perd son accès si la politique le prévoit
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-031 — Réaffectation sans e-mail

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le panneau Réaffecter est ouvert
When PANDA efface l’e-mail du nouveau tuteur puis valide
Then l’action est bloquée et le tuteur initial est conservé
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-032 — Annulation avec motif

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une période active existe
When PANDA clique Annuler, saisit un motif puis confirme
Then la période passe à l’état attendu, conserve son historique et n’est plus considérée active
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-033 — Annulation sans motif

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given la confirmation d’annulation est ouverte
When PANDA tente de confirmer sans motif
Then la confirmation est bloquée ; le statut de la période reste inchangé
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-034 — Archivage d’une période

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une période est éligible à l’archivage
When PANDA utilise Archiver depuis la carte
Then le statut devient archivé sans faire disparaître l’historique métier requis
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-035 — Suppression avec motif et dépendances

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une période possède des heures ou évaluations et la suppression est proposée
When PANDA demande sa suppression avec un motif
Then la règle métier protège l’historique ou confirme la suppression autorisée ; aucune donnée orpheline ni faux succès
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
24.4. Évaluations et espace Tuteur

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-036 — Espace Tuteur : uniquement périodes affectées

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un compte Tuteur possède une période affectée
When PANDA ouvre l’espace Tuteur
Then seules ses périodes autorisées apparaissent, sans accès aux périodes des autres centres
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-037 — Évaluation sans synthèse

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given le formulaire d’évaluation est ouvert
When PANDA laisse le champ Synthèse vide et clique Soumettre
Then la soumission est empêchée et aucune évaluation vide n’est créée
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-038 — Évaluation renseignée et validée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un tuteur peut évaluer sa période
When PANDA saisit synthèse, points forts, améliorations, sélectionne Oui et soumet
Then une évaluation validée apparaît dans l’historique avec l’auteur et la date
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-039 — Évaluation non validée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une période est évaluable
When PANDA saisit une synthèse, sélectionne Non puis soumet
Then la décision non validée est visible sans être confondue avec Validée
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-040 — Évaluation sans décision

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le sélecteur permet Non évalué
When PANDA renseigne la synthèse, laisse la décision non évaluée et soumet
Then le système conserve l’état sans décision ou explique clairement la restriction
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-041 — Évaluation et dossier stagiaire

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une évaluation de stage est sauvegardée
When PANDA ouvre Stagiaires puis le dossier concerné
Then le suivi de stage et les résultats affichés sont cohérents avec l’évaluation
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-042 — Documents non disponibles dans l’UI

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P2  •  Type : E2E UI  •  Environnement : staging
Given l’écran montre des badges de documents mais pas de dépôt disponible
When PANDA cherche une action de dépôt/aperçu de convention
Then le cas est noté Bloqué si exigé et absent ; aucune action d’upload n’est inventée
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
24.5. Multi-organisation, permissions et synchronisation

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-043 — Choix d’organisation après connexion multi-tenant

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given sam.user1@email.com appartient aux quatre centres avec rôles distincts
When PANDA change d’organisation depuis le Contexte de travail
Then Stages affiche seulement les périodes du centre actif et les droits de son rôle courant
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-044 — Aucune fuite à la bascule ECSR → Moto

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given ECSR et Moto possèdent chacun au moins une période
When PANDA passe de ECSR à Moto puis revient à ECSR
Then les périodes, heures, évaluations et tuteurs restent strictement séparés
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-045 — Droits de modification selon rôle

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un compte est Direction dans son centre et Jury dans un autre
When PANDA tente de créer ou modifier un stage dans le centre où il est Jury
Then les actions non permises sont absentes ou refusées, sans réutilisation des droits Direction
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-046 — Ancienne URL après changement de centre

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given PANDA connaît l’URL d’une période ECSR
When PANDA change le contexte sur Ambulancier puis ouvre l’ancienne URL
Then aucune donnée ECSR ne fuit dans le contexte Ambulancier ; accès refusé ou réorientation sûre
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-047 — Révocation de tuteur en session

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un tuteur a sa session ouverte et son affectation est retirée
When PANDA actualise l’espace Tuteur et essaie de sauvegarder
Then l’écriture devient impossible et les autres affectations du compte restent intactes
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-048 — Isolation des indicateurs et du Contexte de travail

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given les quatre centres ont des périodes avec nombres d’heures différents
When PANDA parcourt les quatre organisations et contrôle les indicateurs
Then chaque organisation affiche ses totaux propres et chaque changement de contexte rafraîchit les vues sans réutiliser les chiffres précédents
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-049 — Persistance après reconnexion

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given des périodes, heures et évaluations ont été enregistrées
When PANDA ferme la session puis se reconnecte avec le même utilisateur
Then les périodes autorisées sont retrouvées avec les valeurs exactes et sans données inter-tenant
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-UI-050 — États d’erreur et absence de faux succès

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une sauvegarde ne peut pas aboutir en raison d’une erreur serveur ou d’une perte réseau
When PANDA exécute l’action depuis le navigateur
Then un message d’erreur apparaît, aucun succès fictif ni modification non persistée n’est conservé comme final
Preuves : capture avant / après ; compte, rôle et Contexte de travail complets ; résultat visible dans Stages et, si pertinent, dans Stagiaires ; vérification après actualisation.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
24.6. Critères de sortie — Stages
Les 50 scénarios STA-UI sont exécutés ou classés Bloqué / Non applicable avec justification et preuve ; aucune anomalie P0 ouverte ne vaut réussite.
Pour chaque centre, au moins une période réaliste est créée et retrouvée après rechargement, avec tuteur, dates, heures, documents et états cohérents.
Les heures réalisées, restantes et les progressions sont concordantes entre Stages, espace Tuteur et dossiers stagiaires.
Les évaluations et changements de cycle de vie demeurent traçables ; les opérations non autorisées sont refusées.
Le Contexte de travail est contrôlé après chaque modification pertinente et les quatre organisations conservent leurs données indépendantes.
Statut : RÉDIGÉE — NON EXÉCUTÉE. Prochain module à approfondir : Documents.

25. Campagne Documents — bibliothèque documentaire
Version 1.7 | Recette E2E exclusivement via l’interface utilisateur | Staging | Statut : RÉDIGÉE — NON EXÉCUTÉE
Périmètre : /documents — cartes, catégories, recherche, import, aperçu, téléchargement, remplacement, suppression, droits et contexte. Les 4 comptes Direction et les 4 organisations définis en couverture sont réutilisés. Aucun accès direct à la base ou aux API ne doit être nécessaire pour valider un scénario.
25.1. Préparation de la campagne et jeux de données
Précondition : les campagnes 01–24 ont créé les quatre organisations, établissements, formations, promotions, stagiaires et affectations nécessaires. Avant tout import, enregistrer l’organisation, l’établissement, la formation et la promotion sélectionnés.
Fichiers de test non sensibles : ECSR_Guide_Seance_2027.pdf, Moto_Consignes_Plateau_2027.pdf, PL_Manoeuvres_2027.pdf, DEA_Protocoles_Transport_2027.pdf, ainsi qu’un DOCX et un fichier de format non pris en charge pour tester les validations. Générer ou utiliser des contenus fictifs ; aucune donnée patient ou stagiaire réelle.
Chaque fichier comporte à l’intérieur un texte d’identification unique : « RECETTE / CENTRE / TYPE / VERSION ». PANDA doit pouvoir distinguer un véritable aperçu du fichier d’une vignette générique.
Les fonctions non proposées par l’interface (édition des métadonnées, sélection de catégorie/visibilité à l’import, etc.) sont à qualifier comme écart ou Bloqué, jamais à considérer comme validées.
25.2. Scénarios Given / When / Then
A — État initial

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-001 — Ouverture de la bibliothèque

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une organisation sans document métier est sélectionnée
When PANDA ouvre Documents
Then le titre, la recherche, les catégories et le message de bibliothèque vide sont visibles ; aucune carte fictive
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-002 — Comptages à zéro

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given la bibliothèque est vide
When PANDA consulte les catégories
Then Toutes indique zéro et aucune catégorie inexistante n’est artificiellement remplie
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-003 — Organisation active affichée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given sam.user1 est connecté à son organisation ECSR
When PANDA vérifie le Contexte de travail puis ouvre Documents
Then la liste correspond à ECSR, pas aux fichiers des autres centres
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-004 — Filtre et recherche à vide

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given la bibliothèque est vide
When PANDA saisit un mot dans Rechercher
Then aucune erreur ni carte fictive, et le champ reste utilisable
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-005 — Aucune action sur document absent

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given aucun document n’est présent
When PANDA parcourt la page
Then aucun bouton Aperçu/Télécharger/Remplacer/Supprimer d’un document inexistant n’est visible
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
B — Import

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-006 — Import ECSR réel

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given sam.user1 est Direction ECSR, contexte ECSR actif et un PDF fictif est disponible
When PANDA choisit Importer un document puis le PDF ECSR
Then la nouvelle carte est créée une seule fois, avec titre, auteur, format et informations cohérentes
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-007 — Import Moto

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given sam.user2 est Direction Moto
When PANDA importe le PDF Moto dans son contexte
Then le fichier apparaît dans Moto et pas dans ECSR
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-008 — Import Poids lourds

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given sam.user3 est Direction Poids lourds
When PANDA importe le PDF PL
Then le document est visible uniquement dans le bon centre
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-009 — Import Ambulancier

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given sam.user4 est Direction Ambulancier
When PANDA importe le PDF DEA
Then le document figure seulement dans le contexte Ambulancier
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-010 — Annulation de sélection

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le sélecteur de fichiers vient de s’ouvrir
When PANDA annule sans choisir de fichier
Then aucun document n’est créé ni notification de réussite affichée
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-011 — Double clic sur Importer

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un fichier valide est sélectionné
When PANDA tente deux imports rapprochés
Then l’interface évite un doublon involontaire ou signale clairement un conflit
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-012 — Nom Unicode et espaces

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un PDF de test au nom accentué est disponible
When PANDA importe « Sécurité – évaluation 2027.pdf »
Then le nom est lisible et la carte reste consultable
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-013 — Format interdit ou illisible

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un fichier de format interdit ou corrompu est prêt
When PANDA l’importe
Then le système accepte explicitement le format si supporté ou affiche un refus clair sans faux succès
Note de vérification : Le format autorisé exact n’est pas documenté dans le formulaire HTML ; ne pas inventer de taille limite.
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-014 — Fichier vide

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un fichier de 0 octet est sélectionné
When PANDA lance l’import
Then le refus ou l’acceptation respecte la politique serveur, sans message de succès trompeur
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-015 — Fichier volumineux

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un fichier dépassant le seuil configuré est préparé
When PANDA tente son import
Then le refus est lisible, sans carte persistée ni interface bloquée
Note de vérification : Seuil à relever lors de l’exécution ; non connu dans les sources examinées.
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-016 — Catégorie et visibilité initiales

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un PDF vient d’être importé depuis Documents
When PANDA ouvre sa fiche
Then la catégorie affichée est Autres et la visibilité Personnel selon l’implémentation actuelle ; tout autre besoin métier est signalé comme écart
Note de vérification : Constat code : Category=other et Visibility=staff à l’import.
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-017 — Rattachement à la promotion

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given ECSR et une promotion spécifique sont sélectionnés
When PANDA importe un document puis change de promotion
Then le document conserve son périmètre réel ; aucune fuite ou rattachement arbitraire n’apparaît
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-018 — Rattachement sans promotion

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given seule l’organisation ECSR est sélectionnée
When PANDA importe un fichier
Then le document appartient au niveau Organisation prévu et sa visibilité suit les droits
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-019 — Échec réseau lors de l’import

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given la connexion est interrompue avant la sauvegarde
When PANDA tente un import
Then un message d’échec apparaît et aucun document fictif n’est annoncé comme enregistré
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
C — Bibliothèque

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-020 — Liste et compteurs actualisés

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given quatre documents de types différents existent
When PANDA revient sur Documents
Then le nombre de cartes et les compteurs des catégories correspondent aux documents accessibles
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-021 — Recherche par titre

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un document porte un titre distinct
When PANDA recherche un fragment du titre
Then seul le document pertinent apparaît
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-022 — Recherche par auteur

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given plusieurs auteurs existent
When PANDA saisit un auteur
Then seuls les documents associés s’affichent
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-023 — Recherche par nom de fichier

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un fichier est importé avec nom distinct
When PANDA recherche son nom de fichier
Then la carte correspondante apparaît
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-024 — Recherche insensible à la casse

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un titre comporte des majuscules
When PANDA le cherche en minuscules
Then les résultats restent identiques
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-025 — Catégorie puis recherche

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given plusieurs catégories sont présentes
When PANDA sélectionne une catégorie puis recherche
Then les deux critères sont combinés et les totaux restent cohérents
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-026 — Réinitialiser filtre

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une catégorie et un filtre sont activés
When PANDA sélectionne Toutes et efface la recherche
Then tous les documents autorisés réapparaissent
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-027 — État sans résultat

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given aucun document ne correspond à la recherche
When PANDA saisit un terme absent
Then un état vide apparaît sans effacer les documents du catalogue
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-028 — Fiche et métadonnées

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un document est présent
When PANDA clique Aperçu
Then les champs titre, nom, auteur, date, taille, version, pages et visibilité correspondent au document accessible
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-029 — Fermeture de la fiche

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given la modale Aperçu est ouverte
When PANDA clique Fermer puis rouvre la fiche
Then la modale se ferme et le document correct est réaffiché
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-030 — Fermeture clavier

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given la modale est ouverte
When PANDA appuie sur Échap
Then la modale se ferme sans modifier le document
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-031 — Aperçu du contenu réel

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un PDF porte le marqueur interne « RECETTE ECSR V1 »
When PANDA clique Aperçu
Then PANDA peut constater si le vrai contenu est rendu ; si seule une maquette générée apparaît, signaler une anomalie fonctionnelle et ne pas valider l’aperçu réel
Note de vérification : L’HTML affiche explicitement « generatedPreview » et des lignes décoratives.
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-032 — Télécharger la version importée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un PDF ECSR est disponible
When PANDA clique Télécharger et ouvre le fichier local
Then le fichier téléchargé est lisible et son marqueur est identique à l’original
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-033 — Télécharger depuis la fiche

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given la modale est ouverte
When PANDA utilise son bouton Télécharger
Then le même document correct est reçu, sans erreur
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-034 — Échec de téléchargement

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le fichier distant est indisponible
When PANDA clique Télécharger
Then une erreur explicite s’affiche, sans fichier vide présenté comme succès
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
D — Version et suppression

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-035 — Remplacer un document

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un document ECSR V1 existe et Direction est connectée
When PANDA clique Remplacer et sélectionne ECSR V2
Then la version mise à jour est téléchargeable, visible après actualisation et conserve le bon rattachement
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-036 — Annuler le remplacement

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le sélecteur Remplacer est ouvert
When PANDA annule
Then la version initiale reste intacte
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-037 — Remplacement refusé

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une erreur réseau intervient pendant Remplacer
When PANDA tente une nouvelle version
Then la version initiale reste disponible et l’échec est signalé
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-038 — Supprimer avec annulation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un document de test est sélectionné
When PANDA clique Supprimer et annule la confirmation
Then le fichier reste dans la liste et reste téléchargeable
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-039 — Supprimer avec confirmation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un document de test non indispensable est sélectionné
When PANDA confirme sa suppression
Then la carte disparaît, le compteur diminue et le document ne réapparaît pas après actualisation
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-040 — Suppression en erreur

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un document ne peut pas être supprimé côté serveur
When PANDA valide la suppression
Then la carte est conservée et une erreur explicite est visible
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-041 — Suppression sans document sélectionné

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given une autre fiche est déjà fermée
When PANDA ouvre la fiche d’un autre document
Then aucune suppression de l’ancien fichier ne se produit
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-042 — Suivi des versions

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un document V1 a été remplacé par V2
When PANDA inspecte la fiche et télécharge
Then la version affichée et le contenu correspondent à V2, sans mélange avec un autre fichier
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
E — Permissions

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-043 — Direction peut gérer

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given sam.user1 est Direction ECSR
When PANDA ouvre Documents
Then Importer, Remplacer et Supprimer sont accessibles pour ses documents
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-044 — Stagiaire en lecture

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un stagiaire ECSR est connecté
When PANDA ouvre Documents
Then Importer, Remplacer et Supprimer sont absents et seules les ressources autorisées sont visibles
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-045 — Formateur et documents administratifs

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un formateur ECSR est connecté
When PANDA consulte les documents administratifs non destinés aux stagiaires
Then ces documents ne lui sont pas exposés selon la règle de filtrage ; les actions de gestion restent interdites
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-046 — Secrétariat et gestion

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un compte Secrétariat dispose des permissions effectives
When PANDA consulte un document
Then les actions autorisées fonctionnent et toute permission absente provoque un refus serveur si besoin
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-047 — Jury et périmètre

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un compte Jury invité est connecté
When PANDA ouvre Documents dans son organisation de mission
Then seuls les documents autorisés sont accessibles, sans extension automatique à tous les dossiers
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-048 — Accès après suspension

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un membre est suspendu pendant une session active
When PANDA actualise Documents et tente Télécharger
Then les documents devenus interdits ne sont plus accessibles
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-049 — Rôles distincts par organisation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given sam.user1 est Direction ECSR et Jury PL
When PANDA alterne ECSR et PL
Then les opérations de gestion sont autorisées seulement selon les permissions du contexte, sans héritage des droits ECSR
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-050 — Document confidentiel de stagiaire

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un document appartient à un stagiaire ECSR
When un autre stagiaire essaie de le retrouver via les listes et l’URL du navigateur
Then le document confidentiel ne peut être consulté ni téléchargé
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-051 — Document d’une autre organisation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given le document Moto est connu par son nom
When PANDA revient en contexte ECSR et le recherche
Then le fichier Moto reste absent de la liste et inaccessible via une ancienne URL
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
F — Contextes et qualité

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-052 — Tour des quatre organisations

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given les quatre centres possèdent des fichiers avec marqueurs distincts
When PANDA utilise le même compte multi-organisations et change successivement de contexte
Then chaque bibliothèque présente uniquement ses documents autorisés, sans mélange de titres, compteurs ou téléchargements
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-053 — Bascule formation et promotion

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une organisation possède plusieurs formations et promotions
When PANDA change formation puis promotion
Then la bibliothèque suit le contexte et ne réutilise pas des résultats périmés
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-054 — Rechargement et reconnexion

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given des documents ont été importés et remplacés
When PANDA actualise la page puis se reconnecte
Then les versions, fiches, compteurs et droits sont cohérents et persistants
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-055 — Synchronisation dossier stagiaire

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un document est rattaché au dossier d’un stagiaire
When PANDA ouvre Documents puis le dossier Stagiaires
Then le même fichier apparaît uniquement dans les vues où il est légitimement exposé
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-056 — Synchronisation Stages

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un document de convention fictive est relié à un stage
When PANDA navigue entre Documents et Stages
Then le rattachement et la visibilité sont cohérents, sans doublon
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-057 — Contexte de travail après import

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given un document est ajouté à la promotion ECSR A
When PANDA contrôle le sélecteur de contexte immédiatement après
Then organisation, établissement, formation et promotion restent corrects
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-058 — Contexte de travail après remplacement/suppression

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : E2E UI  •  Environnement : staging
Given une version est remplacée puis un fichier est supprimé
When PANDA recontrôle le Contexte de travail
Then aucune sélection parent/enfant n’est altérée par l’action documentaire
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-059 — Affichage sans fuite technique

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given le serveur renvoie une erreur d’import ou de lecture
When PANDA observe l’interface
Then un message compréhensible apparaît sans trace technique ni données d’une autre organisation
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-060 — Document non pris en charge par le rendu

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given un DOCX valide a été importé
When PANDA ouvre Aperçu puis Télécharger
Then l’indisponibilité éventuelle d’un aperçu fidèle est signalée et le téléchargement reste utilisable
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DOC-UI-061 — État de sortie et traçabilité

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : E2E UI  •  Environnement : staging
Given les scénarios de documents sont achevés
When PANDA rassemble les captures et résultats
Then chaque échec ou blocage comporte compte, organisation, rôle, contexte, action, résultat attendu/obtenu et pièce justificative
Preuves : captures avant/après, compte, rôle, Contexte de travail, nom du fichier et résultat après actualisation ; fichier téléchargé si pertinent.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
25.3. Critères de sortie — Documents
Les 61 scénarios DOC-UI sont exécutés ou qualifiés Bloqué / Non applicable avec justification et preuve ; aucun P0 ouvert ne permet de clôturer la recette.
Chaque centre conserve un document de référence reconnaissable et récupérable après reconnexion ; le téléchargement rend le véritable fichier attendu.
Les tests de remplacement, suppression, permissions et visibilité sont validés par une action UI et un contrôle après actualisation.
Les écarts connus du composant (aperçu généré, catégorie Autres / visibilité Personnel imposées à l’import) sont consignés et non assimilés à une validation fonctionnelle de ces capacités.
À chaque mutation, le Contexte de travail et les quatre périmètres organisationnels restent cohérents.
Statut : RÉDIGÉE — NON EXÉCUTÉE. Prochain module recommandé : Rapports.

26. Campagne — Préparation des données pour Rapports et Statistiques
Objectif : produire des données métier vérifiables à partir de la seule interface Web. Les campagnes précédentes décrivent les créations, mais ne garantissent pas qu’elles ont été exécutées. QA Panda réutilise les éléments effectivement persistés et crée uniquement les événements manquants. Aucune insertion directe en base, aucun mock, aucun chiffre prérempli artificiellement.
Ordre d’exécution obligatoire : terminer les prérequis Authentification → Organisation → Promotions → Stagiaires → Planning / Séances → Présences → Fiches / Compétences → Stages → éventuelles certifications. Relever chaque identifiant et titre visibles avant de commencer les vérifications de Rapports et Statistiques.
26.1. Jeu de données contrôlé — à produire dans chaque organisation
Domaine
Minimum par centre
Résultat à retrouver
Population
2 stagiaires de la même promotion
2 inscrits, aucune identité partagée entre centres
Séances
4 séances distinctes, dont au moins 2 réalisées
Différencier programmé / réalisé
Assiduité
8 lignes d’appel : 4 présents, 2 retards, 1 absent, 1 absence justifiée
Statuts et totaux observables sans formule supposée
Compétences
Au moins 3 évaluations : acquis, à améliorer, non acquis
Progressions différentes entre stagiaires
Fiches
1 validée et 1 à retravailler lorsque module activé
Deux états distincts
Stages
1 stage partiel + 1 stage terminé si le parcours le permet
Deux avancements distincts
Certification
1 réussite, 1 non-réussite si examen/jury disponible
Écart visible ; sinon bloqué et explicité
Ne pas forcer un taux de présence, de réussite ou de progression si la règle de calcul produit n’est pas affichée : comparer les totaux affichés aux événements réellement saisis ; documenter toute formule non identifiable. Ne pas inventer d’états métier impossibles. Les données sont fictives et confinées au staging.

Observe : 

Test :  ; anomalie : 

Preuves : 

## DAT-UI-001 — Vérifier les données déjà présentes

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given les quatre organisations et leurs promotions sont accessibles
When PANDA inventorie les stagiaires, séances, présences et évaluations réellement visibles
Then il marque chaque prérequis présent ou manquant, sans déclarer créé ce qui ne l’est pas
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DAT-UI-002 — Créer seulement les données absentes

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given un prérequis manque dans un centre
When PANDA revient au menu métier correspondant et effectue la création par les formulaires
Then le prérequis apparaît puis persiste après actualisation, sans doublon
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DAT-UI-003 — Deux apprenants par centre

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given une promotion existe dans chacun des quatre centres
When PANDA ouvre Stagiaires et confirme au moins deux inscriptions actives
Then les deux stagiaires figurent dans la bonne promotion et uniquement le bon contexte
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DAT-UI-004 — Construire quatre séances distinctes

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given une promotion et un formateur sont disponibles
When PANDA planifie puis suit quatre séances au sein du centre
Then les séances sont distinctes et consultables depuis Planning et Séances
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DAT-UI-005 — Distinguer planifiée et réalisée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given quatre séances existent
When PANDA termine réellement deux séances selon les actions accessibles
Then le statut et les heures ne confondent pas planification et réalisation
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DAT-UI-006 — Distribuer quatre statuts d’assiduité

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given deux stagiaires participent aux quatre séances
When PANDA enregistre 4 présences, 2 retards, 1 absence et 1 absence justifiée
Then les huit lignes sont visibles et persistées avec leur statut
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DAT-UI-007 — Créer un retard mesurable

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : parcours UI / E2E  •  Environnement : staging
Given une séance avec heures de début et de fin existe
When PANDA renseigne un retard et sauvegarde
Then la durée et les heures associées sont cohérentes, sans valeur négative
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DAT-UI-008 — Produire une absence à rattraper

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : parcours UI / E2E  •  Environnement : staging
Given une séance réalisée existe
When PANDA note une absence et contrôle les heures manquées
Then le solde de rattrapage se met à jour selon les règles affichées
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DAT-UI-009 — Produire un rattrapage réellement effectué

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : parcours UI / E2E  •  Environnement : staging
Given des heures à rattraper existent et l’UI offre ce parcours
When PANDA programme puis valide un rattrapage
Then le solde est recalculé et la même heure n’est pas comptée deux fois
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DAT-UI-010 — Évaluations de niveaux différents

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given des compétences pertinentes existent
When PANDA enregistre trois évaluations de niveaux distincts
Then les fiches stagiaires et le menu Compétences affichent des résultats différenciés
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DAT-UI-011 — Fiches aux décisions différentes

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : parcours UI / E2E  •  Environnement : staging
Given la formation comporte des fiches configurées
When PANDA valide une fiche et en marque une autre à retravailler
Then la répartition des statuts et les compteurs évoluent sans confusion
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DAT-UI-012 — Stages de progression différente

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : parcours UI / E2E  •  Environnement : staging
Given deux périodes de stage valides sont créées
When PANDA saisit un suivi partiel puis complète une autre période
Then les indicateurs de stages montrent des avancements non identiques
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DAT-UI-013 — Événement de certification éventuel

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : parcours UI / E2E  •  Environnement : staging
Given le parcours d’examen ou de Jury est exposé et prêt
When PANDA saisit les décisions autorisées pour deux résultats contrastés
Then le taux de réussite utilise les décisions effectivement validées ; sinon test Bloqué
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DAT-UI-014 — Comparer quatre domaines

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given des données contrastées existent dans les quatre organisations
When PANDA ouvre successivement les contextes ECSR, Moto, Poids lourds et Ambulancier
Then les indicateurs et listes correspondent aux événements de chaque centre
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DAT-UI-015 — Vérifier les permissions après changement de centre

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given un des quatre comptes possède plusieurs appartenances
When PANDA change d’organisation depuis le Contexte de travail
Then les droits et données sont recalculés sans héritage du centre précédent
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DAT-UI-016 — Contrôle après reconnexion

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given les événements statistiques sont créés
When PANDA recharge puis se déconnecte et se reconnecte
Then tous les événements restent présents dans leur périmètre métier
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DAT-UI-017 — Journal des événements et preuves

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : parcours UI / E2E  •  Environnement : staging
Given les données de recette ont été créées via l’UI
When PANDA consigne les actions et leurs dates dans la matrice de preuves
Then chaque KPI peut être rapproché des événements qui le composent
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## DAT-UI-018 — Contrôler les cas impossibles

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given une fonctionnalité nécessaire n’est pas exposée
When PANDA relève son absence sans fabriquer de données
Then le scénario est Bloqué ou Non applicable avec capture et justification, jamais Réussi
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
26.2. Critères de sortie
Les quatre centres disposent de données distinctes et contrastées ; le minimum de données est traçable par écran et par date. Tout élément non créé ou non vérifiable est qualifié, et les rapports qui en dépendent sont Bloqués.

27. Campagne — Rapports
Objectif : vérifier l’utilisation réelle de l’interface Rapports, ses filtres, ses exports et la cohérence avec les événements produits dans la campagne 26. Il ne suffit pas qu’un bouton Exporter affiche un message de succès.

Observe : 

Test :  ; anomalie : 

Preuves : 

## RAP-UI-001 — Affichage initial du menu

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : parcours UI / E2E  •  Environnement : staging
Given le compte Direction est connecté dans son organisation
When PANDA ouvre Rapports
Then les types de rapports et contrôles attendus sont visibles sans erreur
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## RAP-UI-002 — Filtrer par organisation de travail

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given les quatre organisations possèdent des événements distincts
When PANDA sélectionne successivement chaque organisation
Then seuls les événements du centre courant alimentent les résultats
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## RAP-UI-003 — Filtrer par établissement et formation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given une organisation possède un établissement et une formation
When PANDA change les filtres proposés
Then le rapport affiche le périmètre choisi et aucun élément hors périmètre
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## RAP-UI-004 — Filtrer sur une période sans événements

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : parcours UI / E2E  •  Environnement : staging
Given une plage de dates vide est identifiable
When PANDA choisit cette plage puis lance le rapport
Then l’état vide est explicite sans chiffres fictifs
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## RAP-UI-005 — Rapport d’heures réalisées

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given des séances ont été planifiées et réalisées
When PANDA produit le rapport des heures
Then les heures réalisées se distinguent des seules heures planifiées
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## RAP-UI-006 — Rapport absences et retards

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given des statuts contrastés ont été enregistrés
When PANDA affiche le rapport d’assiduité
Then les absences, justifications et retards se rapprochent des appels enregistrés
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## RAP-UI-007 — Rapport heures de rattrapage

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : parcours UI / E2E  •  Environnement : staging
Given un rattrapage a été effectué ou est en attente
When PANDA ouvre le rapport correspondant
Then les heures à rattraper ne sont pas confondues avec les heures effectuées
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## RAP-UI-008 — Rapport compétences et fiches

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given des évaluations de niveaux distincts existent
When PANDA génère le rapport de progression
Then la progression correspond au référentiel et aux évaluations du centre courant
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## RAP-UI-009 — Rapport stages

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : parcours UI / E2E  •  Environnement : staging
Given deux périodes de stage contrastées existent
When PANDA produit le rapport Stages
Then le réalisé, le prévu et le restant sont cohérents avec le suivi
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## RAP-UI-010 — Rapport audit

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : parcours UI / E2E  •  Environnement : staging
Given des créations et modifications ont été réalisées
When PANDA ouvre le journal des modifications
Then les traces observables correspondent aux actions autorisées du centre
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## RAP-UI-011 — Exporter PDF

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : parcours UI / E2E  •  Environnement : staging
Given un rapport contenant des données a été généré
When PANDA clique sur Exporter en PDF et ouvre le fichier
Then le document obtenu contient des données exactes et lisibles, sans erreur
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## RAP-UI-012 — Exporter Excel

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : parcours UI / E2E  •  Environnement : staging
Given un rapport contenant des données a été généré
When PANDA clique sur Exporter en Excel et ouvre le fichier
Then les lignes et colonnes exportées correspondent au rapport affiché
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## RAP-UI-013 — Imprimer le rapport

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P2  •  Type : parcours UI / E2E  •  Environnement : staging
Given un rapport est affiché
When PANDA utilise Imprimer
Then l’aperçu impression contient des informations lisibles et cohérentes
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## RAP-UI-014 — Droits insuffisants

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given un compte à rôle restreint se trouve dans un centre invité
When PANDA essaie de consulter ou exporter un rapport hors permission
Then l’accès est refusé et aucune donnée d’un autre centre ne fuit
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## RAP-UI-015 — Persistance et contexte de travail

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given un rapport filtré est affiché
When PANDA actualise et contrôle le Contexte de travail
Then la sélection autorisée et les résultats restent cohérents ; un éventuel reset est explicite
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
27.1. Critères de sortie
Les exports contiennent les données effectivement visualisées ; les filtres et permissions respectent le périmètre autorisé ; aucune divergence P0 entre événements métier et rapport calculé.

28. Campagne — Statistiques
Objectif : vérifier que les tableaux et graphiques statistiques sont dérivés des événements métier persistés, et non de données statiques. Contrôler les changements de valeurs après mutation réelle depuis les autres menus.

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-STAT-001 — État initial sans événements

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given le compte est connecté à un périmètre sans activité
When PANDA ouvre Statistiques
Then les cartes et graphiques affichent zéro ou un état vide cohérent sans données fictives
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-STAT-002 — Effectif par organisation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given quatre organisations disposent de deux stagiaires chacune
When PANDA parcourt les organisations
Then le nombre affiché par centre est cohérent avec ses stagiaires autorisés
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-STAT-003 — Statistiques par promotion

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given plusieurs promotions sont présentes
When PANDA filtre ou change la promotion courante
Then les chiffres reflètent la promotion sélectionnée
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-STAT-004 — Heures planifiées vs réalisées

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given deux séances sont programmées et deux réalisées
When PANDA consulte les indicateurs horaires
Then le total réalisé n’augmente pas au seul fait de programmer une séance
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-STAT-005 — Taux de présence

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given huit appels contrastés sont persistés
When PANDA consulte les indicateurs de présence
Then le taux ou les totaux concordent avec les catégories et la règle produit visible
Précision / contrôle : Si la règle exacte n’est pas visible, signaler la formule non vérifiable au lieu d’inventer un taux.
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-STAT-006 — Retard et absence justifiée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : parcours UI / E2E  •  Environnement : staging
Given deux retards et une absence justifiée existent
When PANDA ouvre les graphiques d’assiduité
Then les catégories restent distinguables sans comptage incohérent
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-STAT-007 — Heures restant à rattraper

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given une absence a généré des heures manquées
When PANDA contrôle les heures à rattraper
Then le solde ne devient pas négatif et est cohérent avec les données sources
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-STAT-008 — Statistiques des compétences

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given les stagiaires ont des évaluations distinctes
When PANDA ouvre la progression par compétence
Then les acquis et non-acquis sont reflétés et différenciés
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-STAT-009 — Statistiques fiches / exposés

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : parcours UI / E2E  •  Environnement : staging
Given des fiches validées et à retravailler existent
When PANDA consulte les répartitions de fiches
Then les compteurs suivent les statuts des fiches réellement évaluées
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-STAT-010 — Statistiques stages

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : parcours UI / E2E  •  Environnement : staging
Given des stages partiels et terminés existent
When PANDA vérifie les indicateurs stages lorsqu’ils sont exposés
Then les volumes correspondent aux périodes réellement suivies
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-STAT-011 — Certification / réussite

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : parcours UI / E2E  •  Environnement : staging
Given des décisions de certification ont été validées via l’UI
When PANDA ouvre le taux de réussite
Then le numérateur et le dénominateur correspondent aux décisions autorisées
Précision / contrôle : Si aucune décision de Jury n’a été enregistrée, conserver l’état vide et marquer le test Bloqué.
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-STAT-012 — Mutation après nouvelle présence

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given une séance possède une feuille d’appel modifiable
When PANDA corrige un statut dans Présences puis revient aux Statistiques
Then l’indicateur correspondant évolue après persistance, sans autre événement
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-STAT-013 — Mutation après évaluation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given une compétence peut être évaluée via son module
When PANDA saisit une nouvelle évaluation puis revient aux Statistiques
Then la progression reflète exactement la nouvelle évaluation
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-STAT-014 — Mutation après suppression autorisée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : parcours UI / E2E  •  Environnement : staging
Given une donnée statistique peut être supprimée via son écran métier
When PANDA la retire puis consulte les Statistiques
Then les agrégats sont recalculés sans conserver l’enregistrement supprimé
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-STAT-015 — Changement organisation rapide

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given un compte est membre de plusieurs centres
When PANDA passe ECSR → Moto → Ambulancier → Poids lourds
Then les graphiques et compteurs ne conservent pas les chiffres du centre précédent
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-STAT-016 — Rôle restreint

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given un compte membre a un rôle non administrateur
When PANDA affiche Statistiques et tente les actions visibles
Then seuls les indicateurs et actions autorisés sont accessibles
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-STAT-017 — Chiffres identiques dans deux écrans

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given les mêmes données contribuent à Accueil, Rapports et Statistiques
When PANDA compare les valeurs pour une période et un périmètre identiques
Then les valeurs sont compatibles à définition de métrique identique
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## STA-STAT-018 — Actualisation et reconnexion

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given des événements ont été enregistrés dans deux centres
When PANDA rafraîchit puis se reconnecte et sélectionne chaque centre
Then les données persistées restent correctes et isolées
Preuves : captures avant / après ; organisation, rôle, Contexte de travail ; résultat après actualisation et export si concerné.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
28.1. Critères de sortie et traçabilité
Pour chaque indicateur testé : conserver la capture de la source métier, la capture du KPI, la période, l’organisation et le rôle. Un KPI affiché sans données ou sans règle de calcul vérifiable ne peut être déclaré correct sans rapprochement des données observables.
Statut des campagnes 26 à 28 : RÉDIGÉES — NON EXÉCUTÉES. Préparer ensuite la recette du parcours Jury/Certification si exposé, puis une campagne de synthèse de non-régression.

29. Parcours Jury / Certification — recette fonctionnelle
Campagne 29 | QA Panda | Environnement STAGING | Profil Direction / Responsable pédagogique et Jury. Cette campagne complète les précédentes ; elle ne présume pas de la présence de toutes les commandes backend dans l’interface. Les fonctions non exposées doivent être classées « Bloqué — fonctionnalité UI absente » et documentées, jamais validées artificiellement.
29.1. Jeux de données et prérequis
Compte
Organisation principale
Formation / session de recette
sam.user1@email.com
Centre Horizon ECSR — Nice
TP ECSR 2027 / ECSR-EXAM-2027-A
sam.user2@email.com
Académie Azur Deux-Roues — Antibes
Enseignement moto / MOTO-EXAM-2027-A
sam.user3@email.com
Institut Provence Poids Lourds — Marseille
Enseignement groupe lourd / PL-EXAM-2027-A
sam.user4@email.com
Institut Méditerranée Ambulancier — Toulon
DEA / AMB-EXAM-2027-A
Chaque compte conserve Demo@123 (ou DemoDemo@123 uniquement pendant le test de changement de mot de passe). Les quatre comptes ont des appartenances croisées déjà préparées dans la campagne Gestion des accès. Les sessions et candidats ne doivent être créés que depuis une UI réellement disponible ; aucune insertion directe en base ni simulation de réponse API n’est autorisée.
Préparer au moins deux candidats par centre, dont un admissible et un non admissible au démarrage, à partir des huit stagiaires déjà créés. Si le produit ne prend pas en charge une certification pour un métier donné, constater la limitation et ne pas lui substituer le référentiel TP ECSR.
Pour tous les scénarios : après une mutation, vérifier le message utilisateur, les données affichées, le résultat après actualisation et le Contexte de travail (organisation, établissement, formation, promotion). Capturer l’UI et relever toute anomalie avec le rôle et le contexte.
29.2. État initial, navigation et prérequis

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-INIT-001 — Affichage du menu Certification

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : parcours UI / E2E  •  Environnement : staging
Given le compte Direction est connecté sur Horizon ECSR
When PANDA ouvre Certification
Then les rubriques, indicateurs, candidats, jurys et informations de session s’affichent sans erreur ; aucune session fictive n’apparaît
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-INIT-002 — Absence initiale de session

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : parcours UI / E2E  •  Environnement : staging
Given aucune session n’a été créée dans une organisation de recette
When PANDA ouvre Certification
Then l’état vide est explicite et n’affiche pas d’examen imaginaire
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-INIT-003 — Accès espace Jury

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given un compte possède le rôle Jury pour l’organisation choisie
When PANDA se connecte et ouvre son espace Jury
Then il voit uniquement les examens et candidats réellement assignés à son périmètre
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-INIT-004 — Pas de promotion ou de référentiel

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given l’organisation ne comporte pas de promotion ou de référentiel éligible
When PANDA cherche à préparer un examen depuis les actions visibles
Then les prérequis manquants sont indiqués ; aucune session incomplète n’est créée
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-INIT-005 — Affichage du schéma de certification

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given un référentiel de certification est associé à la formation
When PANDA ouvre la synthèse du parcours
Then les unités, étapes et critères correspondent à la formation sélectionnée
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-INIT-006 — Formation non ECSR

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given PANDA travaille dans le centre Ambulancier ou Moto
When il consulte la certification
Then aucune grille générique ECSR n’est imposée à un référentiel différent
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-INIT-007 — Navigation et retour

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P2  •  Type : parcours UI / E2E  •  Environnement : staging
Given une session et un candidat sont accessibles
When PANDA ouvre la session puis le détail candidat et utilise Retour
Then la navigation revient au contexte initial sans le modifier
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
29.3. Préparation et cycle de vie des sessions

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-SES-001 — Création d’une session

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given une promotion et une formation sont valides et l’UI propose la création
When PANDA renseigne nom, période, lieu et promotion puis confirme
Then la session apparaît dans Certification et demeure après rafraîchissement
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-SES-002 — Création sans promotion

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given une formation ne possède pas de promotion éligible
When PANDA tente de créer une session
Then la validation bloque la création et indique le champ manquant
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-SES-003 — Dates de session incohérentes

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : parcours UI / E2E  •  Environnement : staging
Given le formulaire de session est accessible
When PANDA met la date de fin avant le début
Then la soumission est refusée avec indication compréhensible
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-SES-004 — Sessions séparées par formation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given deux formations différentes possèdent leurs promotions
When PANDA prépare une session pour chaque formation
Then chaque session conserve son référentiel et son périmètre
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-SES-005 — Ouverture de session

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given une session planifiée existe et le bouton Démarrer est disponible
When PANDA démarre la session
Then le statut change réellement et reste correct après actualisation
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-SES-006 — Démarrage prématuré

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given les prérequis d’une session sont incomplets
When PANDA tente de démarrer via le bouton visible
Then l’action est bloquée avec les informations nécessaires
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-SES-007 — Double clic au démarrage

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : parcours UI / E2E  •  Environnement : staging
Given une session peut être démarrée
When PANDA active deux fois rapidement le bouton Démarrer
Then une seule transition est enregistrée sans duplication
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-SES-008 — Statut après reconnexion

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : parcours UI / E2E  •  Environnement : staging
Given une session a changé de statut
When PANDA se déconnecte et se reconnecte
Then la session conserve le statut confirmé par l’application
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-SES-009 — Absence des commandes de création

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given aucune action de création ou de planification n’est visible dans l’interface
When PANDA parcourt Certification et les écrans liés
Then il consigne un blocage UI avec capture, sans manipuler directement l’API
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
29.4. Candidats, éligibilité et parcours

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-CAN-001 — Liste des candidats

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given une session possède deux candidats distincts
When PANDA consulte la liste de session
Then les identités, numéros, heures et états sont cohérents avec les dossiers stagiaires
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-CAN-002 — Candidat non éligible

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given un candidat présente des heures ou documents manquants
When PANDA ouvre son dossier de certification
Then l’état non prêt et les éléments manquants apparaissent explicitement
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-CAN-003 — Candidat éligible

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given le candidat remplit les prérequis visibles
When PANDA recharge son dossier
Then l’état prêt reflète les données réellement validées
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-CAN-004 — Mutation des prérequis

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given un candidat présente un document ou des heures manquantes
When PANDA complète le prérequis via le menu métier approprié puis revient
Then le niveau de préparation est recalculé sans validation fictive
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-CAN-005 — Candidat absent de la promotion

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given un stagiaire appartient à une autre promotion
When PANDA consulte la session courante
Then ce stagiaire n’apparaît pas parmi les candidats de la session
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-CAN-006 — Étapes et unités de certification

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : parcours UI / E2E  •  Environnement : staging
Given un candidat possède un parcours de certification configuré
When PANDA ouvre son dossier
Then les étapes affichent leurs véritables statuts et unités correspondant au référentiel
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-CAN-007 — Changement de candidat

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given deux candidats sont présents dans la même session
When PANDA ouvre leurs dossiers successivement
Then les résultats, notes et statuts ne se confondent pas
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
29.5. Affectation et habilitation des jurys

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-AFF-001 — Liste des jurys affectés

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : parcours UI / E2E  •  Environnement : staging
Given une session est créée
When PANDA ouvre le détail et la rubrique Jury
Then seules les affectations réellement enregistrées sont visibles
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-AFF-002 — Affecter un jury habilité

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given l’interface expose une action d’affectation et un membre Jury admissible existe
When PANDA affecte le membre à la session
Then l’affectation apparaît dans le détail et dans son espace Jury
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-AFF-003 — Jury non habilité ou expiré

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given un utilisateur sans habilitation valide est sélectionnable
When PANDA tente son affectation
Then la création est refusée avec un motif exploitable
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-AFF-004 — Chevauchement de missions

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : parcours UI / E2E  •  Environnement : staging
Given une personne est affectée à une session aux mêmes dates
When PANDA essaie une affectation incompatible depuis l’UI
Then la règle de chevauchement applicable est respectée et le résultat expliqué
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-AFF-005 — Rafraîchir les affectations

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : parcours UI / E2E  •  Environnement : staging
Given une nouvelle affectation a été validée
When PANDA utilise Actualiser dans le panneau Jury
Then la liste retrouve la nouvelle affectation sans doublon
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-AFF-006 — Jury ne voit pas les autres sessions

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given un compte Jury a une seule affectation autorisée
When PANDA ouvre l’espace Jury
Then les autres sessions ou candidats non assignés restent inaccessibles
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-AFF-007 — Retrait d’affectation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given l’UI propose le retrait d’une affectation
When PANDA retire un jury de sa session
Then l’accès à cette session disparaît tout en préservant ses autres appartenances
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
29.6. Grilles, brouillons et validation

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-EVAL-001 — Ouvrir la grille du candidat

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given un candidat est affecté à une session accessible au Jury
When PANDA ouvre le détail candidat dans l’espace Jury
Then la grille pertinente et ses critères s’affichent sans données préremplies artificielles
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-EVAL-002 — Choix d’un niveau par critère

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given l’évaluation est modifiable par le Jury assigné
When PANDA sélectionne un niveau pour plusieurs critères
Then chaque choix reste attaché au bon critère et au bon candidat
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-EVAL-003 — Notes et commentaires

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : parcours UI / E2E  •  Environnement : staging
Given la zone de notes Jury est disponible
When PANDA saisit un commentaire distinctif
Then le texte est conservé à la sauvegarde puis au rechargement
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-EVAL-004 — Enregistrer un brouillon

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given une grille contient au moins un choix et une note
When PANDA clique Enregistrer le brouillon
Then un retour de succès confirmé apparaît et la grille peut être reprise après reconnexion
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-EVAL-005 — Brouillon non complet

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : parcours UI / E2E  •  Environnement : staging
Given une grille comporte des critères non renseignés
When PANDA sauvegarde en brouillon
Then les données partielles sont conservées si la règle le permet, sans décision finale
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-EVAL-006 — Validation d’évaluation complète

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given tous les champs obligatoires d’une grille sont remplis
When PANDA valide l’évaluation
Then l’état validé est visible et persiste ; les champs deviennent non modifiables selon la règle métier
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-EVAL-007 — Validation incomplète refusée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given la grille ne satisfait pas aux obligations de validation
When PANDA clique Valider
Then l’application refuse la validation et indique les critères manquants
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-EVAL-008 — Protection contre validation double

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given une évaluation vient d’être validée
When PANDA reclique rapidement sur le bouton ou revient sur la page
Then aucun second enregistrement ou double effet n’est créé
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-EVAL-009 — Évaluation verrouillée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given une évaluation a été définitivement validée
When PANDA tente d’en modifier un niveau et une note
Then l’interface et le serveur empêchent la modification non autorisée
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-EVAL-010 — Jury non assigné

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given le compte possède un rôle Jury mais n’est pas affecté à ce candidat
When PANDA tente d’accéder à la grille par navigation normale ou URL copiée
Then l’accès ou l’action est refusé sans divulguer le contenu confidentiel
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
29.7. Résultats, publication et statistiques

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-DEC-001 — Résultat d’un candidat

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given une évaluation est validée
When PANDA consulte le dossier candidat puis les Résultats
Then les statuts affichés concordent avec les décisions réellement enregistrées
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-DEC-002 — Décision finale depuis l’UI

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given une action de décision est exposée et les prérequis de validation sont satisfaits
When PANDA enregistre une décision de certification
Then elle est conservée, horodatée et attribuée au rôle habilité
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-DEC-003 — Publication des résultats

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given l’UI propose Publier les résultats et la session remplit les prérequis
When PANDA publie puis consulte les résultats
Then seuls les résultats autorisés deviennent visibles aux profils concernés
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-DEC-004 — Aucune publication prématurée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given une session contient des évaluations incomplètes
When PANDA tente de publier
Then la publication est refusée ou soumise à la règle métier documentée, sans faux succès
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-DEC-005 — Effet sur les statistiques

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given au moins deux décisions définitives distinctes sont disponibles
When PANDA ouvre Statistiques puis Rapports
Then les effectifs et taux de réussite correspondent aux résultats effectivement publiés et au bon dénominateur
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-DEC-006 — Modification du résultat déjà publié

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given un résultat est publié
When PANDA tente de le modifier via une action visible
Then la modification est refusée ou suit une procédure de correction traçable
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-DEC-007 — Résultat accessible au candidat

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given une décision est publiée et le stagiaire dispose de son accès
When PANDA se connecte comme stagiaire et consulte son espace
Then il voit uniquement son propre résultat selon la politique de publication
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
29.8. Contexte de travail, permissions et non-régression

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-TEN-001 — Changement de centre

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given sam.user1 est membre de quatre organisations avec rôles distincts
When PANDA bascule ECSR → Moto → Poids lourds → Ambulancier
Then sessions, jurys, candidats et référentiels sont propres au centre courant
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-TEN-002 — Rôle Direction versus rôle Jury

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given un compte est Direction dans un centre et Jury dans un autre
When PANDA compare les actions disponibles après bascule
Then les commandes de gestion et d’évaluation respectent le rôle du contexte actif
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-TEN-003 — Accès croisé par URL

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given un candidat de Moto possède une URL de dossier
When PANDA la colle en session sur le centre ECSR sans permission Moto valable
Then aucune lecture ou écriture inter-organisation n’est autorisée
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-TEN-004 — Révocation d’un jury en session

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given un jury a une page de candidat ouverte
When une Direction autorisée retire son affectation depuis une autre session
Then la prochaine action protégée est refusée et ne persiste rien
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-TEN-005 — Actualisation sans mélange

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : parcours UI / E2E  •  Environnement : staging
Given des évaluations différentes existent dans les quatre organisations
When PANDA recharge puis change rapidement d’organisation
Then ni les compteurs ni les détails d’une organisation précédente ne réapparaissent
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-TEN-006 — Cohérence avec dossier stagiaire

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : parcours UI / E2E  •  Environnement : staging
Given une certification dispose de résultats validés
When PANDA compare certification, dossier stagiaire et statistiques
Then les états et résultats concordent pour un même périmètre et une même période
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## JUR-TEN-007 — Traçabilité d’une décision

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : parcours UI / E2E  •  Environnement : staging
Given un jury a validé une évaluation et une décision a été enregistrée
When PANDA consulte l’historique ou le journal d’audit exposé
Then la date, l’auteur et l’action sont traçables sans révéler les données d’autres centres
Contrôle : vérifier le Contexte de travail avant/après toute mutation, la persistance après actualisation et l’isolation entre les quatre centres. Si la commande n’est pas exposée par l’UI, marquer « Bloqué — UI absente » avec capture ; ne jamais contourner via API ou base.
Preuves : capture initiale/finale, rôle, centre, promotion/session, résultat observable, capture après rechargement ; ID anomalie si échec.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
29.10. Critères de sortie et ordre d’exécution
Exécuter successivement : préparation des quatre périmètres → session → candidats → jurys → brouillons → évaluations validées → décisions et publication (si exposées) → comparaison Rapports / Statistiques → contrôles d’accès croisé. Les règles de certification spécifiques à chaque spécialité doivent provenir du référentiel effectivement sélectionné dans le produit.
54 scénarios Jury/Certification ajoutés. Statut : RÉDIGÉ — NON EXÉCUTÉ. Aucun scénario conditionnel ne doit être déclaré réussi si l’action n’est pas accessible par l’interface utilisateur.

30. Campagne transversale — Confirmation des prestations et heures stagiaire (S01 + S02)
Version 2.0 — extension cumulative de la v1.9. 47 scénarios QA Panda. Statut : RÉDIGÉ — NON EXÉCUTÉ. Cette campagne couvre les changements livrés dans PedagoraPilot_ConfirmationPrestations_S01.zip (backend, 4 fichiers) et S02.zip (Angular, 7 fichiers). Aucun passage en réussite n’est présumé avant déploiement et recette.
OBJECTIF MÉTIER : distinguer, par stagiaire et par séance, les heures réalisées (présence enregistrée pour une séance achevée), les heures confirmées (émargement valide de la révision courante) et les heures en attente. Une contestation ne confirme aucune heure. Une modification d’émargement invalide la confirmation antérieure pour cette nouvelle révision. La progression pédagogique/compétences n’est pas validée automatiquement par l’émargement.
PRÉREQUIS : Exécuter les campagnes Authentification, Promotions, Stagiaires, Planning/Séances, Présences et Gestion des accès ; disposer de deux comptes stagiaires réels reliés à une même promotion ainsi que d’un formateur habilité. Garder les quatre organisations fictives isolées (Horizon ECSR, Azur Deux-Roues, Provence Poids Lourds, Méditerranée Ambulancier). Le contrôle de l’e-mail nécessite une boîte de réception consultable depuis le navigateur par PANDA ; à défaut : « Bloqué — boîte indisponible ». La confirmation de l’adresse e-mail à l’inscription peut être désactivée en staging, mais les e-mails d’émargement doivent rester actifs.
30.1. Jeu de données et résultats de référence
Séance
Stagiaire
Présence
Réalisées
Confirmées
En attente
S-A / 2 h
A
Présent 120 min
2 h
2 h si signé
0 h si signé
S-A / 2 h
B
Présent 120 min
2 h
0 h si en attente
2 h
S-A / 2 h
C (optionnel)
Présent 120 min
2 h
0 h si contesté
2 h
S-B / 1 h
A
Absent
0 h
0 h
0 h
Exemple attendu lorsque A a confirmé, B attend et C conteste : 6 h réalisées, 2 h confirmées, 4 h en attente pour la séance S-A. Ces chiffres sont une somme « stagiaire × minutes », non la durée de la séance pour le formateur ; ne pas confondre les deux mesures.
Après chaque mutation : consigner le Contexte de travail (organisation → établissement → formation → promotion), les identités connectées, la séance, les heures avant/après, l’état après rechargement et la comparaison avec le dossier stagiaire. En cas de fonctionnalité UI absente : « Bloqué — UI absente », sans accès direct à l’API ou à la base.
30.2. Préparation des séances et périmètres

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-001 — Identifier un formateur et deux stagiaires distincts

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  une promotion active, un formateur affecté et deux stagiaires A et B inscrits dans le même centre
When  PANDA se connecte successivement comme Direction, Formateur, A puis B
Then  les menus et données sont accessibles seulement aux rôles habilités et le contexte est cohérent
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-002 — Création d’une séance collective

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  le formateur est connecté au bon centre et à la promotion cible
When  il crée S-A pour A et B, durée prévue 2 heures
Then  la séance est visible dans les vues autorisées de tous les participants après actualisation
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-003 — Séance future sans heures réalisées

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  S-A n’a pas encore eu lieu et aucun émargement n’est enregistré
When  PANDA consulte Présences et les indicateurs disponibles
Then  aucune heure future n’est comptabilisée comme réalisée ou confirmée
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-004 — Enregistrement de deux présences

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  la date de fin de S-A est passée et A/B sont inscrits
When  le formateur saisit Présent avec 120 minutes pour A et B et sauvegarde
Then  les deux lignes persistent et chacune affiche 2 h réalisées, 0 h confirmée et 2 h en attente
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-005 — Absent ne crée aucune heure réalisée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  une autre séance achevée S-B contient A absent
When  le formateur sauvegarde l’absence puis recharge
Then  les heures réalisées, confirmées et en attente de A ne gagnent aucune minute pour S-B
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-006 — Retard et durée partielle

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  une séance achevée de 120 minutes comporte un stagiaire arrivé 30 minutes après le début
When  le formateur enregistre une durée présente de 90 minutes et sauvegarde
Then  la durée réalisée est 90 minutes et seules ces 90 minutes sont potentiellement confirmables
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-007 — Modification non enregistrée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  une ligne enregistrée indique 120 minutes réalisées
When  le formateur change visuellement la durée mais quitte sans enregistrer
Then  les chiffres restent ceux de la dernière version sauvegardée
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
30.3. Demande de confirmation et livraison e-mail

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-008 — Interdiction de signature avant séance achevée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  une séance est encore future ou en cours
When  le formateur tente de demander une confirmation
Then  l’action est indisponible ou refusée sans e-mail valide ni changement d’heures
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-009 — Interdiction de signature avant sauvegarde

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  le formateur a modifié les heures sans enregistrer
When  il tente de demander l’émargement
Then  l’UI impose la sauvegarde ou refuse la demande ; aucune version non persistée n’est signable
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-010 — Demande individuelle pour A

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  S-A est achevée, les 120 minutes de A sont enregistrées et non signées
When  le formateur demande la confirmation de A
Then  le statut devient en attente et les heures confirmées demeurent à zéro
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-011 — Demande groupée pour A et B

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  S-A contient deux stagiaires admissibles avec émargements sauvegardés
When  le formateur sélectionne les deux et demande les signatures
Then  les deux demandes sont individualisées, chaque destinataire est correct et le résultat d’envoi est visible
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-012 — Échec partiel de demandes groupées

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  un lot contient une demande admissible et une demande non admissible
When  le formateur lance l’envoi groupé
Then  l’UI distingue envoyées/échouées et ne marque pas toutes les demandes comme réussies
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-013 — Réception de l’e-mail du bon stagiaire

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  A dispose d’une boîte de réception accessible et une demande vient d’être émise
When  PANDA consulte la boîte de A dans le navigateur
Then  un e-mail d’émargement relatif à S-A arrive à A, sans données privées de B
Point d’attention : Si l’accès e-mail ne peut pas être piloté, marquer « Bloqué — boîte indisponible ».
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-014 — Lien d’e-mail et authentification

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  A possède un lien valide vers sa demande et est déconnecté
When  il ouvre le lien dans le navigateur puis s’authentifie
Then  il atteint uniquement son propre émargement ou reçoit une protection d’accès explicite
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-015 — Pas de confusion avec validation e-mail d’inscription

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  la confirmation d’adresse à l’inscription est désactivée seulement en staging
When  PANDA déclenche une demande d’émargement pour A
Then  la demande et son e-mail fonctionnent indépendamment de la validation d’adresse à l’inscription
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
30.4. Confirmation, contestation et statut individuel

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-016 — Affichage de la prestation côté stagiaire

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  A a une demande d’émargement en attente
When  A ouvre Présences depuis son compte
Then  il voit la séance, les heures enregistrées et son propre statut de confirmation
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-017 — Confirmation par le stagiaire A

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  A a 120 minutes réalisées et 0 minute confirmée sur S-A
When  A lit la demande puis clique sur Confirmer
Then  A passe au statut Confirmée ; ses heures restent 120 réalisées, passent à 120 confirmées et 0 en attente
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-018 — Persistance de la confirmation après reconnexion

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  A a confirmé S-A
When  A recharge, se déconnecte puis se reconnecte
Then  sa confirmation et les 2 heures confirmées restent visibles
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-019 — Indépendance des signatures de A et B

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  A a confirmé tandis que B n’a pas répondu
When  B puis le formateur consultent S-A
Then  B reste en attente avec 0 heure confirmée ; la validation de A ne valide pas B
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-020 — Contestation par le stagiaire B

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  B possède 120 minutes réalisées et une demande en attente
When  B conteste et saisit un commentaire motivé
Then  son statut est Contestée ; il conserve 120 minutes réalisées, 0 confirmée et 120 en attente
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-021 — Visibilité de la contestation côté formateur

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  B a contesté avec un commentaire
When  le formateur ouvre l’historique des signatures de S-A
Then  le statut contesté et le commentaire autorisé sont consultables sans modifier rétroactivement les heures
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-022 — Pas de confirmation sur une contestation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  B est contesté, aucune correction n’a été validée
When  PANDA consulte les totaux de la séance
Then  les 120 minutes contestées ne sont pas comptabilisées comme confirmées
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-023 — Pas de double comptage après double clic

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  A a déjà confirmé 120 minutes
When  A recharge et tente une deuxième confirmation ou clique plusieurs fois rapidement
Then  les heures confirmées ne doublent jamais et le système évite une réponse multiple
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-024 — Interdiction d’une réponse par un autre stagiaire

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  A est connecté et dispose d’une demande propre à B
When  A tente d’ouvrir la demande de B via un lien copié
Then  l’accès est refusé et la réponse de B ne change pas
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
30.5. Révisions d’émargement et corrections

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-025 — Correction des heures après une signature

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  A a signé une ligne de 120 minutes
When  le formateur corrige la durée de A à 90 minutes et sauvegarde
Then  la version change ; A affiche 90 minutes réalisées et la confirmation antérieure ne confirme pas les 90 nouvelles minutes
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-026 — Nouvelle demande après correction

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  les 90 minutes corrigées de A sont en attente et la signature ancienne est obsolète
When  le formateur crée/sollicite la nouvelle demande via l’UI
Then  la nouvelle demande reflète 90 minutes et n’emploie pas silencieusement la signature obsolète
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-027 — Nouvelle confirmation après correction

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  A a une demande valide pour les 90 minutes corrigées
When  A confirme à nouveau
Then  le décompte affiche 90 minutes réalisées, 90 confirmées, 0 en attente sans cumuler les anciennes 120 minutes
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-028 — Retour d’une ligne signée à Absent

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  une présence de 120 minutes est déjà confirmée
When  le formateur modifie la ligne à Absent, puis sauvegarde
Then  la nouvelle révision comptabilise 0 heure réalisée et 0 confirmée pour cette ligne
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-029 — Modification concernant B impactant la version

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  A et B ont des émargements sur la même feuille et A a signé
When  le formateur modifie les horaires de B et sauvegarde
Then  le système applique sa règle de version de feuille ; PANDA vérifie si la signature de A reste valide ou devient obsolète selon la version réellement suivie
Point d’attention : Le correctif utilise une version de feuille : documenter si une modification d’un autre stagiaire révoque également la confirmation de A.
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-030 — Ancien lien refusé après modification

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  une demande antérieure correspond à une version devenue obsolète
When  A tente de signer depuis son ancien lien
Then  l’action est refusée avec une explication compréhensible ; aucune heure obsolète n’est confirmée
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-031 — Correction sans nouvelle confirmation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  la séance a été corrigée mais le stagiaire n’a pas signé la nouvelle version
When  le formateur et le stagiaire rechargent leurs écrans
Then  les heures corrigées sont réalisées mais restent en attente, sans héritage de confirmation
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
30.6. Totaux, dossier Stagiaire et cohérence métier

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-032 — Agrégation de trois stagiaires contrastés

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  une séance de 2 h comporte A confirmé, B en attente et C contesté
When  le formateur consulte le récapitulatif des heures
Then  le total est 6 h réalisées, 2 h confirmées et 4 h en attente ; les lignes expliquent le total
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-033 — Cohérence entre Présences et Stagiaire

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  A dispose de plusieurs émargements de versions courantes
When  PANDA compare Présences puis le dossier Stagiaire avec le même périmètre
Then  les heures réalisées, confirmées et en attente concordent après actualisation
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-034 — Somme sur plusieurs séances

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  A a signé une séance de 120 minutes et attend une autre séance de 60 minutes
When  A ouvre sa synthèse personnelle
Then  il voit 180 minutes réalisées, 120 confirmées et 60 en attente sur les séances concernées
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-035 — Arrondis et unités de durée

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  un émargement réalisé de 90 minutes est enregistré
When  PANDA compare les écrans et les récapitulatifs
Then  90 minutes correspondent à 1,5 h partout, sans troncature à 1 h ni arrondi contradictoire
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-036 — Progression pédagogique indépendante

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  A signe une séance de 2 h sans nouvelle compétence évaluée
When  PANDA ouvre Compétences puis le dossier Stagiaire
Then  les heures confirmées augmentent mais aucune compétence n’est automatiquement acquise
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-037 — Actualisation après signature depuis une autre session

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  formateur et stagiaire sont connectés sur deux navigateurs
When  A confirme pendant que le formateur consulte les Présences
Then  les informations actualisées deviennent cohérentes sans mélanger des états anciens ; au minimum après rafraîchissement
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-038 — Chargement et erreur de synthèse

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  la connexion est temporairement interrompue lors d’une consultation de la synthèse
When  PANDA observe le chargement puis rétablit la connexion et réessaie
Then  une erreur lisible est affichée sans faire passer des chiffres manquants pour des zéros fiables
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
30.7. Isolation, rôles, sécurité fonctionnelle et régression

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-039 — Isolation entre les quatre organisations

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  chaque compte de référence dispose de séances et présences propres
When  PANDA alterne les contextes Horizon ECSR, Azur Deux-Roues, Provence Poids Lourds et Méditerranée Ambulancier
Then  aucune séance, signature ni total d’un autre centre ne fuit dans le centre actif
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-040 — Rôles croisés et moindre privilège

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  USER-01 dispose d’un rôle de Direction dans son centre et d’un rôle restreint dans un autre
When  il change de centre puis tente les actions de confirmation et de correction
Then  seules les opérations de son rôle actif sont proposées et autorisées
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-041 — Révocation des droits pendant une session

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  un formateur possède une session ouverte et son habilitation est ensuite retirée
When  il tente de sauvegarder une correction ou d’envoyer une demande
Then  l’opération protégée est refusée et aucune mutation n’est persistée
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-042 — Aucun mélange après changements rapides de contexte

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  des séances homonymes existent dans deux centres
When  PANDA alterne plusieurs fois les contextes pendant le chargement des heures
Then  l’écran final ne montre que les chiffres de la dernière organisation sélectionnée
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-043 — Régression des e-mails d’autres catégories

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  le module de signature d’observations pédagogiques est disponible
When  un formateur sollicite une signature d’observation puis revient aux signatures d’émargement
Then  les deux parcours restent distincts ; leurs messages, statuts et heures ne se mélangent pas
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-044 — Rapports et Statistiques après confirmation

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  les menus Rapports et Statistiques sont disponibles et présentent des heures ou taux de signature
When  PANDA compare avant/après une confirmation et change de centre
Then  les indicateurs exposés reflètent le bon périmètre ; un indicateur non raccordé est déclaré comme écart ou « Bloqué — indicateur absent »
Point d’attention : Le sprint S02 raccorde Présences et le dossier Stagiaire ; ne pas présumer le raccordement des autres tableaux de bord.
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-045 — Absence d’action d’e-mail automatique non prévue

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  le formateur vient de saisir une présence et sauvegarde
When  PANDA surveille la demande de confirmation via l’interface
Then  la sollicitation reste une action explicite du formateur, sauf évolution démontrée de l’UI ; ne pas exiger un e-mail automatique sur la seule sauvegarde
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-046 — Non-régression sans accès API direct

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P0  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  PANDA arrive à une étape indisponible ou en échec
When  il documente une capture, l’URL, le rôle et le comportement
Then  il classe le scénario « Bloqué » ou « Échoué », sans requête REST manuelle ni accès base
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________

Observe : 

Test :  ; anomalie : 

Preuves : 

## SIG-E2E-047 — Contrôle du calcul après annulation de séance

Verdict : NOT_RUN

Attendu et preconditions :
Priorité : P1  •  Type : Gherkin / E2E UI  •  Environnement : staging
Given  une séance achevée et signée est annulée par un utilisateur habilité, si l’UI le permet
When  PANDA réouvre les heures personnelles et la synthèse de séance
Then  aucune heure de la séance annulée ne reste comptée comme réalisée ou confirmée
Point d’attention : Si le bouton d’annulation est absent : « Bloqué — UI absente ».
Contrôles : contexte organisation / établissement / formation / promotion ; rôle et identité ; sauvegarde, rechargement et persistance ; absence de fuite multi-tenant.
Preuves : captures des écrans avant/après, heures et statuts affichés, identifiant séance/compte, boîte mail si applicable, référence anomalie.
Verdict : □ Réussi  □ Échoué  □ Bloqué  □ Non applicable  •  Anomalie : __________
30.8. Critères de sortie et ordre de recette
Ordre recommandé : déployer S01 et S02 ensemble → vérifier connexion et données de référence → créer S-A → saisir présences → déclencher demandes → vérifier e-mails → confirmer A et contester B → contrôler les trois compteurs → modifier la feuille après signature → solliciter et signer la nouvelle révision → vérifier Stagiaire et Présences → exécuter quatre centres et rôles croisés → contrôler régressions. Une séance n’est pas « confirmée » globalement si un stagiaire concerné reste en attente ou a contesté.
Conditions d’acceptation : heures confirmées ≤ heures réalisées ; heures en attente = heures réalisées − heures confirmées sur chaque périmètre ; aucune heure confirmée issue d’une signature d’ancienne révision ; aucune validation automatique de compétences ; aucun accès transversal injustifié. Toutes les anomalies P0 doivent être résolues ; les scénarios non accessibles restent bloqués et ne comptent jamais comme réussis.
47 nouveaux scénarios SIG-E2E. Statut de la campagne : RÉDIGÉE — NON EXÉCUTÉE. Code source analysé : patches S01/S02 fournis ; compilation et comportement réels à valider sur l’URL de staging.

Observe : 

Test :  ; anomalie : 

Preuves : 
