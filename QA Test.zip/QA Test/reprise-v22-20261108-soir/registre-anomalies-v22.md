# Registre des anomalies — reprise v2.2

Huit nouvelles anomalies valides : task19,20,22–27. Task21 INVALID exclu. Retests18/13 ci-dessous ; historique complet dans cc-tasks-v22.json.

## task-13 — Dossier hors organisation : HTTP500 et squelette vide au lieu d’un refus d’accès

Statut CC : todo

Tests liés : test-26

MET-001-006 ; MAJEUR medium (gestion fonctionnelle du refus, aucune fuite démontrée). Compte A administrateur ECF, pas membre AFTRAL. URL https://pedagora.staging.locaguest.com/stagiaires/1ea8ba5a-6704-4d52-b02d-df7588bac88c (dossier valide connu avec B). Attendu : accès refusé/404 adapté sans données privées. Observé : GET reporting/learners/{id}/detail HTTP500 req2168 ; notification Unable to load learner record ; écran dossier avec0h,0%, nom/dates vides. Aucune donnée du stagiaire dans DOM. Capture23:12UTC snapshot109. Impact : message d’autorisation absent, faux écran vide et erreur serveur.

[med-foreign-learner-final](preuves/med-foreign-learner-final.png)

## task-18 — P2 — Promotion : absence de responsable bloque la création sans message ni voie de résolution

Statut CC : todo

Tests liés : test-10

REGRESSION révélée à la reprise, non prouvée causée par correctif. USER01 propriétaire/Direction Horizon, siteHORIZ-QA-01, formationHORIZ-ECSR-QA Draft, versionCCP1+CCP2. URL /promotions. Repro : Créer promotion, nom ECSR2027-sessionA, dates04/01/2027–30/06/2027, effectif3, version préselectionnéeCCP1+CCP2 ; aucun responsable pédagogique disponible. Cliquer Create cohort. Attendu : message responsable actif requis, lien de préparation ou bouton désactivé expliqué. Observé : bouton actif, aucune réaction ni message, responsable vide non marqué invalid dans snapshot, aucune requête POST. Aucune promotion créée. Snapshot205/207 ; cohort-manager-silent.png. P2/medium : prérequis métier non expliqué. Distinct des écrans Invitations/Formations/Séances de task2 dont deux sont corrigés.

[cohort-no-manager-retest](preuves/cohort-no-manager-retest.png)
[cohort-created](preuves/cohort-created.png)

## task-19 — P2 — Accueil Formateur : date fixe et cinq séances fictives sans affectation

Statut CC : todo

Tests liés : test-40

SEC-REPRISE-004, INV-REPRISE-011. Staging08/11/2026 20:34UTC. Nouveau Formateur qa.v22.20261108t2034.formateur.horizon@example.com, Centre Horizon ECSR/HORIZ-QA-01/programmeECSR sans promotion ni affectation. Se connecter, ouvrir /accueil puis recharger : Monday 21 September 2026 · 5 sessions today malgré date08/11 et sections My sessions today/My students vides. Attendu : date courante et compteur réel ou absence de données. Test40 étape97 FAIL, trainer-home-errors.png et trainer-home-reloaded.png. Donnée trompeuse de tableau de bord ; pas une fuite démontrée.

[trainer-home-reloaded](preuves/trainer-home-reloaded.png)
[student-context](preuves/student-context.png)

## task-20 — P2 — Connexion Formateur : préchargements administratifs interdits et alertes parasites

Statut CC : todo

Tests liés : test-40

SEC-REPRISE-004 / SEC-REPRISE-028. Nouveau Formateur qa.v22.20261108t2034.formateur.horizon@example.com, Horizon sans affectation. Login puis /accueil, reload : alertes Could not load programs, Some workspace data could not be loaded, Unable to load frameworks. Requêtes UI GET /api/v1/referentials403 req574/585, /programs403 req586, /reporting/audit403 req587, dashboards403 req588/589. Attendu : chargement adapté aux droits, aucun appel administratif ni alerte d'indisponibilité pour un refus attendu. Menus administratifs masqués ; aucune autorisation serveur contournée démontrée. Test40 étape98 FAIL, captures trainer-home-errors/reloaded. Aucune affirmation sur exception backend.

[trainer-home-errors](preuves/trainer-home-errors.png)
[student-context](preuves/student-context.png)

## task-22 — P1 — Stagiaire : formulaire de création de séance et commande active exposés

Statut CC : todo

Tests liés : test-41

INV-REPRISE-018 / SEC-REPRISE-007,08/11/2026 vers20:40UTC. StagiaireA qa.v22.20261108t2034.stagiairea.horizon@example.com, Horizon/Nice/ECSR/QA V22 Horizon20261108, rôleTrainee. Ouvrir /seances : formulaire New teaching session complet, Create session actif, cohorte propre sélectionnée. Saisir Topic et cliquer : No active trainer selected. Assign a trainer before creating the session. Attendu : aucun formulaire de création réservé formateur/direction pour ce rôle, accès lecture seulement. Observé action interdite exposée et validation métier accessible. Aucune sauvegarde non autorisée démontrée (listeformateursvide). GravitéP1 sécurité fonctionnelle UI, pas fuite inter-tenant ni contournement serveur prouvé. test41 étapes101/102 FAIL, student-sessions.png / student-create-forbidden.png.

[student-sessions](preuves/student-sessions.png)
[student-create-forbidden](preuves/student-create-forbidden.png)

## task-23 — P2 — Espace Jury sans examen : contenu principal entièrement vide

Statut CC : todo

Tests liés : test-42

SEC-REPRISE-008 / INV-REPRISE-015. Nouveau QA Jury Provence V22 qa.v22.20261108t2034.jury.provence@example.com actif dans Provence, aucun examen affecté. Connexion réussie redirige /jury ; attendre, ouvrir Jury space puis recharger : menuHome/Jury et identité présents mais main vide, aucun titre ni message absence examen. Attendu : page lisible avec état vide explicite. Captures jury-space / jury-blank-final ; test42 étape105FAIL. Les URL admin testées renvoient/accueil, pas de fuite ni accès examen non attribué démontré.

[jury-space](preuves/jury-space.png)
[jury-blank-final](preuves/jury-blank-final.png)

## task-24 — P2 — Rôle Responsable pédagogique affiché Trainer après sélection d’organisation

Statut CC : todo

Tests liés : test-28

INV-REPRISE-022 / SEC-REPRISE-016. 08/11/2026. USER01 est Educational manager dans Azur, confirmé ligne /acces source et chooser Responsable pédagogique ; après sélection sidebar sous Sam Horizon QA affiche Trainer. Reproduit USER03 dans Ambulancier : chooser Responsable pédagogique puis sidebarTrainer, alors que menus manager (Cohorts/Reports) restent présents. Attendu : libellé rôle local exact. Captures user1-in-azure, user3-in-med, cross-2-1 et cross-4-3. Test28 étape59FAIL. Aucun gain de permission serveur ni rôle écrasé démontré ; erreur de représentation du rôle.

[manager-context](preuves/manager-context.png)
[user1-in-azure](preuves/user1-in-azure.png)
[user3-in-med](preuves/user3-in-med.png)

## task-25 — P1 — Accès révoqué : réinvitation refusée409, restauration UI impossible

Statut CC : todo

Tests liés : test-27

SEC-REPRISE-022/038, INV-REPRISE-026. USER01 administrateur Horizon ; USER02 possède une appartenance secondaire Trainer Horizon créée dans ce lot, sans affectation.
Reproduction : suspendre USER02 dans /acces ; vérifier sa nouvelle connexion sans Horizon ; retirer cette seule appartenance et confirmer. Après actualisation, USER02 est absent de la liste Horizon et conserve ses trois autres espaces. Pour restaurer l’état initial, réinviter sam.user2@email.com avec le rôle Trainer.
Attendu : réactivation ou réinvitation maîtrisée de l’appartenance révoquée, sans nouvelle identité.
Observé : POST /api/v1/access/invite HTTP409 (req5455), notification Unable to send this invitation. La ligne retirée n’est plus disponible pour Activate ; aucune autre voie UI de restauration identifiée.
Preuves : user2-revoked-spaces.png, user2-restore-error.png ; test27/run71 étape56 FAIL. Tous les propriétaires restent actifs. Seule la relation secondaire USER02→Horizon reste révoquée à la fin du lot. Distinct du refus d’auto-invitation historique : les douze invitations initiales avaient réussi.

[user2-revoked-spaces](preuves/user2-revoked-spaces.png)
[user2-restore-error](preuves/user2-restore-error.png)

## task-26 — P1 — Formateur actif affecté à une cohorte : liste Formateur vide, séance impossible

Statut CC : todo

Tests liés : test-43

SEC-REPRISE-034, INV-REPRISE-030. Nouveau QA Formateur Horizon V22, actif et affecté à la cohorte QA V22 Horizon 20261108, sous Horizon / Nice / ECSR ; trois Stagiaires actifs.
Reproduction : reconnecter ce Formateur ; ouvrir /seances ; sélectionner sa cohorte ; saisir 08/11/2026,08:00–10:00 et sujet QA V22 Confirmation 2h ; cliquer Create session.
Attendu : le Formateur propre est disponible et peut créer une séance dans sa cohorte.
Observé : liste Trainer vide, alerte Unable to load sessions puis No active trainer selected. Assign a trainer before creating the session. Aucune séance enregistrée. L’administrateur voit ce même Formateur dans la liste et a créé une séance distincte, ce qui confirme que son identité existe.
Preuves : trainer-cohort-assignment.png, trainer-assigned-context.png, trainer-create-blocked.png ; test43/run72 étape120 FAIL. Le parcours de confirmation initié par le Formateur est bloqué. Aucun appel API manuel ni JWT modifié.

[trainer-cohort-assignment](preuves/trainer-cohort-assignment.png)
[trainer-create-blocked](preuves/trainer-create-blocked.png)

## task-27 — P1 — Demandes de confirmation : trois envois refusés409, restent Draft malgré présences valides

Statut CC : todo

Tests liés : test-43

SEC-REPRISE-034/035, INV-REPRISE-030. USER01 administrateur Horizon ; cohorte QA V22 Horizon 20261108 ; séance QA V22 Confirmation 2h Admin le08/11/2026 de08:00 à10:00 locales (07:00–09:00UTC), terminée lors du test ; trois Stagiaires actifs.
Reproduction : enregistrer Present pour A,B,C et actualiser ; cliquer individuellement Request acknowledgement pour chacun. Vérifier ensuite le Centre de signatures ; sélectionner les trois brouillons et Send selected drafts(3).
Attendu : demandes Pending accessibles à chaque Stagiaire sans consultation d’email en staging ; aucune confirmation automatique.
Observé : brouillons créés200 puis envois individuels409 (req6103/6110/6115), statut Requests queued for delivery:0 · Failures:1. Les trois demandes restent Draft ; envoi collectif POST /signatures/batch/request409 req6690. Les détails UI des trois brouillons indiquent Present,120min réalisées,0manquée. Chaque Stagiaire se connecte mais son centre contient0demande envoyée.
Preuves : attendance-three-present.png, attendance-requests-sent.png, attendance-bulk-final.png, student-a-drafts.png, student-b-no-pending.png, student-c-no-pending.png ; test43/run74 étape123 FAIL et run78 étape135 FAIL. 6h réalisées vérifiées manuellement ; 2h confirmées/4h non confirmées non validées.

[attendance-three-present](preuves/attendance-three-present.png)
[attendance-requests-sent](preuves/attendance-requests-sent.png)
[attendance-bulk-final](preuves/attendance-bulk-final.png)

## Ticket invalidé

task21 a été ouvert à tort pendant une transition Invitation sent→Active. Les résultats finaux ont été corrigés ; ni anomalie ouverte ni correctif livré à comptabiliser.