# Sections31–32 — résultats détaillés

Les PASS historiques ne sont pas des preuves de retest actuel. Les BLOCKED et NOT_RUN restent distincts.

## INV-REPRISE-001 — Prérequis : purge des invitations sans destruction des comptes racines

**Verdict : PASS**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Gherkin  •  Environnement : STAGING
Préconditions : Purge réalisée par l’administrateur avant exécution
Given  le responsable confirme avoir supprimé les invitations de la campagne précédente
When  PANDA se connecte aux quatre comptes racines puis consulte Gestion des accès
Then  aucune invitation résiduelle de la campagne précédente ne subsiste ; les quatre comptes, leurs organisations et leurs données métier restent accessibles
Contrôles : vérifier organisation/établissement/formation/promotion, rôle, rafraîchissement, persistance, absence de fuite entre organisations et absence de succès fictif.
Preuves : écran d’invitation et état après rafraîchissement ; capture du menu après connexion ; accès autorisés et interdits ; ID utilisateur/organisation ; anomalies horodatées.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE   •   Ticket : _______________

Étapes exécutées / observé : Les quatre propriétaires se connectent, rechargent Gestion des accès et retrouvent leur organisation et site QA ; Horizon conserve sa formation. Anciennes invitations Horizon absentes. Un accès actif test@email.com préexistait dans Ambulancier et a été conservé.

Test : test-1 ; anomalie : 

Preuves : admin1.png; admin2.png; admin3.png; admin4.png

Portée : Reprise v2.2 du08/11/2026

## INV-REPRISE-002 — Contrôle du paramètre QA [secret QA] par authentification réelle

**Verdict : BLOCKED**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Gherkin  •  Environnement : STAGING
Préconditions : Quatre comptes racines disponibles ; staging et bypass activés ; purge des invitations confirmée
Given  un nouvel utilisateur QA est provisionné avec un mot de passe initial attendu [secret QA]
When  PANDA ouvre une session privée et saisit ses identifiants sans exposer le mot de passe
Then  la connexion fonctionne avec [secret QA] ; sinon anomalie de configuration/bypass avec verdict FAIL ou BLOCKED, jamais PASS implicite
Contrôles : vérifier organisation/établissement/formation/promotion, rôle, rafraîchissement, persistance, absence de fuite entre organisations et absence de succès fictif.
Preuves : écran d’invitation et état après rafraîchissement ; capture du menu après connexion ; accès autorisés et interdits ; ID utilisateur/organisation ; anomalies horodatées.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE   •   Ticket : _______________

Étapes exécutées / observé : Connexions réelles après déconnexion réalisées, mais sessions privées indépendantes non disponibles sous la contrainte onglet 1 unique. Le critère spécifique de session privée/distincte n’est pas validé.

Test : test-1; test-27 ; anomalie : 

Preuves : 

Portée : Reprise v2.2 du08/11/2026

## INV-REPRISE-003 — Invitation nouvelle identité depuis Direction ECSR

**Verdict : PASS**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Gherkin  •  Environnement : STAGING
Préconditions : Quatre comptes racines disponibles ; staging et bypass activés ; purge des invitations confirmée
Given  la Direction ECSR est authentifiée et le bon Contexte de travail est sélectionné
When  PANDA invite une nouvelle identité fictive avec le rôle Formateur et enregistre
Then  la nouvelle identité apparaît sans doublon, avec le bon rôle et la bonne organisation ; après rafraîchissement son statut correspond au traitement automatique du staging
Contrôles : vérifier organisation/établissement/formation/promotion, rôle, rafraîchissement, persistance, absence de fuite entre organisations et absence de succès fictif.
Preuves : écran d’invitation et état après rafraîchissement ; capture du menu après connexion ; accès autorisés et interdits ; ID utilisateur/organisation ; anomalies horodatées.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE   •   Ticket : _______________

Étapes exécutées / observé : Nouvelles identités uniques et activation automatique constatée après traitement, puis connexions réelles et reload. Une nouvelle identité au moins par centre. Douze invitations croisées réutilisent les quatre identités, leurs secrets et accès propriétaires ; rôles distincts conservés au choix d’espace. Le libellé Responsable pédagogique erroné est suivi séparément.

Test : test-3; test-5; test-28 ; anomalie : 

Preuves : trainer-created.png; trainer-status-rechecked.png; secretary-created.png; jury-created.png; med-trainer-created.png; user1-fourspaces.png; user2-fourspaces.png; user3-fourspaces.png; user4-fourspaces.png

Portée : Reprise v2.2 du08/11/2026

## INV-REPRISE-004 — Activation automatique sans clic sur le lien d’invitation

**Verdict : PASS**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Gherkin  •  Environnement : STAGING
Préconditions : Quatre comptes racines disponibles ; staging et bypass activés ; purge des invitations confirmée
Given  une nouvelle invitation valide est créée en staging
When  PANDA ne consulte aucun e-mail et actualise la liste après traitement
Then  l’invitation passe effectivement à un état actif et l’appartenance est enregistrée ; si elle reste « Invitation envoyée » au-delà du délai de traitement observable, relever l’anomalie
Contrôles : vérifier organisation/établissement/formation/promotion, rôle, rafraîchissement, persistance, absence de fuite entre organisations et absence de succès fictif.
Preuves : écran d’invitation et état après rafraîchissement ; capture du menu après connexion ; accès autorisés et interdits ; ID utilisateur/organisation ; anomalies horodatées.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE   •   Ticket : _______________

Étapes exécutées / observé : Nouvelles identités uniques et activation automatique constatée après traitement, puis connexions réelles et reload. Une nouvelle identité au moins par centre. Douze invitations croisées réutilisent les quatre identités, leurs secrets et accès propriétaires ; rôles distincts conservés au choix d’espace. Le libellé Responsable pédagogique erroné est suivi séparément.

Test : test-3; test-5; test-28 ; anomalie : 

Preuves : trainer-created.png; trainer-status-rechecked.png; secretary-created.png; jury-created.png; med-trainer-created.png; user1-fourspaces.png; user2-fourspaces.png; user3-fourspaces.png; user4-fourspaces.png

Portée : Reprise v2.2 du08/11/2026

## INV-REPRISE-005 — Invitation dans chacune des quatre organisations

**Verdict : PASS**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Gherkin  •  Environnement : STAGING
Préconditions : Quatre comptes racines disponibles ; staging et bypass activés ; purge des invitations confirmée
Given  les quatre comptes Direction sont disponibles
When  PANDA crée au moins un compte fictif nouveau dans chaque organisation
Then  chaque compte apparaît uniquement dans la bonne organisation et peut être réutilisé dans les tests du rôle
Contrôles : vérifier organisation/établissement/formation/promotion, rôle, rafraîchissement, persistance, absence de fuite entre organisations et absence de succès fictif.
Preuves : écran d’invitation et état après rafraîchissement ; capture du menu après connexion ; accès autorisés et interdits ; ID utilisateur/organisation ; anomalies horodatées.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE   •   Ticket : _______________

Étapes exécutées / observé : Nouvelles identités uniques et activation automatique constatée après traitement, puis connexions réelles et reload. Une nouvelle identité au moins par centre. Douze invitations croisées réutilisent les quatre identités, leurs secrets et accès propriétaires ; rôles distincts conservés au choix d’espace. Le libellé Responsable pédagogique erroné est suivi séparément.

Test : test-3; test-5; test-28 ; anomalie : 

Preuves : trainer-created.png; trainer-status-rechecked.png; secretary-created.png; jury-created.png; med-trainer-created.png; user1-fourspaces.png; user2-fourspaces.png; user3-fourspaces.png; user4-fourspaces.png

Portée : Reprise v2.2 du08/11/2026

## INV-REPRISE-006 — Invitation multi-rôles : distinction identité / appartenance

**Verdict : PASS**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Gherkin  •  Environnement : STAGING
Préconditions : Quatre comptes racines disponibles ; staging et bypass activés ; purge des invitations confirmée
Given  un utilisateur possède un rôle dans l’organisation A
When  PANDA l’invite dans l’organisation B avec un rôle différent
Then  une seule identité existe, chaque appartenance porte son rôle et le rôle A n’est ni écrasé ni étendu à B
Contrôles : vérifier organisation/établissement/formation/promotion, rôle, rafraîchissement, persistance, absence de fuite entre organisations et absence de succès fictif.
Preuves : écran d’invitation et état après rafraîchissement ; capture du menu après connexion ; accès autorisés et interdits ; ID utilisateur/organisation ; anomalies horodatées.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE   •   Ticket : _______________

Étapes exécutées / observé : Nouvelles identités uniques et activation automatique constatée après traitement, puis connexions réelles et reload. Une nouvelle identité au moins par centre. Douze invitations croisées réutilisent les quatre identités, leurs secrets et accès propriétaires ; rôles distincts conservés au choix d’espace. Le libellé Responsable pédagogique erroné est suivi séparément.

Test : test-3; test-5; test-28 ; anomalie : 

Preuves : trainer-created.png; trainer-status-rechecked.png; secretary-created.png; jury-created.png; med-trainer-created.png; user1-fourspaces.png; user2-fourspaces.png; user3-fourspaces.png; user4-fourspaces.png

Portée : Reprise v2.2 du08/11/2026

## INV-REPRISE-007 — Validation du formulaire : adresse malformée

**Verdict : PASS**

Préconditions et attendu du cahier v2.2 :
Priorité : P1  •  Type : E2E UI / Gherkin  •  Environnement : STAGING
Préconditions : Quatre comptes racines disponibles ; staging et bypass activés ; purge des invitations confirmée
Given  un administrateur a ouvert la création d’invitation
When  PANDA saisit une adresse e-mail invalide puis soumet
Then  le formulaire bloque ou affiche un message de validation et aucun utilisateur ne devient actif
Contrôles : vérifier organisation/établissement/formation/promotion, rôle, rafraîchissement, persistance, absence de fuite entre organisations et absence de succès fictif.
Preuves : écran d’invitation et état après rafraîchissement ; capture du menu après connexion ; accès autorisés et interdits ; ID utilisateur/organisation ; anomalies horodatées.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE   •   Ticket : _______________

Étapes exécutées / observé : Adresse malformée : champ invalid=true et message Enter a valid email address ; aucun compte créé.

Test : test-2 ; anomalie : 

Preuves : invite-malformed.png

Portée : Reprise v2.2 du08/11/2026

## INV-REPRISE-008 — Invitation doublonnée dans la même organisation

**Verdict : PASS**

Préconditions et attendu du cahier v2.2 :
Priorité : P1  •  Type : E2E UI / Gherkin  •  Environnement : STAGING
Préconditions : Quatre comptes racines disponibles ; staging et bypass activés ; purge des invitations confirmée
Given  une invitation active a déjà été traitée pour cette identité
When  PANDA tente de réinviter le même utilisateur et le même rôle
Then  l’application refuse le doublon ou traite l’opération de façon idempotente, sans créer une seconde appartenance
Contrôles : vérifier organisation/établissement/formation/promotion, rôle, rafraîchissement, persistance, absence de fuite entre organisations et absence de succès fictif.
Preuves : écran d’invitation et état après rafraîchissement ; capture du menu après connexion ; accès autorisés et interdits ; ID utilisateur/organisation ; anomalies horodatées.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE   •   Ticket : _______________

Étapes exécutées / observé : Réinvitation du même Formateur actif au même rôle rejetée ; après reload une seule ligne, une affectation et compteur inchangés. Message générique, sans doublon.

Test : test-2 ; anomalie : 

Preuves : invite-duplicate-active.png; invite-duplicate-reloaded.png

Portée : Reprise v2.2 du08/11/2026

## INV-REPRISE-009 — Invitation inter-organisations existante

**Verdict : PASS**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Gherkin  •  Environnement : STAGING
Préconditions : Quatre comptes racines disponibles ; staging et bypass activés ; purge des invitations confirmée
Given  un des quatre utilisateurs racines est déjà inscrit dans AuthGate
When  PANDA l’invite à rejoindre une autre organisation
Then  son identité existante est réutilisée ; son mot de passe n’est pas modifié et son organisation initiale reste accessible
Contrôles : vérifier organisation/établissement/formation/promotion, rôle, rafraîchissement, persistance, absence de fuite entre organisations et absence de succès fictif.
Preuves : écran d’invitation et état après rafraîchissement ; capture du menu après connexion ; accès autorisés et interdits ; ID utilisateur/organisation ; anomalies horodatées.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE   •   Ticket : _______________

Étapes exécutées / observé : Nouvelles identités uniques et activation automatique constatée après traitement, puis connexions réelles et reload. Une nouvelle identité au moins par centre. Douze invitations croisées réutilisent les quatre identités, leurs secrets et accès propriétaires ; rôles distincts conservés au choix d’espace. Le libellé Responsable pédagogique erroné est suivi séparément.

Test : test-3; test-5; test-28 ; anomalie : 

Preuves : trainer-created.png; trainer-status-rechecked.png; secretary-created.png; jury-created.png; med-trainer-created.png; user1-fourspaces.png; user2-fourspaces.png; user3-fourspaces.png; user4-fourspaces.png

Portée : Reprise v2.2 du08/11/2026

## INV-REPRISE-010 — Pas de création fantôme après erreur d’invitation

**Verdict : PASS**

Préconditions et attendu du cahier v2.2 :
Priorité : P1  •  Type : E2E UI / Gherkin  •  Environnement : STAGING
Préconditions : Quatre comptes racines disponibles ; staging et bypass activés ; purge des invitations confirmée
Given  une invitation reçoit un message d’échec visible
When  PANDA rafraîchit les listes et tente une reconnexion avec l’adresse
Then  aucun compte actif sans appartenance valide ne résulte d’un échec ; la reprise ne provoque pas de doublon
Contrôles : vérifier organisation/établissement/formation/promotion, rôle, rafraîchissement, persistance, absence de fuite entre organisations et absence de succès fictif.
Preuves : écran d’invitation et état après rafraîchissement ; capture du menu après connexion ; accès autorisés et interdits ; ID utilisateur/organisation ; anomalies horodatées.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE   •   Ticket : _______________
31.4. Connexion et contrôle des menus par rôle

Étapes exécutées / observé : Après l’échec de réinvitation de USER02 révoqué, Horizon ne contient aucune ligne supplémentaire ; USER02 se reconnecte à ses trois appartenances légitimes. Vérification UI sur identité existante, pas d’échec de provisionnement d’une identité entièrement nouvelle simulé.

Test : test-27 ; anomalie : task-25

Preuves : user2-restore-error.png; user2-revoked-spaces.png

Portée : Reprise v2.2 du08/11/2026

## INV-REPRISE-011 — Formateur : connexion avec [secret QA]

**Verdict : FAIL**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Gherkin  •  Environnement : STAGING
Préconditions : Quatre comptes racines disponibles ; staging et bypass activés ; purge des invitations confirmée
Given  une nouvelle identité Formateur est active
When  PANDA se déconnecte de Direction puis se connecte avec l’adresse invitée et [secret QA]
Then  l’accès est autorisé, l’organisation et le rôle affichés sont corrects, les menus de Formateur correspondent aux permissions et les menus Direction non autorisés sont absents
Contrôles : vérifier organisation/établissement/formation/promotion, rôle, rafraîchissement, persistance, absence de fuite entre organisations et absence de succès fictif.
Preuves : écran d’invitation et état après rafraîchissement ; capture du menu après connexion ; accès autorisés et interdits ; ID utilisateur/organisation ; anomalies horodatées.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE   •   Ticket : _______________

Étapes exécutées / observé : Formateur Horizon réellement connecté et affecté à la cohorte ; menus Direction et URL /acces interdits, mais création légitime de séance impossible : sélecteur Trainer vide et message No active trainer selected.

Test : test-43 ; anomalie : task-26

Preuves : trainer-assigned-context.png; trainer-create-blocked.png

Portée : Reprise v2.2 du08/11/2026

## INV-REPRISE-012 — Stagiaire : connexion avec [secret QA]

**Verdict : FAIL**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Gherkin  •  Environnement : STAGING
Préconditions : Quatre comptes racines disponibles ; staging et bypass activés ; purge des invitations confirmée
Given  une nouvelle identité Stagiaire est active et correctement rattachée
When  PANDA ouvre une nouvelle session avec l’adresse invitée et [secret QA]
Then  l’espace Stagiaire s’ouvre, seules les données du stagiaire sont visibles, aucune administration ou évaluation d’un autre stagiaire n’est accessible
Contrôles : vérifier organisation/établissement/formation/promotion, rôle, rafraîchissement, persistance, absence de fuite entre organisations et absence de succès fictif.
Preuves : écran d’invitation et état après rafraîchissement ; capture du menu après connexion ; accès autorisés et interdits ; ID utilisateur/organisation ; anomalies horodatées.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE   •   Ticket : _______________

Étapes exécutées / observé : Les trois Stagiaires se connectent à leur propre cohorte. A ne lit pas le brouillon B (403). Cependant Séances expose au Stagiaire le formulaire et le bouton Create session actifs ; validation métier accessible. Aucune sauvegarde non autorisée démontrée.

Test : test-41; test-1 ; anomalie : task-22

Preuves : student-context.png; student-create-forbidden.png; student-a-foreign-request.png

Portée : Reprise v2.2 du08/11/2026

## INV-REPRISE-013 — Responsable pédagogique : connexion avec [secret QA]

**Verdict : FAIL**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Gherkin  •  Environnement : STAGING
Préconditions : Quatre comptes racines disponibles ; staging et bypass activés ; purge des invitations confirmée
Given  une nouvelle identité Responsable pédagogique est active
When  PANDA ouvre une session avec ses identifiants et parcourt les menus
Then  les menus et opérations correspondent au référentiel de droits ; pas d’accès aux fonctions réservées à Direction sans habilitation
Contrôles : vérifier organisation/établissement/formation/promotion, rôle, rafraîchissement, persistance, absence de fuite entre organisations et absence de succès fictif.
Preuves : écran d’invitation et état après rafraîchissement ; capture du menu après connexion ; accès autorisés et interdits ; ID utilisateur/organisation ; anomalies horodatées.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE   •   Ticket : _______________

Étapes exécutées / observé : Rôles et espaces créés correctement ; après choix Responsable pédagogique, le libellé sous l’identité affiche Trainer. Reproduit nouveau Responsable Horizon, USER01 dans Azur et USER03 dans Ambulancier. Menus pédagogiques adaptés, aucune élévation serveur démontrée.

Test : test-28; test-3 ; anomalie : task-24

Preuves : manager-context.png; user1-in-azure.png; user3-in-med.png

Portée : Reprise v2.2 du08/11/2026

## INV-REPRISE-014 — Secrétariat : connexion avec [secret QA]

**Verdict : BLOCKED**

Préconditions et attendu du cahier v2.2 :
Priorité : P1  •  Type : E2E UI / Gherkin  •  Environnement : STAGING
Préconditions : Quatre comptes racines disponibles ; staging et bypass activés ; purge des invitations confirmée
Given  une nouvelle identité Secrétariat est active
When  PANDA se connecte avec [secret QA] puis teste lecture et opérations disponibles
Then  les menus apparaissent conformément aux permissions ; accès aux données protégées non autorisées interdit
Contrôles : vérifier organisation/établissement/formation/promotion, rôle, rafraîchissement, persistance, absence de fuite entre organisations et absence de succès fictif.
Preuves : écran d’invitation et état après rafraîchissement ; capture du menu après connexion ; accès autorisés et interdits ; ID utilisateur/organisation ; anomalies horodatées.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE   •   Ticket : _______________

Étapes exécutées / observé : Secrétariat Azur actif et première connexion réussie ; menus, consultation Stagiaires et refus /acces et /administration observés. Opérations métier et périmètre complet non validés faute de formation/promotion Azur préparée.

Test : test-3 ; anomalie : 

Preuves : secretary-context.png; secretary-learners.png

Portée : Reprise v2.2 du08/11/2026

## INV-REPRISE-015 — Jury : connexion avec [secret QA]

**Verdict : BLOCKED**

Préconditions et attendu du cahier v2.2 :
Priorité : P1  •  Type : E2E UI / Gherkin  •  Environnement : STAGING
Préconditions : Quatre comptes racines disponibles ; staging et bypass activés ; purge des invitations confirmée
Given  une nouvelle identité Jury est active et affectée à une session lorsque nécessaire
When  PANDA se connecte avec [secret QA] et ouvre le menu certification
Then  l’espace Jury est visible si implémenté, les candidats/sessions autorisés sont accessibles et les autres sont inaccessibles ; sinon BLOCKED clairement motivé
Contrôles : vérifier organisation/établissement/formation/promotion, rôle, rafraîchissement, persistance, absence de fuite entre organisations et absence de succès fictif.
Preuves : écran d’invitation et état après rafraîchissement ; capture du menu après connexion ; accès autorisés et interdits ; ID utilisateur/organisation ; anomalies horodatées.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE   •   Ticket : _______________

Étapes exécutées / observé : Jury Provence actif et connecté à /jury ; menus Home/Jury seuls et URL administratives refusées. Aucune session d’examen attribuée, donc contrôle positif des candidats bloqué. Le corps de /jury vide est documenté séparément.

Test : test-3; test-42 ; anomalie : task-23

Preuves : jury-created.png; jury-space.png; jury-blank-final.png

Portée : Reprise v2.2 du08/11/2026

## INV-REPRISE-016 — Tuteur : connexion avec [secret QA] si espace disponible

**Verdict : BLOCKED**

Préconditions et attendu du cahier v2.2 :
Priorité : P1  •  Type : E2E UI / Gherkin  •  Environnement : STAGING
Préconditions : Quatre comptes racines disponibles ; staging et bypass activés ; purge des invitations confirmée
Given  une nouvelle identité Tuteur est invitée et une affectation pédagogique existe si l’UI l’autorise
When  PANDA se connecte avec [secret QA] et cherche son espace de suivi
Then  seuls les stagiaires et stages confiés sont visibles ; si le rôle ou espace n’existe pas, BLOCKED et preuve
Contrôles : vérifier organisation/établissement/formation/promotion, rôle, rafraîchissement, persistance, absence de fuite entre organisations et absence de succès fictif.
Preuves : écran d’invitation et état après rafraîchissement ; capture du menu après connexion ; accès autorisés et interdits ; ID utilisateur/organisation ; anomalies horodatées.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE   •   Ticket : _______________

Étapes exécutées / observé : Le formulaire Inviter un utilisateur ne propose pas le rôle Tuteur. Un lien My placements (tutor) existe pour d’autres profils, ce qui ne prouve pas un provisionnement Tuteur. Parcours d’invitation via stage et données de stage restant à préparer.

Test : test-3 ; anomalie : 

Preuves : admin4.png; trainer-context.png

Portée : Reprise v2.2 du08/11/2026

## INV-REPRISE-017 — Direction : maintien de la connexion sur les quatre comptes racines

**Verdict : PASS**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Gherkin  •  Environnement : STAGING
Préconditions : Quatre comptes racines disponibles ; staging et bypass activés ; purge des invitations confirmée
Given  les quatre identités Direction de référence existent
When  PANDA se connecte successivement à chaque compte avec [secret QA]
Then  chaque compte accède à son organisation et ses menus Direction sans collision de session
Contrôles : vérifier organisation/établissement/formation/promotion, rôle, rafraîchissement, persistance, absence de fuite entre organisations et absence de succès fictif.
Preuves : écran d’invitation et état après rafraîchissement ; capture du menu après connexion ; accès autorisés et interdits ; ID utilisateur/organisation ; anomalies horodatées.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE   •   Ticket : _______________

Étapes exécutées / observé : Les quatre propriétaires se connectent, rechargent Gestion des accès et retrouvent leur organisation et site QA ; Horizon conserve sa formation. Anciennes invitations Horizon absentes. Un accès actif test@email.com préexistait dans Ambulancier et a été conservé.

Test : test-1 ; anomalie : 

Preuves : admin1.png; admin2.png; admin3.png; admin4.png

Portée : Reprise v2.2 du08/11/2026

## INV-REPRISE-018 — Menu masqué et URL directe interdite

**Verdict : PASS**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Gherkin  •  Environnement : STAGING
Préconditions : Quatre comptes racines disponibles ; staging et bypass activés ; purge des invitations confirmée
Given  un nouvel utilisateur Stagiaire ou Jury est connecté
When  PANDA tente d’ouvrir une URL UI d’administration copiée d’une session Direction
Then  l’accès est refusé, redirigé ou affiche un refus clair sans fuite de données ; aucun accès simplement masqué par menu
Contrôles : vérifier organisation/établissement/formation/promotion, rôle, rafraîchissement, persistance, absence de fuite entre organisations et absence de succès fictif.
Preuves : écran d’invitation et état après rafraîchissement ; capture du menu après connexion ; accès autorisés et interdits ; ID utilisateur/organisation ; anomalies horodatées.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE   •   Ticket : _______________

Étapes exécutées / observé : Stagiaire A et Jury : URL directes /acces et /administration renvoient à /accueil sans données administratives. Ce PASS ne couvre pas le formulaire Séances exposé au Stagiaire, suivi sous INV-REPRISE-019.

Test : test-3; test-41 ; anomalie : 

Preuves : student-context.png; jury-reload.png

Portée : Reprise v2.2 du08/11/2026

## INV-REPRISE-019 — Comparaison explicite menus Formateur / Stagiaire / Jury

**Verdict : FAIL**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Gherkin  •  Environnement : STAGING
Préconditions : Quatre comptes racines disponibles ; staging et bypass activés ; purge des invitations confirmée
Given  des comptes actifs des trois rôles sont disponibles
When  PANDA photographie les menus de chaque rôle et compare les actions CRUD visibles
Then  les différences observées correspondent à la matrice de permissions ; toute fonction non autorisée disponible est une anomalie
Contrôles : vérifier organisation/établissement/formation/promotion, rôle, rafraîchissement, persistance, absence de fuite entre organisations et absence de succès fictif.
Preuves : écran d’invitation et état après rafraîchissement ; capture du menu après connexion ; accès autorisés et interdits ; ID utilisateur/organisation ; anomalies horodatées.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE   •   Ticket : _______________

Étapes exécutées / observé : Les trois Stagiaires se connectent à leur propre cohorte. A ne lit pas le brouillon B (403). Cependant Séances expose au Stagiaire le formulaire et le bouton Create session actifs ; validation métier accessible. Aucune sauvegarde non autorisée démontrée.

Test : test-41; test-1 ; anomalie : task-22

Preuves : student-context.png; student-create-forbidden.png; student-a-foreign-request.png

Portée : Reprise v2.2 du08/11/2026

## INV-REPRISE-020 — Un rôle ne suffit pas sans affectation opérationnelle

**Verdict : FAIL**

Préconditions et attendu du cahier v2.2 :
Priorité : P1  •  Type : E2E UI / Gherkin  •  Environnement : STAGING
Préconditions : Quatre comptes racines disponibles ; staging et bypass activés ; purge des invitations confirmée
Given  un nouvel utilisateur Jury ou Tuteur possède son rôle mais pas de session/stage affecté
When  PANDA visite les listes de candidats ou de stagiaires
Then  les données non affectées sont invisibles et une liste vide est explicitée, sans données provenant d’autres membres
Contrôles : vérifier organisation/établissement/formation/promotion, rôle, rafraîchissement, persistance, absence de fuite entre organisations et absence de succès fictif.
Preuves : écran d’invitation et état après rafraîchissement ; capture du menu après connexion ; accès autorisés et interdits ; ID utilisateur/organisation ; anomalies horodatées.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE   •   Ticket : _______________
31.5. Multi-organisation et invitations croisées

Étapes exécutées / observé : Jury sans examen attribué : aucune donnée étrangère affichée mais /jury présente un main entièrement vide, sans titre ni état d’absence d’examen.

Test : test-42 ; anomalie : task-23

Preuves : jury-blank-final.png

Portée : Reprise v2.2 du08/11/2026

## INV-REPRISE-021 — Reprendre les douze invitations croisées du cahier

**Verdict : PASS**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Gherkin  •  Environnement : STAGING
Préconditions : Quatre comptes racines disponibles ; staging et bypass activés ; purge des invitations confirmée
Given  les quatre comptes racines existent dans quatre organisations distinctes
When  PANDA exécute la matrice de 12 invitations croisées définie en section 13
Then  les 12 appartenances attendues existent sans doublon, avec les rôles prévus et sans modifier les identités existantes
Contrôles : vérifier organisation/établissement/formation/promotion, rôle, rafraîchissement, persistance, absence de fuite entre organisations et absence de succès fictif.
Preuves : écran d’invitation et état après rafraîchissement ; capture du menu après connexion ; accès autorisés et interdits ; ID utilisateur/organisation ; anomalies horodatées.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE   •   Ticket : _______________

Étapes exécutées / observé : Les douze relations de la matrice ont été créées actives, relues après reload et les douze espaces secondaires ouverts. État obtenu avant le scénario de révocation ; à la fin USER02→Horizon reste révoqué car restauration échoue409.

Test : test-5; test-28 ; anomalie : task-25

Preuves : cross-1-2.png; cross-2-1.png; cross-3-2.png; cross-4-3.png; user1-fourspaces.png; user4-fourspaces.png

Portée : Reprise v2.2 du08/11/2026

## INV-REPRISE-022 — Changement de Contexte de travail après invitation

**Verdict : FAIL**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Gherkin  •  Environnement : STAGING
Préconditions : Quatre comptes racines disponibles ; staging et bypass activés ; purge des invitations confirmée
Given  un compte est membre actif de deux organisations
When  PANDA se connecte, change d’organisation et revisite les écrans concernés
Then  le menu, les droits et les données s’actualisent selon le rôle de l’organisation active, sans fuite de données
Contrôles : vérifier organisation/établissement/formation/promotion, rôle, rafraîchissement, persistance, absence de fuite entre organisations et absence de succès fictif.
Preuves : écran d’invitation et état après rafraîchissement ; capture du menu après connexion ; accès autorisés et interdits ; ID utilisateur/organisation ; anomalies horodatées.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE   •   Ticket : _______________

Étapes exécutées / observé : Rôles et espaces créés correctement ; après choix Responsable pédagogique, le libellé sous l’identité affiche Trainer. Reproduit nouveau Responsable Horizon, USER01 dans Azur et USER03 dans Ambulancier. Menus pédagogiques adaptés, aucune élévation serveur démontrée.

Test : test-28; test-3 ; anomalie : task-24

Preuves : manager-context.png; user1-in-azure.png; user3-in-med.png

Portée : Reprise v2.2 du08/11/2026

## INV-REPRISE-023 — Mot de passe d’une identité existante inchangé

**Verdict : PASS**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Gherkin  •  Environnement : STAGING
Préconditions : Quatre comptes racines disponibles ; staging et bypass activés ; purge des invitations confirmée
Given  une identité AuthGate existante reçoit une nouvelle invitation
When  PANDA se reconnecte avec son mot de passe habituel après activation
Then  la connexion fonctionne sans changement ni écrasement du mot de passe initial
Contrôles : vérifier organisation/établissement/formation/promotion, rôle, rafraîchissement, persistance, absence de fuite entre organisations et absence de succès fictif.
Preuves : écran d’invitation et état après rafraîchissement ; capture du menu après connexion ; accès autorisés et interdits ; ID utilisateur/organisation ; anomalies horodatées.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE   •   Ticket : _______________

Étapes exécutées / observé : Nouvelles identités uniques et activation automatique constatée après traitement, puis connexions réelles et reload. Une nouvelle identité au moins par centre. Douze invitations croisées réutilisent les quatre identités, leurs secrets et accès propriétaires ; rôles distincts conservés au choix d’espace. Le libellé Responsable pédagogique erroné est suivi séparément.

Test : test-3; test-5; test-28 ; anomalie : 

Preuves : trainer-created.png; trainer-status-rechecked.png; secretary-created.png; jury-created.png; med-trainer-created.png; user1-fourspaces.png; user2-fourspaces.png; user3-fourspaces.png; user4-fourspaces.png

Portée : Reprise v2.2 du08/11/2026

## INV-REPRISE-024 — Invité ne voit pas les données de l’organisation tierce

**Verdict : PASS**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Gherkin  •  Environnement : STAGING
Préconditions : Quatre comptes racines disponibles ; staging et bypass activés ; purge des invitations confirmée
Given  un compte est invité uniquement dans l’organisation A
When  PANDA examine le sélecteur de contexte et tente d’accéder à des ressources de B
Then  B n’est pas accessible, aucune liste ni fiche privée n’est divulguée
Contrôles : vérifier organisation/établissement/formation/promotion, rôle, rafraîchissement, persistance, absence de fuite entre organisations et absence de succès fictif.
Preuves : écran d’invitation et état après rafraîchissement ; capture du menu après connexion ; accès autorisés et interdits ; ID utilisateur/organisation ; anomalies horodatées.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE   •   Ticket : _______________

Étapes exécutées / observé : Formateur Med uniquement membre Ambulancier : dossier Horizon A connu valide refuse HTTP404 req7193 ; aucun nom, email ou contenu Horizon visible. Test d’une ressource représentative, pas preuve exhaustive de toutes les routes.

Test : test-26 ; anomalie : 

Preuves : med-before-foreign-learner.png; med-foreign-learner-final.png

Portée : Reprise v2.2 du08/11/2026

## INV-REPRISE-025 — Suspension d’une appartenance et maintien des autres

**Verdict : PASS**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Gherkin  •  Environnement : STAGING
Préconditions : Quatre comptes racines disponibles ; staging et bypass activés ; purge des invitations confirmée
Given  un compte possède deux appartenances actives
When  PANDA fait suspendre l’accès à A par un administrateur puis se reconnecte
Then  l’accès à A est interdit, l’accès à B reste fonctionnel et le menu se recalcule selon B
Contrôles : vérifier organisation/établissement/formation/promotion, rôle, rafraîchissement, persistance, absence de fuite entre organisations et absence de succès fictif.
Preuves : écran d’invitation et état après rafraîchissement ; capture du menu après connexion ; accès autorisés et interdits ; ID utilisateur/organisation ; anomalies horodatées.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE   •   Ticket : _______________

Étapes exécutées / observé : USER02 : suspension puis retrait de la seule appartenance secondaire Horizon ; nouvelle connexion propose trois autres espaces et Azur propriétaire reste fonctionnel. La restauration échoue séparément (SEC-REPRISE-038). L’ancien JWT conservé n’est pas validé.

Test : test-27 ; anomalie : task-25

Preuves : user2-suspended-spaces.png; user2-own-after-suspend.png; user2-revoked-spaces.png; user2-own-after-revoke.png

Portée : Reprise v2.2 du08/11/2026

## INV-REPRISE-026 — Retrait d’accès puis reconnexion

**Verdict : PASS**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Gherkin  •  Environnement : STAGING
Préconditions : Quatre comptes racines disponibles ; staging et bypass activés ; purge des invitations confirmée
Given  une identité dispose d’une appartenance active à A
When  PANDA retire son appartenance via une session administrateur puis se reconnecte
Then  le compte AuthGate peut exister mais les fonctions et données de A ne sont plus accessibles
Contrôles : vérifier organisation/établissement/formation/promotion, rôle, rafraîchissement, persistance, absence de fuite entre organisations et absence de succès fictif.
Preuves : écran d’invitation et état après rafraîchissement ; capture du menu après connexion ; accès autorisés et interdits ; ID utilisateur/organisation ; anomalies horodatées.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE   •   Ticket : _______________
31.6. Traçabilité et campagnes dépendantes

Étapes exécutées / observé : USER02 : suspension puis retrait de la seule appartenance secondaire Horizon ; nouvelle connexion propose trois autres espaces et Azur propriétaire reste fonctionnel. La restauration échoue séparément (SEC-REPRISE-038). L’ancien JWT conservé n’est pas validé.

Test : test-27 ; anomalie : task-25

Preuves : user2-suspended-spaces.png; user2-own-after-suspend.png; user2-revoked-spaces.png; user2-own-after-revoke.png

Portée : Reprise v2.2 du08/11/2026

## INV-REPRISE-027 — Session indépendante par utilisateur QA

**Verdict : BLOCKED**

Préconditions et attendu du cahier v2.2 :
Priorité : P1  •  Type : E2E UI / Gherkin  •  Environnement : STAGING
Préconditions : Quatre comptes racines disponibles ; staging et bypass activés ; purge des invitations confirmée
Given  deux identités nouvelles de rôles différents existent
When  PANDA les connecte successivement en sessions privées distinctes
Then  aucune identité, aucun rôle ni aucun contexte ne fuit entre les deux sessions
Contrôles : vérifier organisation/établissement/formation/promotion, rôle, rafraîchissement, persistance, absence de fuite entre organisations et absence de succès fictif.
Preuves : écran d’invitation et état après rafraîchissement ; capture du menu après connexion ; accès autorisés et interdits ; ID utilisateur/organisation ; anomalies horodatées.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE   •   Ticket : _______________

Étapes exécutées / observé : Connexions réelles après déconnexion réalisées, mais sessions privées indépendantes non disponibles sous la contrainte onglet 1 unique. Le critère spécifique de session privée/distincte n’est pas validé.

Test : test-1; test-27 ; anomalie : 

Preuves : 

Portée : Reprise v2.2 du08/11/2026

## INV-REPRISE-028 — Invitation et rôle persistent après rafraîchissement

**Verdict : PASS**

Préconditions et attendu du cahier v2.2 :
Priorité : P1  •  Type : E2E UI / Gherkin  •  Environnement : STAGING
Préconditions : Quatre comptes racines disponibles ; staging et bypass activés ; purge des invitations confirmée
Given  un compte est actif et affecté à un rôle
When  PANDA recharge la page, se déconnecte puis se reconnecte
Then  les droits et l’appartenance sont inchangés ; pas de retour à « Invitation envoyée »
Contrôles : vérifier organisation/établissement/formation/promotion, rôle, rafraîchissement, persistance, absence de fuite entre organisations et absence de succès fictif.
Preuves : écran d’invitation et état après rafraîchissement ; capture du menu après connexion ; accès autorisés et interdits ; ID utilisateur/organisation ; anomalies horodatées.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE   •   Ticket : _______________

Étapes exécutées / observé : Nouvelles identités uniques et activation automatique constatée après traitement, puis connexions réelles et reload. Une nouvelle identité au moins par centre. Douze invitations croisées réutilisent les quatre identités, leurs secrets et accès propriétaires ; rôles distincts conservés au choix d’espace. Le libellé Responsable pédagogique erroné est suivi séparément.

Test : test-3; test-5; test-28 ; anomalie : 

Preuves : trainer-created.png; trainer-status-rechecked.png; secretary-created.png; jury-created.png; med-trainer-created.png; user1-fourspaces.png; user2-fourspaces.png; user3-fourspaces.png; user4-fourspaces.png

Portée : Reprise v2.2 du08/11/2026

## INV-REPRISE-029 — Pas de mot de passe en clair dans les preuves

**Verdict : PASS**

Préconditions et attendu du cahier v2.2 :
Priorité : P1  •  Type : E2E UI / Gherkin  •  Environnement : STAGING
Préconditions : Quatre comptes racines disponibles ; staging et bypass activés ; purge des invitations confirmée
Given  PANDA exécute les scénarios d’authentification
When  PANDA exporte les captures et le rapport d’anomalies
Then  aucun mot de passe n’est affiché ou copié dans les preuves ; seules identité et réussite/échec sont tracées
Contrôles : vérifier organisation/établissement/formation/promotion, rôle, rafraîchissement, persistance, absence de fuite entre organisations et absence de succès fictif.
Preuves : écran d’invitation et état après rafraîchissement ; capture du menu après connexion ; accès autorisés et interdits ; ID utilisateur/organisation ; anomalies horodatées.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE   •   Ticket : _______________

Étapes exécutées / observé : Captures réalisées hors saisie des secrets ; exports et références dérivées expurgés des secrets QA et des empreintes. Aucun cookie, JWT ou lien d’invitation exporté. Identités, IDs de ressources et résultats seulement.

Test :  ; anomalie : 

Preuves : index-preuves.json

Portée : Reprise v2.2 du08/11/2026

## INV-REPRISE-030 — Stagiaire QA : demande d’émargement sans e-mail

**Verdict : FAIL**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Gherkin  •  Environnement : STAGING
Préconditions : Quatre comptes racines disponibles ; staging et bypass activés ; purge des invitations confirmée
Given  un stagiaire invité s’est connecté avec [secret QA] et une séance est terminée
When  le formateur demande une confirmation puis le stagiaire consulte son espace
Then  la demande est visible sans consultation d’e-mail ; les heures restent en attente jusqu’à confirmation réelle, sans auto-validation
Contrôles : vérifier organisation/établissement/formation/promotion, rôle, rafraîchissement, persistance, absence de fuite entre organisations et absence de succès fictif.
Preuves : écran d’invitation et état après rafraîchissement ; capture du menu après connexion ; accès autorisés et interdits ; ID utilisateur/organisation ; anomalies horodatées.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE   •   Ticket : _______________

Étapes exécutées / observé : Formateur ne peut pas créer la séance (task26). Une séance distincte préparée par administrateur permet de vérifier trois présences120min ; envois individuels et collectif refusent409, demandes Draft, aucun Pending chez les trois Stagiaires.

Test : test-43 ; anomalie : task-26; task-27

Preuves : trainer-create-blocked.png; attendance-three-present.png; attendance-requests-sent.png; attendance-bulk-final.png; student-a-drafts.png

Portée : Reprise v2.2 du08/11/2026

## INV-REPRISE-031 — Stagiaire QA : confirmation et recalcul des heures

**Verdict : BLOCKED**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Gherkin  •  Environnement : STAGING
Préconditions : Quatre comptes racines disponibles ; staging et bypass activés ; purge des invitations confirmée
Given  un stagiaire nouvellement invité possède une demande d’émargement non confirmée
When  PANDA confirme avec le compte Stagiaire puis consulte les vues Formateur et Stagiaire
Then  heures confirmées et statuts évoluent correctement ; droits et données restent isolés
Contrôles : vérifier organisation/établissement/formation/promotion, rôle, rafraîchissement, persistance, absence de fuite entre organisations et absence de succès fictif.
Preuves : écran d’invitation et état après rafraîchissement ; capture du menu après connexion ; accès autorisés et interdits ; ID utilisateur/organisation ; anomalies horodatées.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE   •   Ticket : _______________

Étapes exécutées / observé : Aucune demande envoyée : trois brouillons subsistent après409. Confirmation A, attente B et contestation C non exécutables. Refus d’un brouillon B sous A vérifié indépendamment (403), sans valider tout le scénario.

Test : test-43; test-41 ; anomalie : task-27

Preuves : attendance-bulk-final.png; student-a-foreign-request.png

Portée : Reprise v2.2 du08/11/2026

## INV-REPRISE-032 — Stagiaire QA : contestation et confidentialité

**Verdict : BLOCKED**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Gherkin  •  Environnement : STAGING
Préconditions : Quatre comptes racines disponibles ; staging et bypass activés ; purge des invitations confirmée
Given  un deuxième stagiaire nouvellement invité possède une demande de signature
When  PANDA conteste depuis son compte et tente de voir la demande du premier
Then  la contestation est enregistrée, aucune heure supplémentaire n’est confirmée, aucun accès à la demande d’un tiers
Contrôles : vérifier organisation/établissement/formation/promotion, rôle, rafraîchissement, persistance, absence de fuite entre organisations et absence de succès fictif.
Preuves : écran d’invitation et état après rafraîchissement ; capture du menu après connexion ; accès autorisés et interdits ; ID utilisateur/organisation ; anomalies horodatées.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE   •   Ticket : _______________

Étapes exécutées / observé : Aucune demande envoyée : trois brouillons subsistent après409. Confirmation A, attente B et contestation C non exécutables. Refus d’un brouillon B sous A vérifié indépendamment (403), sans valider tout le scénario.

Test : test-43; test-41 ; anomalie : task-27

Preuves : attendance-bulk-final.png; student-a-foreign-request.png

Portée : Reprise v2.2 du08/11/2026

## INV-REPRISE-033 — Bilan après purge et reprise

**Verdict : NOT_RUN**

Préconditions et attendu du cahier v2.2 :
Priorité : P1  •  Type : E2E UI / Gherkin  •  Environnement : STAGING
Préconditions : Quatre comptes racines disponibles ; staging et bypass activés ; purge des invitations confirmée
Given  tous les scénarios de cette campagne ont été tentés
When  PANDA établit les statuts PASS/FAIL/BLOCKED/NA et compare avec le rapport initial
Then  tous les nouveaux comptes actifs et leur première connexion sont documentés, les blocages d’invitation sont identifiés, les scénarios antérieurs restent traçables
Contrôles : vérifier organisation/établissement/formation/promotion, rôle, rafraîchissement, persistance, absence de fuite entre organisations et absence de succès fictif.
Preuves : écran d’invitation et état après rafraîchissement ; capture du menu après connexion ; accès autorisés et interdits ; ID utilisateur/organisation ; anomalies horodatées.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE   •   Ticket : _______________
31.7. Critères d’acceptation de la reprise
Tous les nouveaux comptes QA nécessaires sont créés sans limitation d’adresse en STAGING, avec rôle et organisation corrects. Au minimum une connexion réelle par rôle est prouvée avec [secret QA].
Aucune invitation de test attendue n’est considérée PASS si elle reste « Invitation envoyée », si le compte ne peut pas se connecter, ou si les menus/droits ne correspondent pas au rôle.
Les 12 invitations inter-organisations sont rejouées avec des identités existantes sans modification de leur mot de passe ni fuite d’autorisations.
Les scénarios bloqués par une mauvaise configuration du mot de passe QA, une panne de provisionnement ou un écran absent sont marqués explicitement FAIL ou BLOCKED, sans contournement par API.
Les confirmations de prestations demeurent manuelles même lorsque l’envoi d’e-mail est bypassé.
Après clôture de la campagne Invitations, PANDA reprend les scénarios fonctionnels non exécutés des sections précédentes, en conservant les données valides créées ici.
33 scénarios INV-REPRISE ajoutés. Résultats attendus à vérifier sur l’application déployée ; aucune exécution ni connexion staging effectuée au moment de la rédaction.

32. Campagne de reprise ciblée — Invitations, Register, révocations AuthGate et ancien JWT
VERSION 2.2 — STAGING UNIQUEMENT — Tests UI navigateur (sans invocation directe des API ni accès SQL). Cette campagne complète, sans remplacer, les 33 tests INV-REPRISE de la section 31 et tous les tests précédents. Aucun scénario de la section 32 n’a été exécuté à la rédaction.
32.1. Point de reprise, données et garde-fous
Les invitations précédentes ont été supprimées par le responsable du staging. NE PAS supprimer les quatre organisations de référence, les comptes racines ou les autres données métier ; NE PAS refaire un Register de ces comptes.
La suppression d’une invitation ne prouve pas la suppression d’une identité AuthGate ni des appartenances antérieures. Vérifier via l’interface les utilisateurs déjà existants, puis utiliser des adresses fictives inédites pour tester « nouvel invité + [secret QA] ». Ne jamais affirmer qu’un compte existant possède le mot de passe QA.
Précondition technique à déclarer : correctifs Register/Invitations/Organisations, contrôle des appartenances actives, endpoint MembershipState optimisé et délai de vérification AuthGate mis à jour déployés sur AuthGate puis PedagoraPilot.API ; front Angular redéployé. Si non confirmés, marquer les tests correspondants BLOCKED et notifier.
Tous les tests sont réalisés depuis le navigateur. Les tests d’ancien JWT utilisent une session de navigateur déjà ouverte, et éventuellement une autre session privée ; ne pas extraire ni réutiliser le JWT dans des requêtes API manuelles.
Validation métier : une organisation propre peut naître du parcours explicite Register/provisionnement ; une invitation n’en crée aucune. Une identité invitée peut rejoindre plusieurs organisations actives, chacune avec son rôle local. Le bypass d’e-mail ne confirme ni présence ni compétence.
Mot de passe initial attendu pour un compte entièrement nouveau provisionné en QA staging : [secret QA]. Les comptes AuthGate existants conservent leur propre mot de passe.
À chaque action : vérifier organisation, établissement, formation, promotion lorsqu’applicable ; capturer avant/après, rafraîchir, se reconnecter ; ne déclarer PASS que si le résultat visible et les restrictions d’accès sont démontrés.
32.2. Recréation des invitations après purge — identité et rôle

Étapes exécutées / observé : Bilan de lot produit ; clôture intégrale de campagne non acquise tant que les contrôles restants et les blocages ne sont pas résolus.

Test :  ; anomalie : 

Preuves : 

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-001 — Préconditions de reprise sans recréer le socle

**Verdict : PASS**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  les quatre comptes racines et organisations historiques existent et les invitations antérieures ont été purgées
When  PANDA se connecte successivement aux comptes racines et consulte Gestion des accès
Then  le socle métier reste utilisable ; seules les invitations concernées sont absentes ; les autres données ne sont ni effacées ni recréées
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________

Étapes exécutées / observé : Les quatre propriétaires se connectent, rechargent Gestion des accès et retrouvent leur organisation et site QA ; Horizon conserve sa formation. Anciennes invitations Horizon absentes. Un accès actif test@email.com préexistait dans Ambulancier et a été conservé.

Test : test-1 ; anomalie : 

Preuves : admin1.png; admin2.png; admin3.png; admin4.png

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-002 — Nouvelle invitation avec adresse jamais utilisée

**Verdict : PASS**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  une adresse fictive inédite est choisie pour un Formateur de Centre Horizon ECSR
When  la Direction invite cet utilisateur et actualise la liste après traitement
Then  l’invitation passe à Actif en staging sans clic sur un e-mail ; aucune organisation supplémentaire n’est créée
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________

Étapes exécutées / observé : Nouveau Formateur Horizon jamais utilisé auparavant : activation automatique différée, connexion réelle réussie sans email ni activation manuelle ; rôle Trainer, seul Horizon, session persistante après reload et reconnexion.

Test : test-3 ; anomalie : 

Preuves : trainer-created.png; trainer-status-rechecked.png; trainer-context.png; trainer-home-reloaded.png

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-003 — Connexion de l’identité nouvellement invitée

**Verdict : PASS**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  le Formateur inédit est affiché Actif et son identité AuthGate a été provisionnée
When  PANDA ferme la session Direction et se connecte comme l’invité avec [secret QA]
Then  la connexion réussit, le rôle Formateur et l’organisation invitante sont retrouvés après reconnexion
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________

Étapes exécutées / observé : Nouveau Formateur Horizon jamais utilisé auparavant : activation automatique différée, connexion réelle réussie sans email ni activation manuelle ; rôle Trainer, seul Horizon, session persistante après reload et reconnexion.

Test : test-3 ; anomalie : 

Preuves : trainer-created.png; trainer-status-rechecked.png; trainer-context.png; trainer-home-reloaded.png

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-004 — Contrôle précis du menu Formateur

**Verdict : FAIL**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  le nouvel invité est authentifié comme Formateur
When  PANDA parcourt les menus et tente les actions métier compatibles puis interdites selon la matrice de permissions
Then  seuls les menus/actions autorisés au Formateur sont accessibles ; les opérations Direction sont refusées, y compris après URL directe
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________

Étapes exécutées / observé : Formateur Horizon réellement connecté et affecté à la cohorte ; menus Direction et URL /acces interdits, mais création légitime de séance impossible : sélecteur Trainer vide et message No active trainer selected.

Test : test-43; test-40 ; anomalie : task-26; task-20

Preuves : trainer-create-blocked.png; trainer-home-errors.png

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-005 — Invitation d’un Responsable pédagogique

**Verdict : FAIL**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  une autre adresse inédite et un responsable habilité sont disponibles
When  PANDA invite puis se connecte au nouveau compte avec [secret QA]
Then  une seule appartenance active est proposée ; les menus reflètent le rôle Responsable pédagogique, sans droits de Direction implicites
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________

Étapes exécutées / observé : Rôles et espaces créés correctement ; après choix Responsable pédagogique, le libellé sous l’identité affiche Trainer. Reproduit nouveau Responsable Horizon, USER01 dans Azur et USER03 dans Ambulancier. Menus pédagogiques adaptés, aucune élévation serveur démontrée.

Test : test-3; test-28 ; anomalie : task-24

Preuves : manager-context.png

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-006 — Invitation d’une Secrétariat / gestion administrative

**Verdict : BLOCKED**

Préconditions et attendu du cahier v2.2 :
Priorité : P1  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  une autre adresse inédite et le rôle administratif disponible sont sélectionnés
When  PANDA invite puis teste la connexion [secret QA]
Then  les menus et opérations visibles correspondent au rôle effectif ; aucun accès aux évaluations confidentielles non accordées
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________

Étapes exécutées / observé : Secrétariat Azur actif et première connexion réussie ; menus, consultation Stagiaires et refus /acces et /administration observés. Opérations métier et périmètre complet non validés faute de formation/promotion Azur préparée.

Test : test-3 ; anomalie : 

Preuves : secretary-context.png; secretary-learners.png

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-007 — Invitation d’un Stagiaire

**Verdict : FAIL**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  une autre adresse inédite est invitée comme Stagiaire dans la formation autorisée
When  PANDA se connecte avec [secret QA] et ouvre son espace personnel
Then  seules ses propres informations, séances, présences et demandes autorisées sont consultables
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________

Étapes exécutées / observé : Les trois Stagiaires se connectent à leur propre cohorte. A ne lit pas le brouillon B (403). Cependant Séances expose au Stagiaire le formulaire et le bouton Create session actifs ; validation métier accessible. Aucune sauvegarde non autorisée démontrée.

Test : test-41 ; anomalie : task-22

Preuves : student-sessions.png; student-create-forbidden.png

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-008 — Invitation d’un Jury

**Verdict : BLOCKED**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  une autre adresse inédite est affectée au rôle Jury pour le contexte prévu
When  PANDA se connecte avec [secret QA] et inspecte les écrans d’examen
Then  les menus et candidats accessibles sont strictement limités aux affectations du Jury
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________

Étapes exécutées / observé : Jury Provence actif et connecté à /jury ; menus Home/Jury seuls et URL administratives refusées. Aucune session d’examen attribuée, donc contrôle positif des candidats bloqué. Le corps de /jury vide est documenté séparément.

Test : test-42 ; anomalie : task-23

Preuves : jury-blank-final.png

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-009 — Invitation d’un Tuteur, si proposé

**Verdict : BLOCKED**

Préconditions et attendu du cahier v2.2 :
Priorité : P1  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  un rôle Tuteur et l’écran d’invitation sont disponibles
When  PANDA invite le compte inédit et tente une connexion [secret QA]
Then  le tuteur ne voit que les stages et stagiaires autorisés ; si son parcours UI manque, consigner BLOCKED, sans inventer de fonctionnalité
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________

Étapes exécutées / observé : Le formulaire Inviter un utilisateur ne propose pas le rôle Tuteur. Un lien My placements (tutor) existe pour d’autres profils, ce qui ne prouve pas un provisionnement Tuteur. Parcours d’invitation via stage et données de stage restant à préparer.

Test : test-3 ; anomalie : 

Preuves : admin4.png

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-010 — Compte AuthGate existant : ne pas réinitialiser le mot de passe

**Verdict : PASS**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  un utilisateur AuthGate existant et une organisation distincte sont identifiés
When  PANDA invite l’identité existante puis se connecte avec son identifiant habituel
Then  nouvelle appartenance visible si active, anciennes conservées ; le mot de passe AuthGate existant reste inchangé
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________

Étapes exécutées / observé : Les quatre identités AuthGate de référence, déjà utilisées historiquement, ont été invitées sans réinscription ni réinitialisation ; leurs connexions habituelles réussissent, organisations propriétaires et appartenances secondaires conservées.

Test : test-5; test-28 ; anomalie : 

Preuves : user1-fourspaces.png; user2-fourspaces.png; user3-fourspaces.png; user4-fourspaces.png

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-011 — Ne pas confondre compte invité et organisation propre

**Verdict : PASS**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  un nouvel utilisateur a été créé exclusivement par invitation et n’a jamais emprunté Register
When  PANDA se connecte puis ouvre le sélecteur d’organisations
Then  seule l’organisation invitante active apparaît ; aucune organisation personnelle ou par défaut non sollicitée
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________

Étapes exécutées / observé : Identités créées exclusivement par invitation : Formateur, Responsable, Stagiaires et Secrétariat ne présentent aucune organisation personnelle. Contextes propres à l’organisation invitante ; jamais de Register pour ces identités.

Test : test-3; test-1 ; anomalie : 

Preuves : trainer-context.png; manager-context.png; student-context.png; secretary-context.png; med-trainer-context.png

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-012 — Compte créé par Register : organisation propre conservée

**Verdict : PASS**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  un compte de référence déjà créé via Register est disponible
When  PANDA se connecte puis consulte la sélection d’organisation
Then  son organisation propriétaire reste accessible si active ; le filtrage n’efface pas son accès légitime
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________

Étapes exécutées / observé : Les quatre propriétaires conservent leur organisation créée par Register. En complément, un Register inédit QA Register V22 20261108 a été exécuté : une seule organisation explicitement nommée, persistante après connexion/reload, aucun accès aux quatre centres non invités.

Test : test-1; test-31 ; anomalie : 

Preuves : register-own-context.png; register-own-reload.png; user1-fourspaces.png

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-013 — Inviter un inscrit dans une deuxième organisation

**Verdict : PASS**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  un compte propriétaire créé par Register dispose de son organisation active
When  une Direction d’une autre organisation l’invite et il se reconnecte
Then  l’organisation initiale et l’organisation invitante sont proposées si les deux appartenances sont actives, chacune avec les bons rôles
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________

Étapes exécutées / observé : Les quatre identités AuthGate de référence, déjà utilisées historiquement, ont été invitées sans réinscription ni réinitialisation ; leurs connexions habituelles réussissent, organisations propriétaires et appartenances secondaires conservées.

Test : test-5; test-28 ; anomalie : 

Preuves : user1-fourspaces.png; user2-fourspaces.png; user3-fourspaces.png; user4-fourspaces.png

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-014 — Purge d’invitation sans supposer identité supprimée

**Verdict : PASS**

Préconditions et attendu du cahier v2.2 :
Priorité : P1  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  une adresse a déjà été utilisée lors d’une précédente recette
When  PANDA tente un nouveau parcours d’invitation et documente les résultats
Then  aucun mot de passe QA n’est supposé pour une identité existante ; tout blocage de connexion est signalé avec sa cause observable
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________
32.3. Sélection d’espace et isolation entre AuthGate et PedagoraPilot

Étapes exécutées / observé : Les quatre identités AuthGate de référence, déjà utilisées historiquement, ont été invitées sans réinscription ni réinitialisation ; leurs connexions habituelles réussissent, organisations propriétaires et appartenances secondaires conservées.

Test : test-5; test-28 ; anomalie : 

Preuves : user1-fourspaces.png; user2-fourspaces.png; user3-fourspaces.png; user4-fourspaces.png

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-015 — 12 invitations croisées multi-organisations

**Verdict : PASS**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  les quatre comptes racines conservent leurs identités et les quatre organisations de test
When  PANDA réalise les 12 invitations croisées prévues en section 31, puis ouvre chaque session
Then  chaque utilisateur sélectionne uniquement ses organisations actives ; les rôles sont spécifiques à chaque appartenance ; aucun compte n’est recréé
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________

Étapes exécutées / observé : Les douze relations de la matrice ont été créées actives, relues après reload et les douze espaces secondaires ouverts. État obtenu avant le scénario de révocation ; à la fin USER02→Horizon reste révoqué car restauration échoue409.

Test : test-5; test-28 ; anomalie : task-25

Preuves : cross-1-2.png; cross-4-3.png; user1-fourspaces.png; user2-fourspaces.png; user3-fourspaces.png; user4-fourspaces.png

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-016 — Deux organisations actives, changement de rôle

**Verdict : FAIL**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  un utilisateur possède deux appartenances actives avec rôles différents
When  PANDA passe de la première à la seconde et contrôle menus, actions et listes
Then  le changement de contexte met à jour permissions et données immédiatement, sans réutiliser le rôle de l’autre organisation
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________

Étapes exécutées / observé : Rôles et espaces créés correctement ; après choix Responsable pédagogique, le libellé sous l’identité affiche Trainer. Reproduit nouveau Responsable Horizon, USER01 dans Azur et USER03 dans Ambulancier. Menus pédagogiques adaptés, aucune élévation serveur démontrée.

Test : test-28 ; anomalie : task-24

Preuves : user1-in-azure.png; user3-in-med.png

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-017 — Appartenance locale inactive absente du sélecteur

**Verdict : PASS**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  un utilisateur possède une appartenance active et une autre inactive localement
When  PANDA reconnecte le compte et ouvre le sélecteur
Then  seule l’appartenance active est proposée, même si AuthGate connaît encore l’autre organisation
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________

Étapes exécutées / observé : Appartenance USER02 Horizon suspendue localement : Horizon absent du sélecteur après connexion ; trois autres espaces présents, Azur fonctionnel. Aucun espace de secours créé.

Test : test-27 ; anomalie : 

Preuves : user2-suspended-horizon.png; user2-suspended-spaces.png

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-018 — Organisation suspendue ou fermée non accessible

**Verdict : BLOCKED**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  une organisation de test peut être suspendue depuis l’interface autorisée sans compromettre le socle
When  PANDA suspend l’organisation, actualise le sélecteur et teste une navigation persistante
Then  l’organisation indisponible est exclue du choix et ses routes métier sont refusées, les organisations non concernées restent utilisables
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________

Étapes exécutées / observé : Aucun contrôle autorisé de suspension/fermeture d’une organisation entière trouvé dans Organization overview et Organization administration inspectés ; seuls création/configuration, identité, modules et politiques sont exposés. Aucune suspension des quatre organisations conservées. Interface AuthGate administrative non disponible.

Test :  ; anomalie : 

Preuves : organization-controls.png; administration-controls.png; authgate-root404.png

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-019 — Absence d’appartenances actives

**Verdict : PASS**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  un utilisateur de test ne possède plus aucune appartenance active
When  PANDA se déconnecte/reconnecte puis consulte les espaces proposés
Then  aucune organisation de secours n’est inventée, aucun accès métier indu ; un état explicite est affiché
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________

Étapes exécutées / observé : Le seul accès du nouveau Formateur Med a été suspendu. Préconnexion refuse avec Application membership is inactive, sans espace métier ni organisation de secours. Réactivation via UI par USER04 et nouvelle connexion réussie.

Test : test-27 ; anomalie : 

Preuves : med-only-membership-suspended.png; med-no-active-membership.png; med-membership-restored.png; med-login-restored.png

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-020 — Accès direct à une URL d’un autre tenant

**Verdict : PASS**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  un utilisateur n’est membre que d’une organisation A
When  PANDA tente via navigation normale une URL métier connue de l’organisation B
Then  aucune donnée B n’est montrée ; le serveur refuse la requête non autorisée, même si le menu a été masqué
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________
32.4. Révocations en session ouverte et anciens jetons

Étapes exécutées / observé : Formateur Med uniquement membre Ambulancier : dossier Horizon A connu valide refuse HTTP404 req7193 ; aucun nom, email ou contenu Horizon visible. Test d’une ressource représentative, pas preuve exhaustive de toutes les routes.

Test : test-26 ; anomalie : 

Preuves : med-foreign-learner-final.png

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-021 — Suspension depuis PedagoraPilot en session ouverte

**Verdict : BLOCKED**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  un invité est connecté dans un navigateur et une Direction dispose d’une deuxième session
When  la Direction suspend son appartenance pendant que l’invité garde sa page ouverte, puis l’invité recharge
Then  les opérations métier de l’organisation suspendue sont refusées sans attendre la déconnexion ni l’expiration du JWT
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________

Étapes exécutées / observé : Ces scénarios exigent une ou plusieurs sessions simultanées indépendantes et une session antérieure conservée. Impossible sous onglet1 unique, interdiction new_page et sans manipulation JWT. Suspensions et révocations après nouvelle connexion vérifiées séparément ; pas de PASS sur ancien JWT.

Test : test-27 ; anomalie : 

Preuves : 

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-022 — Révocation depuis PedagoraPilot et reconnexion

**Verdict : PASS**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  un invité actif et le menu de gestion des accès sont disponibles
When  la Direction retire l’accès puis l’invité recharge et tente une nouvelle connexion
Then  l’organisation retirée disparaît ; ses données sont refusées ; la connexion à une autre organisation active reste possible
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________

Étapes exécutées / observé : USER02 : suspension puis retrait de la seule appartenance secondaire Horizon ; nouvelle connexion propose trois autres espaces et Azur propriétaire reste fonctionnel. La restauration échoue séparément (SEC-REPRISE-038). L’ancien JWT conservé n’est pas validé.

Test : test-27 ; anomalie : task-25

Preuves : user2-revoked-spaces.png; user2-own-after-revoke.png

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-023 — Révocation directement dans AuthGate si UI administrateur disponible

**Verdict : BLOCKED**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  un administrateur autorisé dispose d’une interface de révocation AuthGate en staging et d’une session invité ouverte
When  l’administrateur révoque l’appartenance AuthGate puis l’invité actualise PedagoraPilot
Then  l’accès métier est refusé malgré la session/JWT antérieur ; sinon scénario BLOCKED avec raison précise si interface indisponible
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________

Étapes exécutées / observé : Aucune interface administrative AuthGate autorisée fournie. Navigation vers la racine https://auth.staging.locaguest.com affiche HTTP404. Cela ne signifie pas que les API AuthGate sont indisponibles ; login via application fonctionne. Pas de révocation AuthGate directe réalisée.

Test : test-27 ; anomalie : 

Preuves : authgate-root404.png

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-024 — Révocation de A sans effet sur B

**Verdict : BLOCKED**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  un même utilisateur appartient activement à deux organisations A et B
When  la Direction révoque uniquement A puis PANDA teste les deux espaces avec la session existante
Then  A devient inaccessible, B demeure accessible avec son rôle et ses données propres
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________

Étapes exécutées / observé : Ces scénarios exigent une ou plusieurs sessions simultanées indépendantes et une session antérieure conservée. Impossible sous onglet1 unique, interdiction new_page et sans manipulation JWT. Suspensions et révocations après nouvelle connexion vérifiées séparément ; pas de PASS sur ancien JWT.

Test : test-27 ; anomalie : 

Preuves : 

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-025 — Tentative d’action métier avec ancien écran non actualisé

**Verdict : BLOCKED**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  un invité conserve une page d’édition ouverte avant suspension
When  la Direction révoque l’accès puis l’invité tente de sauvegarder depuis cette page
Then  la sauvegarde est refusée côté serveur et aucun changement interdit n’est persisté malgré l’ancien écran ou JWT
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________

Étapes exécutées / observé : Ces scénarios exigent une ou plusieurs sessions simultanées indépendantes et une session antérieure conservée. Impossible sous onglet1 unique, interdiction new_page et sans manipulation JWT. Suspensions et révocations après nouvelle connexion vérifiées séparément ; pas de PASS sur ancien JWT.

Test : test-27 ; anomalie : 

Preuves : 

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-026 — Session déjà ouverte en temps réel après révocation

**Verdict : BLOCKED**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  un utilisateur a une page ouverte avec notifications et un accès révoqué
When  PANDA observe le comportement de l’écran, de ses notifications et des actions après révocation
Then  aucune nouvelle donnée confidentielle ne devient accessible ; tout WebSocket conservé ou notification persistante est consigné explicitement comme limite à investiguer
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________

Étapes exécutées / observé : Ces scénarios exigent une ou plusieurs sessions simultanées indépendantes et une session antérieure conservée. Impossible sous onglet1 unique, interdiction new_page et sans manipulation JWT. Suspensions et révocations après nouvelle connexion vérifiées séparément ; pas de PASS sur ancien JWT.

Test : test-27 ; anomalie : 

Preuves : 

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-027 — Modification du rôle et vérification des droits existants

**Verdict : BLOCKED**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  un utilisateur actif dispose d’un rôle A, puis la Direction lui affecte un rôle B via UI
When  PANDA conserve l’ancienne session et reteste les actions interdites au nouveau rôle
Then  les changements doivent être imposés côté serveur ; tout droit périmé encore utilisable constitue un FAIL même si le menu est masqué
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________
32.5. Résilience du contrôle MembershipState / AuthGate

Étapes exécutées / observé : Ces scénarios exigent une ou plusieurs sessions simultanées indépendantes et une session antérieure conservée. Impossible sous onglet1 unique, interdiction new_page et sans manipulation JWT. Suspensions et révocations après nouvelle connexion vérifiées séparément ; pas de PASS sur ancien JWT.

Test : test-27 ; anomalie : 

Preuves : 

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-028 — Navigation normale après correctif MembershipState

**Verdict : FAIL**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  AuthGate et PedagoraPilot.API corrigés sont déployés et un invité actif dispose d’une session
When  PANDA parcourt plusieurs menus métier et actualise à plusieurs reprises
Then  aucun 500 inattendu ni annulation visible ; les opérations légitimes restent utilisables
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________

Étapes exécutées / observé : Navigation et logins des comptes légitimes observés sans500 inattendu dans les requêtes inspectées. Mais le Formateur actif affecté ne peut pas créer sa séance (listes/réponses403). L’élimination d’OperationCanceledException et le déploiement précis ne sont pas prouvés par UI.

Test : test-43; test-40 ; anomalie : task-26; task-20

Preuves : trainer-create-blocked.png; trainer-home-errors.png

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-029 — Connexion simultanée de comptes QA

**Verdict : BLOCKED**

Préconditions et attendu du cahier v2.2 :
Priorité : P1  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  trois utilisateurs autorisés de rôles et organisations différents disposent de sessions distinctes
When  PANDA effectue des navigations rapprochées puis vérifie chaque session
Then  aucun mélange de contexte ni perte injustifiée de droits ; noter latences/erreurs visibles sans inventer de métriques réseau
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________

Étapes exécutées / observé : Ces scénarios exigent une ou plusieurs sessions simultanées indépendantes et une session antérieure conservée. Impossible sous onglet1 unique, interdiction new_page et sans manipulation JWT. Suspensions et révocations après nouvelle connexion vérifiées séparément ; pas de PASS sur ancien JWT.

Test : test-27 ; anomalie : 

Preuves : 

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-030 — Indisponibilité AuthGate — arrêt sécurisé (conditionnel)

**Verdict : BLOCKED**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  une interruption contrôlée d’AuthGate est autorisée par l’exploitant staging et est rétablie après essai
When  PANDA tente une action métier pendant l’incident selon un scénario coordonné
Then  aucun accès non vérifié n’est accordé ; un message maîtrisé apparaît, et la reprise fonctionne après restauration ; sinon BLOCKED sans provoquer de panne
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________

Étapes exécutées / observé : Aucune interruption coordonnée autorisée par l’exploitant ; aucune panne AuthGate provoquée. Test conditionnel de refus sécurisé pendant panne non exécuté.

Test :  ; anomalie : 

Preuves : 

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-031 — Délai d’attente AuthGate — pas de 500 brut

**Verdict : BLOCKED**

Préconditions et attendu du cahier v2.2 :
Priorité : P1  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  une latence ou panne temporaire est constatée lors d’un test réel ou simulée par l’exploitant hors UI
When  PANDA observe le comportement navigateur lors d’une consultation métier
Then  l’application ne divulgue pas de stack trace, n’accorde pas de permissions par défaut ; erreur temporaire maîtrisée si vérification impossible
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________

Étapes exécutées / observé : Aucune latence/panne AuthGate réelle isolée observée et aucune simulation par exploitant disponible. Les délais d’attente d’outil sur textes absents ne sont pas des incidents AuthGate.

Test :  ; anomalie : 

Preuves : 

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-032 — Rafraîchissement et déconnexion après jeton expiré

**Verdict : NOT_RUN**

Préconditions et attendu du cahier v2.2 :
Priorité : P1  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  une session est active jusqu’à expiration normale, sans altération manuelle du JWT
When  PANDA attend la condition, navigue puis se reconnecte si l’application le demande
Then  les jetons expirés ne donnent pas accès et l’expérience reste cohérente ; aucun cycle infini de reconnexions SignalR
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________

Étapes exécutées / observé : Expiration naturelle d’une même session non atteinte/observée ; plusieurs reconnexions nécessaires aux autres parcours. Aucun JWT extrait ou altéré ; gestion après expiration non validée.

Test :  ; anomalie : 

Preuves : 

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-033 — Contrôle des routes hors contexte de travail

**Verdict : NOT_RUN**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  un utilisateur authentifié n’a pas encore sélectionné son organisation
When  PANDA consulte le sélecteur puis tente de naviguer vers une fonctionnalité métier
Then  le choix des espaces reste disponible, mais la route métier exige une organisation valide et active
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________
32.6. Non-régression des prestations sans e-mail

Étapes exécutées / observé : Contrôle d’une route métier avec absence démontrée de tout contexte actif restant à exécuter. Les choix d’espaces et les contextes actifs valides ont été testés, sans présumer le cas sans contexte.

Test :  ; anomalie : 

Preuves : 

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-034 — Demande de confirmation sans e-mail sous compte invité

**Verdict : FAIL**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  un Formateur et deux Stagiaires QA nouvellement invités sont connectables
When  le Formateur termine la séance, enregistre les présences et demande la confirmation
Then  chaque stagiaire voit uniquement sa propre demande depuis son espace sans accès à sa boîte mail ; la séance reste en attente
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________

Étapes exécutées / observé : Formateur ne peut pas créer la séance (task26). Une séance distincte préparée par administrateur permet de vérifier trois présences120min ; envois individuels et collectif refusent409, demandes Draft, aucun Pending chez les trois Stagiaires.

Test : test-43 ; anomalie : task-26; task-27

Preuves : trainer-create-blocked.png; attendance-requests-sent.png; attendance-bulk-final.png

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-035 — Heures réalisées et confirmées non confondues

**Verdict : BLOCKED**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  une séance de 2 h concerne trois stagiaires A, B et C
When  A confirme, B laisse en attente, C conteste depuis trois sessions distinctes
Then  total réalisé 6 h ; confirmé 2 h ; non confirmé 4 h ; aucun acquis de compétence n’est créé par la signature
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________

Étapes exécutées / observé : Trois présences120min confirmées comme réalisées (6h manuelles), mais envoi de demandes409 : aucun Pending, aucune confirmation/contestation. Les totaux2h/4h et l’invalidation d’une signature confirmée ne sont pas testables actuellement.

Test : test-43 ; anomalie : task-27

Preuves : attendance-three-present.png; attendance-bulk-final.png

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-036 — Signature obsolète après correction

**Verdict : BLOCKED**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  un émargement a été signé puis modifié par un acteur autorisé
When  PANDA revient dans l’espace stagiaire et recharge la progression
Then  la confirmation précédente n’est plus comptée pour la nouvelle version ; une nouvelle confirmation est requise
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________
32.7. Clôture, preuves et critères de sortie

Étapes exécutées / observé : Trois présences120min confirmées comme réalisées (6h manuelles), mais envoi de demandes409 : aucun Pending, aucune confirmation/contestation. Les totaux2h/4h et l’invalidation d’une signature confirmée ne sont pas testables actuellement.

Test : test-43 ; anomalie : task-27

Preuves : attendance-three-present.png; attendance-bulk-final.png

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-037 — Bilan des invitations recréées après purge

**Verdict : NOT_RUN**

Préconditions et attendu du cahier v2.2 :
Priorité : P1  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  toutes les invitations nécessaires à la reprise ont été exécutées ou tentées
When  PANDA produit un tableau par identité, organisation, rôle et statut de première connexion
Then  chaque nouveau compte a son résultat [secret QA] documenté ; les identités existantes sont distinguées ; aucune invitation restante non expliquée
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________

Étapes exécutées / observé : Rapport intermédiaire de lot et tableaux produits ; critères de clôture intégrale non satisfaits. Autres invitations de la matrice de profils par centre et contrôles restants à poursuivre.

Test :  ; anomalie : 

Preuves : 

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-038 — Rétablissement des organisations de test après scénarios destructifs

**Verdict : FAIL**

Préconditions et attendu du cahier v2.2 :
Priorité : P0  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  des suspensions ou changements de rôle ont été effectués dans les seuls comptes fictifs prévus
When  PANDA remet les droits de référence nécessaires aux prochaines campagnes via l’UI et vérifie
Then  les comptes racines et organisations de référence sont réutilisables, les données ne sont pas effacées ; restauration impossible consignée
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________

Étapes exécutées / observé : Les propriétaires et données métier conservés, FormateurMed suspendu puis réactivé avec connexion réussie. En revanche la relation secondaire USER02→Horizon retirée ne peut être restaurée par réinvitation (409). Elle reste révoquée à la fin du lot.

Test : test-27 ; anomalie : task-25

Preuves : user2-restore-error.png; med-membership-restored.png

Portée : Reprise v2.2 du08/11/2026

## SEC-REPRISE-039 — Rapport avec verdicts et preuves des correctifs sécurité

**Verdict : NOT_RUN**

Préconditions et attendu du cahier v2.2 :
Priorité : P1  •  Type : E2E UI / Given–When–Then  •  Environnement : STAGING
Préconditions : Staging disponible ; état et identité connus ; navigateur QA autorisé
Given  les scénarios de cette campagne et de la section 31 ont été exécutés ou classés
When  PANDA consolide PASS/FAIL/BLOCKED/NA et les tickets d’anomalie
Then  les points non vérifiés (notamment révocation AuthGate directe, panne simulée, WebSocket) ne sont jamais annoncés PASS ; liste des défauts P0/P1 et recommandation GO/NO GO justifiée
Preuves requises : captures du contexte actif et de l’écran concerné, URL, rôle et organisation, étapes horodatées, statut avant/après actualisation/reconnexion, erreur navigateur si accessible. Ne jamais exposer mot de passe, cookie, JWT ou lien d’invitation.
Verdict : □ PASS   □ FAIL   □ BLOCKED   □ NOT APPLICABLE  •  Référence anomalie : ____________
Critères de sortie : (1) invitation nouvelle identité → statut Actif → connexion réelle [secret QA] → menu/rôle correct ; (2) invitation ≠ création d’organisation propre ; (3) seules appartenances actives proposées ; (4) suspension/révocation testée avec session préexistante, actions métier refusées ; (5) accès aux autres organisations actives maintenu ; (6) absence de 500 récurrent sur la vérification MembershipState ; (7) prestations confirmées uniquement par stagiaire ; (8) scénarios impossibles explicitement BLOCKED.
39 nouveaux scénarios SEC-REPRISE, complémentaires aux 33 INV-REPRISE de la v2.1. Ne pas confondre scénarios rédigés avec scénarios effectivement exécutés.

Étapes exécutées / observé : Rapport intermédiaire de lot et tableaux produits ; critères de clôture intégrale non satisfaits. Autres invitations de la matrice de profils par centre et contrôles restants à poursuivre.

Test :  ; anomalie : 

Preuves : 

Portée : Reprise v2.2 du08/11/2026
