# Réseau observé depuis les actions UI
Aucun appel API manuel. IDs de requêtes locaux à la capture Chrome ; pas de headers, cookie ou JWT exportés.
- Connexion Formateur Horizon : Auth/login200 req567, memberships200 req569 ; préchargements referentials403 req574/585, programs403 req586, audit403 req587, dashboards403 req588/589.
- Après retrait USER02 Horizon, réinvitation UI : access/invite409 req5455, erreur générique.
- Séance administrateur : Présences GETattendance200 req5913 ; brouillons détailsUI Present120min chacun.
- Demandes individuelles : signatures/drafts200 req6101/6109/6114 ; request409 req6103/6110/6115.
- Envoi collectif : signatures/batch/request409 req6690 ; trois Draft,Pending0.
- StagiaireA vers contenuB : GETsignatures/attendance/{B}/content403 req6267, aucun contenu étranger.
- FormateurMed vers dossierHorizonA : GETreporting/learners/{A}/detail404 req7193, aucune identité ni donnée Horizon visible.
- Racine AuthGate404 dans navigateur ; pas une preuve de panne API. Les branding404 optionnels ne sont pas interprétés comme défaut de sécurité.
Aucun500 inattendu vu dans les requêtes inspectées. Ceci ne prouve pas l'élimination d'une exception backend ni un comportement sous charge/expiration.
