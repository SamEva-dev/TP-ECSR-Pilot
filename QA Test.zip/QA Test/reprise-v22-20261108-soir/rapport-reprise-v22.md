# Reprise QA v2.2 — lot du 8 novembre 2026 au soir

**Conclusion : NO GO. La recette reste en cours.** Les invitations et connexions ont nettement progressé, mais les droits Stagiaire, la création de séance par Formateur, l’envoi des confirmations et la restauration d’une appartenance révoquée présentent des défauts ouverts. Les tests sur ancien JWT conservé ne sont pas validés.

## A. Périmètre et avancement

Application : https://pedagora.staging.locaguest.com ; AuthGate : https://auth.staging.locaguest.com. Staging uniquement, onglet1 existant, UI exclusivement, aucun appel API manuel, aucun JWT extrait/modifié, aucun changement de code. Aucun démarrage local nécessaire. Exécution commencée vers20:29UTC (21:29Paris). Quatre propriétaires réutilisés, aucune réinscription de ces comptes, aucun mot de passe changé.

Le DOCX actuel contient **865 identifiants uniques :793 historiques +33 INV-REPRISE +39 SEC-REPRISE**. Les quatre IDs ORG-SPEC comportent deux chiffres : ils sont inclus. Les chiffres historiques sont cohérents, mais ne constituent pas une preuve sur la version actuelle. Le registre antérieur campagne-20261108.json est conservé.

Les sections31–32 comptent **31PASS,14FAIL,22BLOCKED,0N/A,5NOT_RUN**, soit45 scénarios exécutés sur72 (62,50%). Les scénarios FAILED peuvent référencer un même défaut :14FAIL ne signifient pas14bugs.

Au cumul des865 références : **58PASS,17FAIL,31BLOCKED,3N/A,756NOT_RUN**. Couverture exécutée75/865 = **8,67%** ; réussite58/75 =77,33%, comprenant les résultats historiques non tous rejoués. Parmi les793 scénarios antérieurs, la référence de30 exécutés est conservée ;45 nouvelles références exécutées s’ajoutent. Les autres actions préparatoires ne sont pas promues arbitrairement en PASS complet du cahier.

Restent non exécutés dans31–32 : INV-REPRISE-033 et SEC-REPRISE-032/033/037/039. Ces références concernent notamment expiration naturelle, route sans contexte démontré et critères de bilan/clôture intégraux. Les blocages sont détaillés par ID, sans les transformer en réussites.

## B. Invitations, comptes et appartenances

Les quatre connexions propriétaires et la purge ont été contrôlées avant les invitations. Horizon, Azur et Provence ne présentaient que leur propriétaire ; Ambulancier présentait en plus test@email.com, Formateur actif préexistant, conservé et non utilisé. Les quatre sites QA et la formation Horizon préexistants sont toujours disponibles.

**Huit identités inédites ont été créées par invitation et connectées réellement.** Aucun compte n’est déclaré fonctionnellement conforme sur la seule base d’un état Active. Le tableau comptes-invites.csv distingue réussite d’authentification et verdict fonctionnel. Un neuvième compte, créé explicitement par Register, sert au cas organisation propriétaire ; il ne provient pas d’une invitation.

Les nouvelles adresses partagent le préfixe traçable qa.v22.20261108t2034 et le domaine fictif example.com. Leurs détails, menus observés et limites figurent ci-dessous. Aucune boîte mail n’a été utilisée et aucune livraison de mail n’est déclarée réussie.

### Tableau des comptes

| Compte fictif | Organisation / rôle | État | Login réel | Verdict fonctionnel | Limite / preuve |
|---|---|---|---|---|---|
| qa.v22.20261108t2034.formateur.horizon@example.com | Centre Horizon ECSR / Trainer | Active | PASS | FAIL | Affectation cohorte persistée ; création de séance impossible (task26), accueil incohérent (task19/20). [trainer-context](preuves/trainer-context.png) |
| qa.v22.20261108t2034.responsable.horizon@example.com | Centre Horizon ECSR / Educational manager | Active | PASS | FAIL | Responsable de la formation et de la promotion ; libellé Trainer erroné (task24). [manager-context](preuves/manager-context.png) |
| qa.v22.20261108t2034.stagiairea.horizon@example.com | Centre Horizon ECSR / Student | Active | PASS | FAIL | Formulaire Séances exposé (task22) ; demande B refusée403. [student-context](preuves/student-context.png) |
| qa.v22.20261108t2034.stagiaireb.horizon@example.com | Centre Horizon ECSR / Student | Active | PASS | BLOCKED | Aucune demande envoyée (task27), confirmation/contestation non exécutables. [student-b-context](preuves/student-b-context.png) |
| qa.v22.20261108t2034.stagiairec.horizon@example.com | Centre Horizon ECSR / Student | Active | PASS | BLOCKED | Aucune demande envoyée (task27), confirmation/contestation non exécutables. [student-c-context](preuves/student-c-context.png) |
| qa.v22.20261108t2034.secretariat.azur@example.com | Académie Azur Deux-Roues / Administration | Active | PASS | BLOCKED | Login et menus/restrictions vérifiés ; CRUD affecté faute de formation/promotion Azur non validé. [secretary-context](preuves/secretary-context.png) |
| qa.v22.20261108t2034.jury.provence@example.com | Institut Provence Poids Lourds / Jury member | Active | PASS | BLOCKED | Aucun examen affecté ; espace Jury vide (task23). [jury-space](preuves/jury-space.png) |
| qa.v22.20261108t2034.formateur.med@example.com | Institut Méditerranée Ambulancier / Trainer | Active (restored) | PASS | BLOCKED | Suspendu puis réactivé, nouvelle connexion prouvée ; opérations métier faute de formation/cohorte Med non validées. [med-trainer-context](preuves/med-trainer-context.png) |
| qa.v22.20261108t2055.register@example.com | QA Register V22 20261108 / Organization administrator | Active | PASS | PASS | Compte additionnel créé explicitement via Register ; une seule organisation propre, aucun accès aux quatre centres. [register-own-context](preuves/register-own-context.png) |

Les intitulés Administration/Student/Jury member correspondent aux libellés UI de Secrétariat/Stagiaire/Jury. Aucun rôle Tuteur n’est proposé dans le formulaire d’invitation inspecté ; l’existence du lien My placements (tutor) chez d’autres profils ne suffit pas à valider le provisionnement Tuteur. Les parcours de stage et d’examen nécessaires restent à préparer.

### Matrice des douze invitations croisées

| Source | USER01 | USER02 | USER03 | USER04 |
|---|---|---|---|---|
| Horizon | Propriétaire conservé | Trainer | Administration | Jury member |
| Azur | Educational manager | Propriétaire conservé | Trainer | Administration |
| Provence | Jury member | Site management | Propriétaire conservé | Trainer |
| Ambulancier | Administration | Jury member | Educational manager | Propriétaire conservé |

Les douze relations ont été créées actives, relues après actualisation et les douze espaces secondaires ouverts. Chaque nouvelle connexion des quatre racines proposait les quatre organisations avec les rôles de la matrice, avant le scénario de révocation. Les sites et menus changeaient avec le contexte ; les libellés Responsable pédagogique sont toutefois erronés (task24).

**État final important : USER02→Horizon reste révoqué.** Sa restauration par réinvitation échoue409 (task25). USER02 conserve Azur, Provence et Ambulancier. Les trois autres propriétaires conservent leurs quatre appartenances. Le tableau appartenances.csv donne l’état final des26 relations inventoriées, y compris le compte préexistant non touché :25actives,1révoquée. Ne pas confondre état obtenu avant révocation et état final.

### Données préparées pour les prestations

Horizon : programme HORIZ-ECSR-QA existant,140h techniques fictives, manager QA Responsable Horizon V22 affecté puis relu après reload. Nouvelle promotion QA V22 Horizon 20261108, active du01/11/2026 au31/12/2026, effectif prévu3, version CCP1+CCP2. ID cohorte14944c1e-4d8f-429b-aa84-591b4e224387. Le Formateur QA a une affectation de cohorte ; chacun des trois Stagiaires a son affectation et sa première connexion.

Le Formateur ne peut pas créer sa séance. Une **séance distincte créée par USER01 administrateur** permet une couverture indépendante des présences : QA V22 Confirmation 2h Admin,08/11/2026,08:00–10:00 locales, IDf68c75c7-8a14-44d4-94ce-2f0dfad2e06f. Elle persiste dans Séances, Planning et Présences. Cette préparation ne corrige pas le FAIL du Formateur.

Trois présences Present ont été enregistrées et rechargées. Les trois brouillons consultés par UI indiquent chacun120min réalisées,0manquée : **3×120min =6h réalisées**. Les envois individuels puis collectif sont refusés409, les trois demandes restent Draft et chaque Stagiaire voit0demande envoyée. **Aucune confirmation A, attente B au statut Pending, contestation C ni total2h/4h n’est validé.** Aucun acquis de compétence lié à une signature n’est affirmé.

## C. Rapport de sécurité et AuthGate

- Stagiaire et Jury : accès directs /acces et /administration refusés/redirigés. Cependant le Stagiaire reçoit un formulaire de création de séance actif (task22) ; aucune sauvegarde interdite n’a réussi.
- A ne peut pas lire le brouillon d’émargement B : GETcontent403 req6267, aucun contenu B exposé. Les demandes Pending n’étant pas créées, la confidentialité de ce second état reste bloquée.
- Formateur Med, membre Ambulancier seulement : accès direct au dossier valide Horizon A refusé404 req7193, aucune identité ou donnée Horizon affichée. Le squelette vide et le message générique restent une limite UX, ajoutée au ticket historique13 ; son ancien contexte ECF/AFTRAL n’est pas rejoué.
- USER02 secondaire Horizon suspendu puis retiré : après nouvelle connexion Horizon absent, trois autres espaces accessibles, Azur propriétaire utilisable. Il s’agit de tests après reconnexion ; pas de preuve sur un ancien JWT maintenu.
- Le seul accès du nouveau Formateur Med a été suspendu : identification refusée avec Application membership is inactive, sans espace de secours. USER04 l’a ensuite réactivé et une connexion réelle a réussi.
- Aucun test à deux/trois sessions simultanées n’est validé : contrainte onglet1 unique et aucun nouveau contexte de navigateur disponible. SEC-REPRISE-021/024/025/026/027/029 sont BLOCKED. Aucun contournement par copie de cookies/JWT.
- Racine AuthGate HTTP404 : aucune interface de révocation administrative autorisée identifiée. Les API de connexion AuthGate utilisées par l’application fonctionnent ; le404 racine ne prouve pas une panne du fournisseur.
- Aucun500 inattendu n’a été vu dans les requêtes de connexion/navigation inspectées, mais403 sur des préchargements administratifs et sur le parcours Formateur sont observés. Aucun constat UI ne prouve la disparition d’OperationCanceledException, la version exacte déployée ou la performance de MembershipState.
- Pas de panne AuthGate provoquée. Pas d’incident réel de latence AuthGate isolé. Les délais d’attente d’outil dus à une option de select non visible ou à un texte absent ne sont pas des incidents backend.
- Expiration naturelle et boucles SignalR après expiration non vérifiées. Aucune mesure de charge ni test d’intrusion.

## D. Anomalies du lot

**Huit nouvelles anomalies valides ouvertes : quatreP1 et quatreP2.** Les liens vers captures et reproductions complètes figurent dans registre-anomalies-v22.md.

| Ticket | Gravité | Défaut |
|---|---|---|
| task19 | P2 | Accueil Formateur avec date fixe et cinq séances fictives ; accueil Stagiaire avec échéance hors contexte |
| task20 | P2 | Préchargements administratifs403 et alertes parasites chez les profils restreints |
| task22 | P1 | Formulaire et commande de création de séance exposés au Stagiaire |
| task23 | P2 | Espace Jury sans examen entièrement vide |
| task24 | P2 | Responsable pédagogique présenté comme Trainer après sélection d’espace |
| task25 | P1 | Réinvitation après révocation refusée409 : restauration UI impossible |
| task26 | P1 | Formateur actif affecté : liste Formateur vide, création de séance impossible |
| task27 | P1 | Demandes individuelles et collectives409, restent Draft malgré présences valides |

Task18 a été retesté : responsable de promotion manquant toujours silencieux, STILL FAILING ; une création complète avec le nouveau responsable a néanmoins réussi. Task13 a reçu la nouvelle preuve404 sans fuite, sans clôture globale sur son ancien contexte.

**Task21 est INVALID, pas FIXED.** Un verdict prématuré a confondu l’état transitoire Invitation sent avec l’état final ; le snapshot de relecture montrait Active access. Ticket et étape ont été corrigés immédiatement. Il est exclu des huit nouvelles anomalies et de tout bilan de corrections.

Aucune fuite inter-tenant ni sauvegarde serveur interdite n’a été démontrée. Cela n’est pas une certification de sécurité : les contrôles indispensables sur ancien JWT restent bloqués.

## E. Traçabilité, limites et reprise

Tests réutilisés :1,2,3,5,9,10,14,26,27,28,31. Nouveaux tests :40–43 uniquement pour les lacunes identifiées après recherche. Runs60–81 conservés ; run63 est un enregistrement en doublon du run62, sans exécution distincte ni augmentation de couverture. Les statuts automatiques passing de certains derniers runs ciblés avec skip ne clôturent pas les défauts observés dans des runs précédents.

Les références détaillées du DOCX, préconditions, attendus, observés, verdicts, tests et tickets sont présents dans resultats-sections31-32.md et suivi-global-v22.md/CSV/JSON. Les anciens rapports et verdicts ne sont pas écrasés. Les exports CC incluent les historiques ; les secrets sont masqués. Les preuves comprennent des captures PNG et des snapshots DOM. Aucun PASS de disposition visuelle globale n’est déclaré.

Poursuite requise :
1. Corriger puis retester task22/25/26/27 ; restaurer la relation secondaire USER02→Horizon via une voie UI corrigée, en conservant ses autres accès.
2. Fournir une capacité autorisée de sessions simultanées pour les scénarios d’ancien JWT et de changement de rôle ; identifier l’interface administrative AuthGate si elle existe.
3. Rejouer les demandes d’émargement puis confirmer A, laisser B Pending, contester C, contrôler6h/2h/4h et l’invalidation après modification.
4. Compléter les rôles par affectation métier, les programmes/cohortes des autres centres, les parcours Jury/Tuteur et les scénarios encore non exécutés ; observer une expiration naturelle dans une session dédiée.
5. Relire les contrôles de route sans contexte et les critères de bilan intégraux avant de clôturer les sections31–32, puis poursuivre les autres campagnes.

**NO GO : anomaliesP1 ouvertes et parcours essentiels non validés. Ce document est un checkpoint de reprise, pas une recette terminée.**
