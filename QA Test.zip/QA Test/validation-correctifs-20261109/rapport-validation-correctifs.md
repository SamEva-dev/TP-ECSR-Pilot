# PedagoraPilot — validation des correctifs, 9 novembre 2026

**NO GO pour ce lot de correctifs.** Les quatre défauts initiaux sont corrigés dans leurs conditions de reproduction. Le scénario P1-01 reste toutefois en échec sur son cas négatif : un Formateur sans affectation peut créer une séance. Le parcours sans e-mail échoue dans le Centre de signatures des Stagiaires, et un incident503 intermittent a perturbé une contestation.

La création, la sauvegarde des présences et la clôture par un Formateur sont réellement démontrées dans Horizon et Azur. Les réponses individuelles A/B/C et les calculs6h/2h/4h ont été vérifiés. Ces résultats n’autorisent pas un GO de l’ensemble du produit.

## 1. Périmètre, méthode et référence

Staging exclusivement : https://pedagora.staging.locaguest.com. NavigateurChrome, unique onglet existantpage1 ; aucune nouvelle page, aucun appelAPI manuel, aucune modificationSQL/JWT ou code applicatif. Toutes les mutations métier ont été faites par les contrôlesUI. Quelques lecturesDOM ont confirmé la cible d’un clic ; les réponses réseau des requêtes émises par l’écran ont servi à contrôler les calculs. Aucun secret n’est exporté.

Référentiel : `../PedagoraPilotCahierRecetteQA.docx`,865IDs v2.2, et registres du8novembre dans `../reprise-v22-20261108-soir`. `QA Test(2).zip` n’a pas été retrouvé dans le workspace ; les rapports et exports durables locaux ont servi à retrouver les étapes initiales. L’application étant déjà accessible en staging, aucun service local n’a été démarré. Angular22 confirmé dans le projet ; la présence de code local ne constitue pas une preuve de déploiement. Les verdicts reposent sur le comportement du staging.

Les comptes et données existants ont été réutilisés. Les quatre administrateurs ont été reconnectés sans changement de mot de passe ni réinscription. Les seules préparations supplémentaires sont le programme/cohorteAzur et les affectations nécessaires au second parcours.

## 2. Retest des quatre tickets

| Ticket | Scénario et contexte | Résultat observé et preuve | Verdict |
|---|---|---|---|
| task26 | P1-01 positif, Formateurs affectés Horizon etAzur | Création propre2h, sauvegarde/reload et menus concernés. [trainer-session-persisted](preuves/trainer-session-persisted.png), [azur-trainer-session-persisted](preuves/azur-trainer-session-persisted.png) | **FIXED** pour listevide/création affectée |
| task27 | P1-02, Formateurs Horizon/Azur ; ancien batchAdminHorizon | Complete session200, clôture persistante, demandesindividuellesPending ; ancien batchégalement200. [horizon-new-three-pending](preuves/horizon-new-three-pending.png), [azur-three-pending-persisted](preuves/azur-three-pending-persisted.png) | **FIXED** pour409 aprèsclôture effective |
| task25 | P1-03, USER01→USER02Horizon, puis USER04→USER03Med | Réinvitation d’appartenance révoquée Active unique, connexion habituelle, autres espaces préservés. [user2-restored-four-spaces](preuves/user2-restored-four-spaces.png), [nr-user3-four-spaces-restored](preuves/nr-user3-four-spaces-restored.png) | **FIXED** |
| task22 | P1-04, StagiaireA seulTrainee Horizon/Azur | /seances menu puis URLdirecte/reload : formulaire/action création, modification etclôture absents. [student-direct-sessions-corrected](preuves/student-direct-sessions-corrected.png), [azur-student-session-isolation](preuves/azur-student-session-isolation.png) | **FIXED** dans /seances |

Le contrôle négatif de P1-01 est **FAIL task29**, distinct du défaut initial task26. USER02Horizon a zéro affectation, mais peut créer `QA P1 Non affecté20261109`,09/11 08–12h. Cette séance QA est conservée comme preuve, sans présence ni confirmation. Aucune exposition à une organisation non autorisée n’est démontrée.

Le refus avant clôture a aussi été exécuté : request409 sur la nouvelle séance Horizon, puis succès après Complete session. Ce409 est attendu ; son corps n’était plus disponible au moment de la lecture. Aucune assertion du code d’erreur exact n’est faite sur cette requête.

## 3. Parcours réalisé et heures

### Horizon — séance créée par le Formateur

`QA P1 20261109 Horizon 2h`,09/11/2026 06:00–08:00 heure de Paris, session`09750d4f-7592-4724-913a-14536388925a`, promotion`QA V22 Horizon20261108`.

Le Formateur crée sa séance, retrouve Planning et Présences, enregistre troisPresent120min, actualise, tente un envoi avantclôture (refusattendu), clôture explicitement puis envoie les trois demandes. Trois connexionsStagiaires distinctes et séquentielles répondent depuis leurs propres URLUI connues. Les centres de signatures restent vides : cette alternative ne valide pas le parcours normal sans e-mail.

| Stagiaire | Réalisées | Confirmées | Non confirmées | État final |
|---|---:|---:|---:|---|
| A |2h|2h|0h|Acknowledged|
| B |2h|0h|2h|Viewed, sans réponse|
| C |2h|0h|2h|Declined, commentairepersistant aprèsréessai|
| **Total** |**6h**|**2h**|**4h**|1confirmée /1sansréponse /1contestée|

C a initialement rencontré view503 etrespond503 `AUTHGATE_MEMBERSHIP_UNAVAILABLE`, puis a réussi au réessai sans modification de la prestation. Incidenttask32 conservé ; il ne prouve ni une exceptionbackend particulière ni une causalité avec le brouillon créé avantclôture.

Preuve des statuts visibles : [horizon-new-final-statuses](preuves/horizon-new-final-statuses.png). Preuve des calculs : [réponse de la lectureUI/hours](hours-horizon-final-response.txt),360/120/240min. Les cartes d’agrégats numériques ne sont pas rendues dans l’UI examinée : les chiffres sont validés dans la réponse réseau déclenchée par la page, **pas comme affichage visuel conforme**.

L’ancienne séanceAdmin du08/11 est conservée séparément. Elle a également été close par le Formateur, puis ses troisDraft envoyés enbatch parAdmin et réellement répondus A/B/C. Ne pas additionner ces deux séances pour le cas de référence. Le CentreAdmin final, My team records, contient6demandes pour ces deux séances : [final-admin-horizon-six-requests](preuves/final-admin-horizon-six-requests.png).

### Azur — répétition et correction

Programme`AZUR-MOTO-QA`,promotion`QA P1 Azur20261109`, FormateurUSER03 affecté, mêmes trois identitésStagiaires invitées et inscrites dans ce contexte autorisé. Séance`QA P1 20261109 Azur2h`,09/11 06–08h, session`0681a071-4076-40b4-95b7-15195f786212`.

Le Formateur a créé/clôturé/envoyé les trois demandes individuelles. Les présences ont d’abord été préparées parAdmin pendant l’analyse d’un fauxéchec de clic, puis leur sauvegarde par le vrai clicFormateur a été vérifiée. Avant correction, Aconfirmed/BViewed/CDeclined donnent également360/120/240min : [réponse observée](hours-azur-observed-response.txt).

Après cette preuve, la présenceA déjàconfirmée a été changéePresent→Absent, sauvegardée et rechargée. Version3 :240minréalisées,0confirmée. A a ensuite été rétabliPresent et sauvegardé : version4,360minréalisées,0confirmée,360enattente. Une nouvelle demandeA a été envoyée et StagiaireA l’a réellement ouverte : Viewed avec commandes deréponse. L’ancienne URL garde sa tracehistoriqueAcknowledged, mais cette confirmation n’est plus comptée pour la versioncourante.

| Point de contrôle Azur | Réalisées | Confirmées | Non confirmées |
|---|---:|---:|---:|
| Avant correction, casA/B/C |6h|2h|4h|
| Version3, Aabsent |4h|0h|4h|
| État conservé version4, ArestauréPresent, nouvelle confirmationrequise |6h|0h|6h|

Preuves : [azur-correction-persisted](preuves/azur-correction-persisted.png), [azur-a-new-confirmation-required](preuves/azur-a-new-confirmation-required.png), [résuméversion4](hours-azur-final-new-version-response.txt). Les anciennes réponsesB/C de version2 ne sont pas comptées pour version4 ; aucune réponse n’a été simulée pour restaurer artificiellement les totaux.

## 4. Anomalies

| Ticket | Gravité | Situation | Impact |
|---|---|---|---|
| task29 |P1|Formateur zéroaffectation crée dans la promotionHorizon|Restriction d’affectation non appliquée|
| task30 |P1|Demandes envoyées absentes du CentreStagiaire, contenu propre accessible parURLconnue|Parcours normal sans e-mail inutilisable|
| task31 |P1|Attendance d’une séance ouvre une autre feuille ; varianteStagiaire renvoieàAccueil|Mauvaise séance ciblée, risque de saisieerronée|
| task32 |P2|Deux503 MembershipState lors de la lecture/réponseC, réessai réussi|Fiabilité intermittente de la confirmation|
| task33 |P3|Add to schedule visible chezStagiaire, retour silencieuxPlanning|Commande trompeuse ; aucune création nonautorisée|
| task19 |P2, toujoursprésent|Date21septembre/5séances fictives à l’accueilFormateur|Données de tableau de bord trompeuses|
| task20 |P2, toujoursprésent|Préchargements administratifs403 chezTrainer/Trainee|Alertes parasites et panneau qui recouvre les contrôles|
| task24 |P2, toujoursprésent|Responsablepédagogique affichéTrainer|Libellé de rôle incohérent, création effective autorisée|

Les reproductions, URL, rôles, résultats attendus/observés et captures figurent dans [le registre détaillé](registre-anomalies.md) et [les exportsCC](cc-tasks-correctifs.json). Cinq nouveaux défauts réels ont été créés après recherche de doublons ; les trois anciens ont été réutilisés. AucunP0 démontré.

**Erratumtask28 — INVALID.** Le panneau de notifications auto-ouvert recouvrait le centre du boutonSave. Le clicphysiqueMCP activait une notification menantàAccueil. Le diagnostic a été vérifié par capture et elementFromPoint. Escape ferme le panneau ; le vrai clicSave fonctionne et persiste dans les deux centres. Les anciensFAIL de sauvegarde ne sont pas retenus comme bugs applicatifs ; task28 ne doit être compté ni ouvert, ni comme correctif livré. [Preuve de l’occlusion](preuves/azur-save-scrolled-visible.png), [vraie sauvegarde](preuves/azur-trainer-save-pointer-success.png).

## 5. Non-régression, blocages et limites

Les créationsAdmin etResponsable, chargementTrainer, Planning, lectureStagiaire, reconnexions et refus de la demande d’un autreStagiaire ont été exécutés. Révocation secondaireUSER03Med : disparition de l’espace à la nouvelleconnexion, trois autres espaces proposés etAzur ouvert ; réinvitationMed rétablit les quatreespaces. USER02Horizon est aussi restauré. Aucun propriétaire ni donnée métier préexistante supprimé.

Quatre contrôles restentBLOCKED :
- E2E-09 : aucun acquis de compétence réel disponible dans le référentielQA ; pas de preuve complète de nonacquisitionautomatique. **SEC-REPRISE-035 resteBLOCKED**, malgré ses totaux conformes.
- NR-06 : éditiontitre/date/horaires d’une séance non exposée dans l’UI examinée.
- NR-12 : ancienJWT maintenu dans une session pendant révocation depuis une deuxième session impossible sous la contrainteongletunique ; aucune manipulation deJWT.
- NR-14 : pas de commutateurdelangueutilisateur trouvé ; ENobservé, FRnonvérifié. La préférenceorganisationFR ne suffit pas comme preuve de libelléFR.

Les503 réellementobservés sont archivés ; aucune interruptionAuthGate n’a été provoquée. Aucun testdecharge, forcebrute ou intrusion. Aucun email livré déclaré : le bypassstaging a été exercé par les demandes et réponses UI. Les captures ne contiennent ni mot de passe, cookie, JWT ou lien d’invitation.

## 6. Chiffres et traçabilité

| Mesure du lot ciblé | Nombre |
|---|---:|
| Contrôles identifiés |37|
| Exécutés avec résultat réel |33|
| PASS |25|
| FAIL, y compris intermittent |8|
| BLOCKED |4|
| NOT APPLICABLE |0|
| Non commencés dans ce lot |0|
| Taux de réussite sur exécutés |25/33 =75,76%|

Ces37contrôles sont une décomposition explicite du promptcorrectifs, **pas37IDs nouveaux du DOCX**. Les itérationsHorizon/Azur ne sont pas comptées comme nouveaux cas quand elles répètent le même contrôle. Les résultats détaillés attendus/observés de chaquecontrôle sont dans [resultats-detail.md](resultats-detail.md) et [CSV](resultats.csv).

Huit tests durables utilisés : sept réutilisés(test9,10,14,27,40,41,43) et untestmanquant créé(test44navigation). Dix-sept runs82–98 clos. Un runentièrementSKIP(run95) est automatiquement«passing» parCC : il est comptéBLOCKEDici. Les cartesCC reflètent parfois les résultatsactuelsdesétapes plutôt qu’une itération complète ; les historiquesrun et le registre de ce lot font foi. Aucun doublonde couverture recréé.

Le cahierglobal865scénarios n’a pas été intégralement rejoué. La copie de suivi [campagne-globale-conservee.json](campagne-globale-conservee.json) conserve les verdicts historiques et n’actualise que sixIDs précisément tracés, dont SEC036 etSEC038 désormaisPASS ; les autres résultats sont marquéshistoriques, pas preuvesactuelles. Les comparaisons complètes de tous les rôles/Jury n’ont pas été reprises. Aucune annonce de recetteexhaustive.

## 7. État conservé et suite

Les deux nouvelles séancesde référence, les séancesde nonrégressionAdmin/Responsable, la séance négative du Formateur nonaffecté, les promotions, programmes et appartenances sont conservés. Horizon09/11 reste6/2/4 ; Azurversion4 reste6/0/6 pour vérifier la nouvelle confirmationrequise. Ne pas les remettre artificiellement à un étatPASS.

Priorité de correction : task29 ettask30, puis task31 etanalyse de task32. Reprendre ensuite le parcours normalStagiaire depuis son espace, sans URLcopiée, et les quatrecontrôles bloqués avec leurs préconditions réelles. La plateforme entière n’est pas qualifiée par ce lot.

État navigateur final : USER01 connecté propriétaireHorizon, contexteHorizon/Nice/ECSR/promotionQA, Signaturecenter/My team records, deuxjeux de trois réponses. Aucun accès restauré n’est laissé révoqué.
