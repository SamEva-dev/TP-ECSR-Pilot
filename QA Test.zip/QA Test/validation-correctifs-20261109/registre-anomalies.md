# Registre du lot correctifs

Cinq nouveaux défauts réels : task29/30/31 P1,task32 P2,task33 P3. Task28 est INVALID, non compté comme bug ou correctif. AucunP0 démontré. Les causes backend ne sont pas inférées d’un seul statutHTTP.

## task-19 — P2 — Accueil Formateur : date fixe et cinq séances fictives sans affectation

Statut CC : todo.

SEC-REPRISE-004, INV-REPRISE-011. Staging08/11/2026 20:34UTC. Nouveau Formateur qa.v22.20261108t2034.formateur.horizon@example.com, Centre Horizon ECSR/HORIZ-QA-01/programmeECSR sans promotion ni affectation. Se connecter, ouvrir /accueil puis recharger : Monday 21 September 2026 · 5 sessions today malgré date08/11 et sections My sessions today/My students vides. Attendu : date courante et compteur réel ou absence de données. Test40 étape97 FAIL, trainer-home-errors.png et trainer-home-reloaded.png. Donnée trompeuse de tableau de bord ; pas une fuite démontrée.

Même défaut de contenu de démonstration observé chez nouveau StagiaireA : accueil TP ECSR2026–2027 · scheduled end30/06/2027 alors que contexte réel QA V22 Horizon20261108 finit31/12/2026. Capture student-context. Extension même famille accueil non contextualisé ; pas de nouveau doublon.

Retest09/11USER03TrainerAzuraffectéavec1séanceQA2hréellementcrééeaujourd’hui : accueilresteMonday21September2026·5sessions today,My sessions todayvide,mêmeaprèsreload. test40/run98étape97FAIL,nr-trainer-static-home-current/nr-trainer-home-reload-errors. Toujoursprésent, pasnouveaudoublon.

Tests liés : test-40.

## task-20 — P2 — Connexion Formateur : préchargements administratifs interdits et alertes parasites

Statut CC : todo.

SEC-REPRISE-004 / SEC-REPRISE-028. Nouveau Formateur qa.v22.20261108t2034.formateur.horizon@example.com, Horizon sans affectation. Login puis /accueil, reload : alertes Could not load programs, Some workspace data could not be loaded, Unable to load frameworks. Requêtes UI GET /api/v1/referentials403 req574/585, /programs403 req586, /reporting/audit403 req587, dashboards403 req588/589. Attendu : chargement adapté aux droits, aucun appel administratif ni alerte d'indisponibilité pour un refus attendu. Menus administratifs masqués ; aucune autorisation serveur contournée démontrée. Test40 étape98 FAIL, captures trainer-home-errors/reloaded. Aucune affirmation sur exception backend.

Nouveau StagiaireA affecté promotion : alertes Unable to load students / Could not load programs / Some workspace data / Unable to load frameworks également présentes après connexion. student-context. Refus attendus403 préchargés malgré rôle restreint ; étendre correction au Stagiaire et Responsable.

Observation incidente09/11 pendant retestP1 : créationFormateur fonctionne désormais (task26), mais alerte Some workspace data could not be loaded reste affichée avec referentials/programs/audit/dashboards403 (req280–284). trainer-session-persisted et net-trainer-create. Même défaut de préchargement existant, aucun nouveau doublon créé ; hors des4P1 ciblés.

09/11 toujoursobservé : préchargements 403/programs,/referentials,/reporting pourTrainer/TraineeHorizon/Azur,fontSome workspace data could not be loaded etpopoverautoouvert. Consoledernièreitérationplusieurs403 ; métierSessionslecture200. PopoverpeutrecouvrirSave,Escapeferme ; nepasconfondreavecfauxbugSave(task28INVALID). Preuvestrainer-session-persisted/azur-trainer-session-persisted,console-final.

Tests liés : test-40.

## task-22 — P1 — Stagiaire : formulaire de création de séance et commande active exposés

Statut CC : done.

INV-REPRISE-018 / SEC-REPRISE-007,08/11/2026 vers20:40UTC. StagiaireA qa.v22.20261108t2034.stagiairea.horizon@example.com, Horizon/Nice/ECSR/QA V22 Horizon20261108, rôleTrainee. Ouvrir /seances : formulaire New teaching session complet, Create session actif, cohorte propre sélectionnée. Saisir Topic et cliquer : No active trainer selected. Assign a trainer before creating the session. Attendu : aucun formulaire de création réservé formateur/direction pour ce rôle, accès lecture seulement. Observé action interdite exposée et validation métier accessible. Aucune sauvegarde non autorisée démontrée (listeformateursvide). GravitéP1 sécurité fonctionnelle UI, pas fuite inter-tenant ni contournement serveur prouvé. test41 étapes101/102 FAIL, student-sessions.png / student-create-forbidden.png.

Mappingprécis : INV-REPRISE-018 (URLadministration) effectivementrefusé etdoitêtrePASSdansleregistre. LeformulairecréationSéancesexposéauStagiaire relève deINV-REPRISE-019/SEC-REPRISE-007 ettest41run66 ; nepasforcerFAILdelaprotection/acces qui fonctionne.

Retest09/11/2026 P1-04 FIXED. StagiaireA Trainee seul Horizon : accès réel menu Sessions puis URL directe /seances et chargement final. Séances visibles limitées à sa présence ; aucun formulaire ni bouton création, modification ou Complete session. test41/run85 étapes101/102 PASS ; student-direct-sessions-corrected.png et student-context-confirmed.png. Aucune permission serveur hors UI supposée.

Tests liés : test-41.

## task-24 — P2 — Rôle Responsable pédagogique affiché Trainer après sélection d’organisation

Statut CC : todo.

INV-REPRISE-022 / SEC-REPRISE-016. 08/11/2026. USER01 est Educational manager dans Azur, confirmé ligne /acces source et chooser Responsable pédagogique ; après sélection sidebar sous Sam Horizon QA affiche Trainer. Reproduit USER03 dans Ambulancier : chooser Responsable pédagogique puis sidebarTrainer, alors que menus manager (Cohorts/Reports) restent présents. Attendu : libellé rôle local exact. Captures user1-in-azure, user3-in-med, cross-2-1 et cross-4-3. Test28 étape59FAIL. Aucun gain de permission serveur ni rôle écrasé démontré ; erreur de représentation du rôle.

09/11NR : QA ResponsableHorizonseconnecte,créevraimentQA NR ResponsableHorizon20261109,maisroleSidebarTrainerresteaffiché. Défautdelibelléconservé ; permissionscréation effectivevalidéesrun93. nr-manager-session-persisted.png.

Tests liés : test-28.

## task-25 — P1 — Accès révoqué : réinvitation refusée409, restauration UI impossible

Statut CC : done.

SEC-REPRISE-022/038, INV-REPRISE-026. USER01 administrateur Horizon ; USER02 possède une appartenance secondaire Trainer Horizon créée dans ce lot, sans affectation.
Reproduction : suspendre USER02 dans /acces ; vérifier sa nouvelle connexion sans Horizon ; retirer cette seule appartenance et confirmer. Après actualisation, USER02 est absent de la liste Horizon et conserve ses trois autres espaces. Pour restaurer l’état initial, réinviter sam.user2@email.com avec le rôle Trainer.
Attendu : réactivation ou réinvitation maîtrisée de l’appartenance révoquée, sans nouvelle identité.
Observé : POST /api/v1/access/invite HTTP409 (req5455), notification Unable to send this invitation. La ligne retirée n’est plus disponible pour Activate ; aucune autre voie UI de restauration identifiée.
Preuves : user2-revoked-spaces.png, user2-restore-error.png ; test27/run71 étape56 FAIL. Tous les propriétaires restent actifs. Seule la relation secondaire USER02→Horizon reste révoquée à la fin du lot. Distinct du refus d’auto-invitation historique : les douze invitations initiales avaient réussi.

Retest09/11/2026 FIXED : appartenance Horizon révoquée restaurée par réinvitation200 req723 au rôleTrainer, unique etActive aprèsreload ; USER02 se reconnecte avec ses identifiants habituels et retrouve4espaces avec les3autresrôlesinchangés. test27/run84 étape56PASS, preuves restored-user2-persisted,user2-restored-four-spaces,user2-restored-horizon-context. Contrôle de limites du Formateur sans affectation traité séparément.

Nonrégression09/11dans2eorganisation : USER04MedretireUSER03Educationalmanager0affectation ; loginUSER03propose3autresespaces etAzurfonctionne. RéinvitationMedEducationalmanagerActive,persistancereloadpuisUSER03mêmepasslogin4espacesetMedouvert. test27/run94 étapes144–146PASS. Aucunpropriétaireretiré,donnéespréservées.

Tests liés : test-27.

## task-26 — P1 — Formateur actif affecté à une cohorte : liste Formateur vide, séance impossible

Statut CC : done.

SEC-REPRISE-034, INV-REPRISE-030. Nouveau QA Formateur Horizon V22, actif et affecté à la cohorte QA V22 Horizon 20261108, sous Horizon / Nice / ECSR ; trois Stagiaires actifs.
Reproduction : reconnecter ce Formateur ; ouvrir /seances ; sélectionner sa cohorte ; saisir 08/11/2026,08:00–10:00 et sujet QA V22 Confirmation 2h ; cliquer Create session.
Attendu : le Formateur propre est disponible et peut créer une séance dans sa cohorte.
Observé : liste Trainer vide, alerte Unable to load sessions puis No active trainer selected. Assign a trainer before creating the session. Aucune séance enregistrée. L’administrateur voit ce même Formateur dans la liste et a créé une séance distincte, ce qui confirme que son identité existe.
Preuves : trainer-cohort-assignment.png, trainer-assigned-context.png, trainer-create-blocked.png ; test43/run72 étape120 FAIL. Le parcours de confirmation initié par le Formateur est bloqué. Aucun appel API manuel ni JWT modifié.

Retest09/11/2026, FIXED pour le défaut initial : FormateurQA actif affecté voit sa promotion et sa propre identité ; création201 req243 d’une nouvelle séance2h, puis reload et présence dansPlanning/Présences avec3Stagiaires. test43/run82 étapes119–121 PASS ; trainer-create-filled,trainer-session-persisted,trainer-session-planning,trainer-session-attendance-initial. La limite du Formateur nonaffecté reste un contrôle de non-régression séparé, non présumé PASS.

Tests liés : test-43.

## task-27 — P1 — Demandes de confirmation : trois envois refusés409, restent Draft malgré présences valides

Statut CC : done.

SEC-REPRISE-034/035, INV-REPRISE-030. USER01 administrateur Horizon ; cohorte QA V22 Horizon 20261108 ; séance QA V22 Confirmation 2h Admin le08/11/2026 de08:00 à10:00 locales (07:00–09:00UTC), terminée lors du test ; trois Stagiaires actifs.
Reproduction : enregistrer Present pour A,B,C et actualiser ; cliquer individuellement Request acknowledgement pour chacun. Vérifier ensuite le Centre de signatures ; sélectionner les trois brouillons et Send selected drafts(3).
Attendu : demandes Pending accessibles à chaque Stagiaire sans consultation d’email en staging ; aucune confirmation automatique.
Observé : brouillons créés200 puis envois individuels409 (req6103/6110/6115), statut Requests queued for delivery:0 · Failures:1. Les trois demandes restent Draft ; envoi collectif POST /signatures/batch/request409 req6690. Les détails UI des trois brouillons indiquent Present,120min réalisées,0manquée. Chaque Stagiaire se connecte mais son centre contient0demande envoyée.
Preuves : attendance-three-present.png, attendance-requests-sent.png, attendance-bulk-final.png, student-a-drafts.png, student-b-no-pending.png, student-c-no-pending.png ; test43/run74 étape123 FAIL et run78 étape135 FAIL. 6h réalisées vérifiées manuellement ; 2h confirmées/4h non confirmées non validées.

Envoi collectif aussi vérifié : CentreSignatures sélectionner3Draft puis Sendselecteddrafts(3), POST/signatures/batch/request409 req6690 ; 3Draft etPending0 persistent. test43run78étape135FAIL, attendance-bulk-final.png. Mêmeissue, pasdedoublon.

09/11 retestpartiel positif : nouvelle action Complete session permetclôture explicite par Formateur surancienne séancef68... ; POSTcomplete200req545,persistancereload. Adminrenvoie3Draft enbatch200req1220,3Pendingpersistants. Aconfirmé,Ccontesté120minréelsparURLconnue ; pasde409aprèsclôture. EnvoiindividuelFormateur surséancenouvelle restebloqué task28, routageprésences erroné ; task30 centreStagiairevide empêcheparcourssansemail. Ticket laisséouvert jusqu’àvalidationcomplèteP1-02, nepasassimilerheurepasséeàclôture.

P1-02 FIXED pour défaut 409aprèsclôture :09/11dansAzur, USER03Formateuraffecté crée0681a071-4076-40b4-95b7-15195f78621206–08h. Adminprépare3présences120minpersistantes(carSaveFormateurFAILtask28). FormateurComplete sessionPOST200req3032,reloadpuisenvoisindividuelsA/B/C réussissentqueued1failure0,3Pendingpersistantsaprèsreload. test43/run89étapes123/141PASS,azur-three-pending-persisted.png. AncienbatchHorizonégalementréussi. ParcoursglobalresteNO GOtask28/30/31 ; négatifavantclôturenonvalidé.

ConfirmationfinaleHorizon09/11 : vraieSaveFormateur, négatifavantclôture/request409req4010attendu ; aprèsComplete200les3envoisindividuelsPendingpersistants. Aconfirmé,BViewed,CDeclined(aprèsretry503task32). GET/hourssession09750...360/120/240. DoncFIXEDdéfaut 409surclôture effective,niGOglobalniabsence503affirmés. horizon-new-three-pending/horizon-new-final-statuses.

Tests liés : test-43.

## task-28 — INVALID — Save attendance : clic QA intercepté par le panneau de notifications

Statut CC : done.

Fausse alerte QA invalidée09/11/2026. Le panneau de notifications auto-ouvert sur préchargements 403 recouvrait le centre de Save attendance ; le clic physique MCP atteignait une notification menant à /accueil. Aucun handlerSave ni appel de sauvegarde n’était exécuté lors de ces essais. Diagnostic confirmé par screenshot azur-save-scrolled-visible et document.elementFromPoint. Escape ferme le panneau ; vrai clicSave par Formateur exécutePUT200, trois présences persistent aprèsreload dansHorizon etAzur. Activation DOM du mêmecontrôleUI a aussi exécutéPUT200, sansappelAPImanuel. Preuves azur-trainer-save-pointer-success.png,horizon-real-save-persisted.png. test43/run82étape122corrigéeSKIP(erratum),run89/90étape122PASS. Ne pas compter comme anomalie réelle ou correctif déployé.

Reproduitdans2eorganisationAzuravecUSER03TraineraffectéQA P1Azur : séanceQA P1 20261109 Azur2h06–08hcréée/persistée,3Studentsactifs ; Present3puisSave→accueil ; retour0présent. test43/run89 étape122FAIL,azur-trainer-save-attendance-result.png/azur-save-not-persisted.png. DéfautnonlimitéàHorizon.

Diagnosticcorrigé09/11 : captureazur-save-scrolled-visible montrepopovernotificationscouvrantcentreSave(x1132,y136). ClicMCPUIDphysiqueaactivélanotificationvers/accueil,paslehandlerSave. ActivationducontrôleUIréelparDOM.clickdéclenchePUTattendance200req3779, modificationpersistée ; pasdedéfautsauvegardedémontré. Retestpanneau ferméen cours, nepascomptertask28commebugouFIXEDdéployé. Anciennespreuvesdocumententinterceptiond’outil, pasrejetapp. AucunAPIappelmanuel.

INVALID confirmé : Escapefermelepanneaunotification, elementFromPointcentreSaveestbienSavepuisclicChromeUIDenregistreavecFormateur ; reloadconserve3Present. azur-trainer-save-pointer-success.png. LesverdictsFAILsauvegarde initiauxsontfaussesalertesinterceptionQA ; run89étape122corrigéePASS. Conserverhistorique, nepascomptercommebugréel.

Tests liés : test-43.

## task-29 — P1 — Formateur sans affectation : création autorisée dans la promotion Horizon

Statut CC : todo.

09/11/2026, P1-01 négatif. USER02 sam.user2@email.com restauré Trainer dans Horizon, 0 affectation vérifiée dans Accès. Se connecter avec USER02, choisir Centre Horizon ECSR, ouvrir /seances : cohorte QA V22 Horizon 20261108 proposée. Saisir Topic QA P1 Non affecté 20261109, laisser 09/11 08–12h et soi-même Trainer, cliquer Create session. Création réussie, séance persistante après reload. Attendu : seules les promotions affectées autorisées doivent être proposées et aucune séance ne doit être créée par ce formateur non affecté. Observé : restriction d’affectation contournée via UI normale. Preuves unassigned-trainer-create-result.png / unassigned-session-persisted.png, test43/run83 étape142 FAIL. Pas de fuite inter-organisation démontrée ; membre légitime Horizon. Gravité P1 fonctionnelle permissions. Ne pas confondre task26 : formateur affecté peut désormais créer.



Tests liés : test-43.

## task-30 — P1 — Demande d’émargement Pending absente du Centre de signatures du destinataire

Statut CC : todo.

09/11/2026, Horizon, StagiaireA seul Trainee, promotion QA V22 Horizon20261108. Ancienne séance QA V22 Confirmation2h Admin explicitement close, trois demandes envoyées parAdmin (batch/request200 req1220) et Pending persistants aprèsreload. Connecter qa.v22.20261108t2034.stagiairea.horizon@example.com ; menu Signature center puis Refresh : 0requests, GET signatures/center200 req1329. Attendu : sa demandeA Pending doit être listée, sans e-mail en bypassstaging. Observé : liste vide ; pourtant URL connue /signatures/attendance/6e6138f0-a26d-4fe4-a979-e8388f9662ef charge sa prestation120min et commandes Acknowledge/Dispute, prouvant existence et droit. Preuves old-three-pending-persisted.png,student-a-after-pending-send.png,student-a-own-pending-direct.png ; test43/run83 étape124 FAIL pour découverte normale. Pas de refus403 de sa propre demande, pas de fuite démontrée. Contournement ponctuel de navigation possible avec référence connue, ne valide pas le parcours sans e-mail.

Reproduit également chezB etC : centres0requests après envoi réussi ; URL propre connue donneViewed120min. Alternative UI : A a réellementAcknowledged, C a réellementDeclined aveccommentaire, tousdeux persistants aprèsreload. B resteViewed sansréponse. Le défaut est la découvrabilité dans lecentre, pas le droit de répondre parURLconnue.

ReproduitAzuravec nouvellesdemandes crééesparFormateur,pasuniquementanciensbrouillonsAdmin. Acentre0req200req3287,maisURLpropre44e...réponseAcknowledgedpersistante ; BViewed9e...,CDeclinede3... . Centresaveuglesauxdemandesenvoyées ; adminglobalàvérifier. azur-student-a-center.png.

Tests liés : test-43.

## task-31 — P1 — Le lien Présences d’une séance ouvre une autre séance sans sélecteur

Statut CC : todo.

Horizon, promotion QA V22 Horizon20261108, AdminUSER01 ou FormateurQA. Sessions contient ancienne QA V22 Confirmation2h Admin08/11 08–10h et nouvelles09/11. Cliquer Attendance souslaancienne : /presences affiche09/11 08–12h pourAdmin, ou09/11 06–08h pourFormateur ; aucune sélection deséance visible. Attendu : feuille de la séance cliquée08/11 08–10h. Observé : remplacement silencieux paruneautre séance, bloquecontrôle6/2/4etcorrectiond’unémargementconfirmé, risque saisie mauvaisefeuille. Aucune mauvaiseécriture volontaire réalisée. Preuves admin-sessions-before-old-attendance.png,admin-old-attendance-wrong-session.png,old-session-attendance-routes-to-new.png. test44/run86 étape143FAIL. GravitéP1.

VarianteStudentAzur : carteQA P1 20261109Azur2h proposeAttendance, clicrenvoie/accueil (guard), pasdefeuilleconsultation. azur-student-a-attendance-requests.png. Pasdecontournementserveur, maisliennavigationinutilisable ; centrevide task30n’offreaucunealternativeUIpourretrouverdemande.

Tests liés : test-44.

## task-32 — P2 — Confirmation Stagiaire C : erreurs transitoires503 AUTHGATE_MEMBERSHIP_UNAVAILABLE

Statut CC : todo.

09/11/2026 vers08:13UTC, StagiaireC Horizon, séanceQA P1 20261109 Horizon2h, demande0a59fed0-e38e-4448-ad81-3c03a5eccb5a Pending. ConnexionréellepuisouvrirURLpropre, lire120min, saisircommentaireQA etDispute. GETcontent200, POSTview503req4512 etPOSTrespond503req4515,corps {code:AUTHGATE_MEMBERSHIP_UNAVAILABLE}, messagesUI Unable to record that you viewed… puisUnable to save your response, statutPending. Nouvelle tentativeDisputeultérieureaboutitDeclined, doncintermittent. Attendu : accèslégitime/réponseenregistréesouindisponibilitéexpliciteetrelance ; observéindisponibilitéfonctionnellede2opérationsmalgrélectureréussie. Aucunarrêtd’AuthGateprovoqué,aucuneexceptionbackenddéduite. Preuveshorizon-c-draft-before-close-response-failure.png,horizon-c-response-retry.png,réponsesréseau4512/4515sanitisées ; test43/run90étape126FAILinitial. P2fiabilité, pasdéfautdehash/clôturedémontré.

Réessaidu09/11sanschangementdonnée : DisputeCaboutitDeclined,commentairepersistentreload. Formateurreconnectévoittroisstatuts ; heures09750...360/120/240. L’incident503resteconsignépourfiabilité, pasdefaillepermissionniobsolescencehashdémontrée.

Tests liés : test-43.

## task-33 — P3 — Planning Stagiaire : lien Add to schedule actif mais retour silencieux

Statut CC : todo.

09/11/2026, StagiaireA,Trainee,Azur/Antibes/QA Moto/QA P1Azur. Ouvrir/planning : Add to schedule(href/planning/nouveau)visible. Cliquer : retour/planning,sansformulaireetaucunmessageexpliquantdroits. Attendu : masquercommandepersonnelourefusexplicitementexpliqué. Observé : commandetrompeuse/inutilisable. Preuvesazur-student-planning-isolation.png/student-planning-create-access.png,test41/run97 étape149FAIL. P3UXnonbloquant ; aucunepermissionserveurcontournée,aucunecréationnonautorisée. Distincttask22FIXEDmasquageformulaire/seances.



Tests liés : test-41.
