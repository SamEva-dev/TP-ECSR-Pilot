# Résultats détaillés — 9 novembre 2026

37 contrôles ciblés,33 exécutés (25PASS/8FAIL),4BLOCKED,0N/A. Ces IDs de lot ne sont pas37 nouveaux scénarios du cahier865. Les références exactes du cahier sont indiquées lorsque leur périmètre correspond ; un PASS partiel ne devient pas un PASS du scénario complet.

## DEP-01 — Accessibilité et données existantes — PASS

Référence cahier : Extension ciblée du prompt correctifs. Profil : Administrateurs USER01–04. Organisation : Horizon, Azur, Provence, Méditerranée.

Étapes réellement exécutées : Connexion réelle, sélection explicite du propriétaire et lecture des contextes existants.

Attendu : Staging accessible, comptes et organisations conservés.

Observé : Quatre identités existantes reconnectées ; Horizon conserve son programme, promotion et trois stagiaires ; sites des quatre centres retrouvés. Aucun démarrage local.

Traçabilité : test-43/run82:119. 

Preuves : [admin-existing-cohort](preuves/admin-existing-cohort.png), [admin-existing-context](preuves/admin-existing-context.png), [nr-revoke-med-context](preuves/nr-revoke-med-context.png)

## P1-01 — task26 — création par Formateur affecté — PASS

Référence cahier : SEC-REPRISE-034;INV-REPRISE-030. Profil : Formateur QA Horizon et USER03 Trainer Azur. Organisation : Horizon et Azur.

Étapes réellement exécutées : Choisir sa cohorte, son identité, titre/date/horaires 06–08h ; créer, actualiser et consulter Planning/Présences.

Attendu : Séance2h persistante dans la bonne promotion, identité propre sélectionnable.

Observé : Deux nouvelles séances créées par leurs formateurs, persistantes ; aucun Trainer vide. Défaut initial task26 FIXED.

Traçabilité : test-43/run82:120,121;run89:120. Ticket : task-26.

Preuves : [trainer-create-filled](preuves/trainer-create-filled.png), [trainer-session-persisted](preuves/trainer-session-persisted.png), [trainer-session-planning](preuves/trainer-session-planning.png), [azur-trainer-session-persisted](preuves/azur-trainer-session-persisted.png)

## P1-01-N — Formateur non affecté — FAIL

Référence cahier : Extension ciblée du prompt correctifs. Profil : USER02 Trainer sans affectation. Organisation : Horizon.

Étapes réellement exécutées : Vérifier zéro affectation dans Accès, reconnecter USER02 dans Horizon puis créer dans la promotion QA.

Attendu : Promotion hors affectation indisponible ou création refusée.

Observé : QA P1 Non affecté 20261109 enregistrée 08–12h et persistante malgré zéro affectation. Membre légitime Horizon : pas de fuite inter-tenant démontrée.

Traçabilité : test-43/run83:142. Ticket : task-29.

Preuves : [restored-user2-persisted](preuves/restored-user2-persisted.png), [unassigned-trainer-create-result](preuves/unassigned-trainer-create-result.png), [unassigned-session-persisted](preuves/unassigned-session-persisted.png)

## P1-02 — task27 — clôture puis demandes — PASS

Référence cahier : SEC-REPRISE-034. Profil : Formateurs affectés. Organisation : Horizon et Azur.

Étapes réellement exécutées : Enregistrer les présences, Complete session, actualiser, demander individuellement A/B/C et actualiser.

Attendu : Clôture persistante et demandes Pending sans erreur de séance non terminée.

Observé : Complete session200 et trois Pending persistants dans les deux centres. task27 FIXED pour le défaut 409 après clôture effective.

Traçabilité : test-43/run89:123,141;run90:123,141. Ticket : task-27.

Preuves : [horizon-new-completed-persisted](preuves/horizon-new-completed-persisted.png), [horizon-new-three-pending](preuves/horizon-new-three-pending.png), [azur-trainer-completed-persisted](preuves/azur-trainer-completed-persisted.png), [azur-three-pending-persisted](preuves/azur-three-pending-persisted.png)

## P1-02-N — Refus avant clôture — PASS

Référence cahier : Extension ciblée du prompt correctifs. Profil : Formateur QA Horizon. Organisation : Horizon.

Étapes réellement exécutées : Sur séance09/11 avec présences sauvées mais non close, demander C ; fermer ensuite la séance et renvoyer.

Attendu : Refus avant clôture, puis envoi possible après clôture.

Observé : Avant : Draft200 puis request409 req4010,0queued1failure. Après : même demande Pending. Corps4010 n’était plus disponible lors de sa lecture ; aucun code backend exact affirmé.

Traçabilité : test-43/run90:140. 

Preuves : [horizon-unfinished-request-refused](preuves/horizon-unfinished-request-refused.png), [horizon-new-three-pending](preuves/horizon-new-three-pending.png)

## P1-03 — task25 — réinvitation après révocation — PASS

Référence cahier : SEC-REPRISE-038. Profil : USER01 administrateur, USER02 invité. Organisation : Horizon.

Étapes réellement exécutées : Réinviter USER02 déjà révoqué comme Trainer ; vérifier ligne unique Active, recharger ; connexion réelle et sélection Horizon.

Attendu : Même identité et mot de passe habituel, rôle restauré, autres appartenances conservées.

Observé : Invitation200, unique USER02 Active Trainer ; quatre espaces avec rôles précédents, Horizon ouvert. Aucune organisation personnelle ajoutée. Identité identique déduite du compte existant et du login habituel, sans inspection interne AuthGate.

Traçabilité : test-27/run84:56. Ticket : task-25.

Preuves : [restored-user2-persisted](preuves/restored-user2-persisted.png), [user2-restored-four-spaces](preuves/user2-restored-four-spaces.png), [user2-restored-horizon-context](preuves/user2-restored-horizon-context.png)

## P1-04 — task22 — création masquée chez le Stagiaire — PASS

Référence cahier : SEC-REPRISE-007;INV-REPRISE-019. Profil : Stagiaire A Trainee seul. Organisation : Horizon et Azur.

Étapes réellement exécutées : Menu Séances, URL directe /seances et actualisation ; rechercher création, modification et clôture.

Attendu : Aucun formulaire ni commande réservée au personnel, séances autorisées consultables.

Observé : Formulaire et Create session absents ; aucun Complete session/Edit ; séances et compteur propres au Stagiaire. task22 FIXED dans son périmètre /seances.

Traçabilité : test-41/run85:101,102;run96:101,102. Ticket : task-22.

Preuves : [student-direct-sessions-corrected](preuves/student-direct-sessions-corrected.png), [student-context-confirmed](preuves/student-context-confirmed.png), [azur-student-session-isolation](preuves/azur-student-session-isolation.png)

## E2E-01 — Trois présences de120min — PASS

Référence cahier : SEC-REPRISE-034. Profil : Formateur affecté. Organisation : Horizon et Azur.

Étapes réellement exécutées : Sélectionner Present A/B/C ; fermer le panneau de notifications avec Escape ; Save attendance et actualisation.

Attendu : Trois présences et6h réalisées persistantes,0confirmation automatique.

Observé : Vrai clicSave fonctionne et persiste dans les deux centres. Les essais initiaux interceptés par une notification sont invalidés (task28), pas une panne applicative.

Traçabilité : test-43/run90:122;run89:122. 

Preuves : [horizon-real-save-persisted](preuves/horizon-real-save-persisted.png), [azur-trainer-save-pointer-success](preuves/azur-trainer-save-pointer-success.png)

## E2E-02 — Envoi collectif de brouillons existants — PASS

Référence cahier : SEC-REPRISE-034. Profil : Admin USER01 après clôture Formateur. Organisation : Horizon, ancienne séance08/11.

Étapes réellement exécutées : Sélectionner les trois Draft dans Signature center, Send selected drafts puis actualiser.

Attendu : Trois Pending, aucune confirmation automatique.

Observé : POST batch/request200 req1220 ; trois Pending persistants. Cette séance est distincte des séances09/11.

Traçabilité : test-43/run83:135. 

Preuves : [old-completed-batch-send-result](preuves/old-completed-batch-send-result.png), [old-three-pending-persisted](preuves/old-three-pending-persisted.png)

## E2E-03 — Découverte des demandes sans e-mail — FAIL

Référence cahier : INV-REPRISE-030;SEC-REPRISE-034. Profil : Stagiaires A/B/C. Organisation : Horizon et Azur.

Étapes réellement exécutées : Se reconnecter dans le bon centre, ouvrir Signature center et Refresh.

Attendu : Demandes propres accessibles depuis l’espace sans connaître leur URL.

Observé : Centres vides malgré Pending envoyés et content propre accessible par URL connue. Le parcours normal sans e-mail n’est pas validé.

Traçabilité : test-43/run83:124;run89:124;run90:124. Ticket : task-30.

Preuves : [student-a-after-pending-send](preuves/student-a-after-pending-send.png), [student-b-center-pending](preuves/student-b-center-pending.png), [student-c-center-empty](preuves/student-c-center-empty.png), [azur-student-a-center](preuves/azur-student-a-center.png), [horizon-new-student-a-center-empty](preuves/horizon-new-student-a-center-empty.png)

## E2E-04 — A confirme réellement — PASS

Référence cahier : SEC-REPRISE-035. Profil : Stagiaire A. Organisation : Horizon et Azur.

Étapes réellement exécutées : Ouvrir l’URL UI propre connue, lire120min, Acknowledge attendance record puis actualiser.

Attendu : Confirmation réelle persistante,120min confirmées.

Observé : Acknowledged persiste. Navigation alternative par URL connue explicitement nécessaire à cause de task30 ; ne valide pas la découverte dans le centre.

Traçabilité : test-43/run89:124;run90:124. 

Preuves : [horizon-new-a-confirmed](preuves/horizon-new-a-confirmed.png), [azur-student-a-confirmed-persisted](preuves/azur-student-a-confirmed-persisted.png)

## E2E-05 — B consulte et ne répond pas — PASS

Référence cahier : SEC-REPRISE-035. Profil : Stagiaire B. Organisation : Horizon et Azur.

Étapes réellement exécutées : Connexion indépendante séquentielle, URL propre connue, lire120min et ne cliquer aucune réponse.

Attendu : 0heure confirmée, demande sans réponse.

Observé : Viewed,120min réalisées/0confirmée. Le statut technique Viewed correspond à une demande encore sans confirmation.

Traçabilité : test-43/run89:125;run90:125. 

Preuves : [horizon-new-b-viewed](preuves/horizon-new-b-viewed.png), [azur-student-b-viewed-no-response](preuves/azur-student-b-viewed-no-response.png)

## E2E-06 — C conteste et fiabilité de la réponse — FAIL

Référence cahier : SEC-REPRISE-035. Profil : Stagiaire C. Organisation : Horizon et Azur.

Étapes réellement exécutées : Connexion propre, lire la prestation, saisir commentaireQA, Dispute puis actualiser ; réessayer après erreur.

Attendu : Contestation persistante sans augmenter les heures confirmées, réponse fiable.

Observé : Azur : Declined au premier parcours. Horizon09/11 : view503 et respond503 AUTHGATE_MEMBERSHIP_UNAVAILABLE, puis nouveau Dispute réussi et Declined persistant. Résultat final correct, incident intermittent conservé FAIL.

Traçabilité : test-43/run90:126. Ticket : task-32.

Preuves : [azur-student-c-disputed-persisted](preuves/azur-student-c-disputed-persisted.png), [horizon-c-draft-before-close-response-failure](preuves/horizon-c-draft-before-close-response-failure.png), [horizon-c-response-retry](preuves/horizon-c-response-retry.png), [horizon-new-c-contested-final](preuves/horizon-new-c-contested-final.png)

## E2E-07 — Calculs6h/2h/4h — PASS

Référence cahier : SEC-REPRISE-035. Profil : Formateurs reconnectés. Organisation : Horizon et Azur avant correction.

Étapes réellement exécutées : Actualiser les présences, comparer les trois statuts et lire les réponses réseau déclenchées par l’écran.

Attendu : 360min réalisées,120confirmées,240nonconfirmées ;1confirmée/1attente/1contestée.

Observé : Conforme dans GET/hours émis par l’UI, par ligne et total ; statuts Acknowledged/Viewed/Declined visibles. Aucun appelAPI manuel. Les cartes d’agrégats numériques ne sont pas rendues dans l’UI examinée : PASS calcul réseau, pas PASS visuel.

Traçabilité : test-43/run90:127;run89:127. 

Preuves : [horizon-new-final-statuses](preuves/horizon-new-final-statuses.png), [azur-pre-correction-three-statuses](preuves/azur-pre-correction-three-statuses.png)

## E2E-08 — Correction et nouvelle confirmation requise — PASS

Référence cahier : SEC-REPRISE-036. Profil : Formateur USER03 puis Stagiaire A. Organisation : Azur.

Étapes réellement exécutées : A confirmé : changer Present→Absent et sauvegarder ; rétablir Present et sauvegarder ; renvoyer A ; reconnecter A.

Attendu : Ancienne confirmation non comptée pour la nouvelle version ; nouvelle réponse requise.

Observé : Version3 :240réalisées/0confirmée. Version4 restaurée :360réalisées/0confirmée/360enattente ; nouvelle demandeA Pending puisViewed avec boutonsréponse. Ancienne URL garde son état historique Acknowledged, mais n’est plus comptée pour la version4. Aucune nouvelle confirmation faite.

Traçabilité : test-43/run89:129. 

Preuves : [azur-correction-persisted](preuves/azur-correction-persisted.png), [azur-trainer-save-pointer-success](preuves/azur-trainer-save-pointer-success.png), [azur-a-renewed-request](preuves/azur-a-renewed-request.png), [azur-a-old-signature-invalidated](preuves/azur-a-old-signature-invalidated.png), [azur-a-new-confirmation-required](preuves/azur-a-new-confirmation-required.png), [azur-final-new-version-unconfirmed](preuves/azur-final-new-version-unconfirmed.png)

## E2E-09 — Absence d’acquisition automatique de compétence — BLOCKED

Référence cahier : SEC-REPRISE-035. Profil : Stagiaire A. Organisation : Azur.

Étapes réellement exécutées : Ouvrir Skills après confirmation et vérifier le référentiel.

Attendu : Une confirmation de présence ne valide aucune compétence réelle.

Observé : Aucune compétence définie dans le référentiel QA. Absence d’acquisition sur une compétence existante non démontrée ; le scénario complet SEC035 reste BLOCKED malgré les calculs conformes.

Traçabilité : test-43/run89:128;run90:128. 

Preuves : [azur-student-a-skills-after-confirmation](preuves/azur-student-a-skills-after-confirmation.png)

## PREP-01 — Programme Azur nécessaire au second parcours — PASS

Référence cahier : Extension ciblée du prompt correctifs. Profil : USER02 propriétaire. Organisation : Azur.

Étapes réellement exécutées : Vérifier catalogue vide sans filtres ; créer programmeQA140h Moto, responsableUSER01, puis Attach program au site et recharger.

Attendu : Programme et responsable persistants dans Azur/Antibes uniquement.

Observé : AZUR-MOTO-QA créé201, responsable200, rattachement explicite au site ; visible après reload. La liste site était normalement vide avant rattachement, aucune perte de programme.

Traçabilité : test-9/run87:22,23. 

Preuves : [azur-program-attached-persisted](preuves/azur-program-attached-persisted.png)

## PREP-02 — Promotion et affectations Azur — PASS

Référence cahier : Extension ciblée du prompt correctifs. Profil : USER02 propriétaire. Organisation : Azur.

Étapes réellement exécutées : Créer cohorte01/11–31/12/2026 effectifprévu3, choisir contexte, affecter USER03 et inviter les trois identitésStudent existantes.

Attendu : Cohorte, formateur et3inscriptions persistants, sans recréer les identités.

Observé : QA P1 Azur20261109 active, USER03affectéCohort,3apprenants actifs inscrits ; aucun programme/cohorte préexistant effacé.

Traçabilité : test-10/run88:100. 

Preuves : [azur-cohort-persisted](preuves/azur-cohort-persisted.png), [azur-trainer-assignment-persisted](preuves/azur-trainer-assignment-persisted.png), [azur-three-learners-final](preuves/azur-three-learners-final.png)

## NR-01 — Création par administrateur — PASS

Référence cahier : Extension ciblée du prompt correctifs. Profil : USER01 Admin. Organisation : Horizon.

Étapes réellement exécutées : Créer séance future10/11 06–08h, recharger et consulter Planning.

Attendu : Bonne cohorte, bon formateur,2h persistantes.

Observé : QA NR Admin Horizon20261109 persistée dans Séances et Planning, anciennes séances conservées.

Traçabilité : test-14/run92:32. 

Preuves : [nr-admin-session-persisted](preuves/nr-admin-session-persisted.png), [nr-admin-planning](preuves/nr-admin-planning.png)

## NR-02 — Création par responsable pédagogique — PASS

Référence cahier : Extension ciblée du prompt correctifs. Profil : QA Responsable Horizon. Organisation : Horizon.

Étapes réellement exécutées : Créer séance future11/11 06–08h, recharger et consulter Planning.

Attendu : Création autorisée persistante.

Observé : QA NR Responsable Horizon20261109 sauvegardée et présente au Planning ; libelléSidebarTrainer erroné suivi séparément task24.

Traçabilité : test-14/run93:32. 

Preuves : [nr-manager-session-persisted](preuves/nr-manager-session-persisted.png), [nr-manager-planning](preuves/nr-manager-planning.png)

## NR-03 — Listes de formateurs — PASS

Référence cahier : Extension ciblée du prompt correctifs. Profil : Admin, Responsable, Formateurs. Organisation : Horizon et Azur.

Étapes réellement exécutées : Ouvrir les listes Trainer des formulaires après chargement.

Attendu : Identités actives disponibles ; formateur propre sélectionnable.

Observé : Listes chargées, identités réelles sélectionnées et créations réussies. Ce résultat ne valide pas le filtrage des promotions hors affectation, FAIL task29.

Traçabilité : test-43/run82:120;run89:120. 

Preuves : [trainer-create-filled](preuves/trainer-create-filled.png), [azur-trainer-filled](preuves/azur-trainer-filled.png), [nr-manager-session-persisted](preuves/nr-manager-session-persisted.png)

## NR-04 — Planning et synchronisation — PASS

Référence cahier : Extension ciblée du prompt correctifs. Profil : Admin, Responsable, Stagiaire A. Organisation : Horizon et Azur.

Étapes réellement exécutées : Consulter Planning après créations et changement d’organisation.

Attendu : Dates/horaires/cohortes cohérents et listes distinctes.

Observé : Horizon contient ses séances, Azur uniquement la séance QA Azur dans cette semaine ;06–08h cohérents.

Traçabilité : test-43/run82:121;test-14/run92:32;run93:32. 

Preuves : [trainer-session-planning](preuves/trainer-session-planning.png), [nr-admin-planning](preuves/nr-admin-planning.png), [nr-manager-planning](preuves/nr-manager-planning.png), [azur-student-planning-isolation](preuves/azur-student-planning-isolation.png)

## NR-05 — Consultation des séances existantes — PASS

Référence cahier : Extension ciblée du prompt correctifs. Profil : Stagiaire A et personnel. Organisation : Horizon et Azur.

Étapes réellement exécutées : Ouvrir Séances et actualiser sous les deux rôles.

Attendu : Séances autorisées lisibles, Stagiaire sans commande de modification/clôture.

Observé : Lecture persistante ; compteur Stagiaire1/1 pour sa présence, personnel3/3 pour la promotion.

Traçabilité : test-41/run85;run96. 

Preuves : [student-direct-sessions-corrected](preuves/student-direct-sessions-corrected.png), [azur-student-session-isolation](preuves/azur-student-session-isolation.png), [horizon-new-completed-persisted](preuves/horizon-new-completed-persisted.png)

## NR-06 — Modification titre/date/horaires d’une séance — BLOCKED

Référence cahier : Extension ciblée du prompt correctifs. Profil : Admin, Responsable, Formateur. Organisation : Horizon.

Étapes réellement exécutées : Rechercher édition d’une carte existante et cliquer son titre.

Attendu : Si édition disponible, sauvegarde et persistance vérifiables.

Observé : Aucun éditeur exposé dans l’UI examinée ; cartes Attendance et Complete seulement. Non exécuté, aucune sauvegarde supposée.

Traçabilité : test-14/run95:148. 

Preuves : [nr-admin-session-persisted](preuves/nr-admin-session-persisted.png), [nr-manager-session-persisted](preuves/nr-manager-session-persisted.png)

## NR-07 — Reconnexion des invités — PASS

Référence cahier : Extension ciblée du prompt correctifs. Profil : Formateurs et trois Stagiaires. Organisation : Horizon et Azur.

Étapes réellement exécutées : Déconnexion/connexion réelle et sélection explicite de l’organisation.

Attendu : Identités/rôles et appartenances persistants.

Observé : Connexions réelles répétées ; trois Stagiaires ont leurs deux organisations autorisées, sans espace personnel ajouté.

Traçabilité : test-43/run89;run90;test-27/run94. 

Preuves : [student-a-two-spaces](preuves/student-a-two-spaces.png), [nr-user3-four-spaces-restored](preuves/nr-user3-four-spaces-restored.png)

## NR-08 — Refus d’une demande d’un autre stagiaire — PASS

Référence cahier : SEC-REPRISE-007. Profil : Stagiaire C. Organisation : Horizon.

Étapes réellement exécutées : Ouvrir sous C l’URL de la demandeA confirmée.

Attendu : Aucun contenu ni bouton réponse pour A.

Observé : Refus de chargement et aucun contenuA/commande ; pas de fuite démontrée.

Traçabilité : test-41/run91:130. 

Preuves : [horizon-c-foreign-a-confirmed-refused](preuves/horizon-c-foreign-a-confirmed-refused.png)

## NR-09 — Isolation des heures et des listes — PASS

Référence cahier : Extension ciblée du prompt correctifs. Profil : Formateurs, Stagiaire A. Organisation : Horizon et Azur.

Étapes réellement exécutées : Changer d’organisation, contrôler Sessions/Planning et lire les résumés des deux séances UI.

Attendu : Aucune liste ou agrégat mélangeant les deux promotions.

Observé : Sessions de deux centres distincts ; résumés360/120/240 par session distincte avant correction. Après correction Azur360/0/360, Horizon360/120/240 inchangé. Contrôle ciblé, pas preuve exhaustive d’isolation serveur.

Traçabilité : test-43/run89:127;run90:127;test-41/run96. 

Preuves : [azur-student-session-isolation](preuves/azur-student-session-isolation.png), [horizon-new-final-statuses](preuves/horizon-new-final-statuses.png), [azur-final-new-version-unconfirmed](preuves/azur-final-new-version-unconfirmed.png)

## NR-10 — Révocation secondaire conserve les autres espaces — PASS

Référence cahier : INV-REPRISE-026;SEC-REPRISE-022. Profil : USER04 Admin puis USER03. Organisation : Méditerranée puis Azur.

Étapes réellement exécutées : Retirer USER03Med0affectation ; actualiser ; reconnecter USER03 et ouvrir Azur.

Attendu : Med absente, autres appartenances préservées.

Observé : Med retirée,3espaces restants proposés ; Azur fonctionne avec séance existante. Contrôle après nouvelle connexion, pas ancienJWT.

Traçabilité : test-27/run94:144,145. 

Preuves : [nr-user3-med-revoked](preuves/nr-user3-med-revoked.png), [nr-user3-three-spaces](preuves/nr-user3-three-spaces.png), [nr-user3-azur-preserved](preuves/nr-user3-azur-preserved.png)

## NR-11 — Restauration dans la seconde organisation — PASS

Référence cahier : SEC-REPRISE-038. Profil : USER04 Admin puis USER03. Organisation : Méditerranée.

Étapes réellement exécutées : Réinviter USER03Educationalmanager, recharger ; reconnecter et ouvrir Med.

Attendu : Une appartenance active restaurée,4espaces et mêmes rôles.

Observé : Unique ligne Active et quatre espaces retrouvés, Med ouvert ; propriétaires et données métier conservés.

Traçabilité : test-27/run94:146. 

Preuves : [nr-user3-med-restored](preuves/nr-user3-med-restored.png), [nr-user3-four-spaces-restored](preuves/nr-user3-four-spaces-restored.png), [nr-user3-restored-med-space](preuves/nr-user3-restored-med-space.png)

## NR-12 — Révocation avec ancienJWT dans deux sessions — BLOCKED

Référence cahier : Extension ciblée du prompt correctifs. Profil : Admin et invité simultanés. Organisation : Multi-organisation.

Étapes réellement exécutées : Préserver une session utilisateur pendant révocation dans une deuxième session.

Attendu : L’accès métier doit être refusé sans attendre expiration duJWT.

Observé : Impossible sous contrainte unique onglet et aucune seconde session autorisée ; aucunJWT manipulé. AucunPASS de sécurité sur ce point.

Traçabilité : test-27/run94:118. 

Preuves : Blocage documenté ; aucune preuve d’exécution revendiquée.

## NR-13 — Libellé de clôture EN — PASS

Référence cahier : Extension ciblée du prompt correctifs. Profil : Formateurs. Organisation : Horizon et Azur.

Étapes réellement exécutées : Lire et utiliser le bouton de clôture.

Attendu : Complete session traduit en anglais, pas de clé brute.

Observé : Libellé EN observé et utilisé avec succès ; preuve fonctionnelle et capture.

Traçabilité : test-43/run83:141;run89:141;run90:141. 

Preuves : [old-session-completion-click](preuves/old-session-completion-click.png), [azur-trainer-completed-persisted](preuves/azur-trainer-completed-persisted.png), [horizon-new-completed-persisted](preuves/horizon-new-completed-persisted.png)

## NR-14 — Libellé de clôture FR — BLOCKED

Référence cahier : Extension ciblée du prompt correctifs. Profil : Personnel. Organisation : Horizon et Azur.

Étapes réellement exécutées : Chercher le réglage de langue utilisateur exposé.

Attendu : Terminer la séance en FR vérifié à l’écran.

Observé : Aucun commutateur UI utilisateur trouvé ; langue organisation par défautFR ne change pas l’affichageEN observé. Pas de manipulation du stockage ni de profilChrome. FR non vérifié.

Traçabilité : test-14/run95:147. 

Preuves : [nr-manager-session-persisted](preuves/nr-manager-session-persisted.png)

## NR-15 — Lien Présences conserve la séance choisie — FAIL

Référence cahier : Extension ciblée du prompt correctifs. Profil : Admin et Formateur. Organisation : Horizon.

Étapes réellement exécutées : Cliquer Attendance de la séance08/11 08–10h.

Attendu : Ouvrir la feuille08/11 08–10h.

Observé : Autre séance09/11 ouverte sans sélecteur :08–12h Admin,06–08h Formateur. Risque de travailler sur la mauvaise feuille ; aucune mauvaise écriture volontaire.

Traçabilité : test-44/run86:143. Ticket : task-31.

Preuves : [admin-sessions-before-old-attendance](preuves/admin-sessions-before-old-attendance.png), [admin-old-attendance-wrong-session](preuves/admin-old-attendance-wrong-session.png), [old-session-attendance-routes-to-new](preuves/old-session-attendance-routes-to-new.png)

## NR-16 — Planning Stagiaire, lien de création — FAIL

Référence cahier : Extension ciblée du prompt correctifs. Profil : Stagiaire A. Organisation : Azur.

Étapes réellement exécutées : Cliquer Add to schedule depuis Planning.

Attendu : Commande réservée masquée ou refus explicite.

Observé : Lien visible vers/planning/nouveau puis retour silencieux/planning, aucun formulaire ni création non autorisée.

Traçabilité : test-41/run97:149. Ticket : task-33.

Preuves : [azur-student-planning-isolation](preuves/azur-student-planning-isolation.png), [student-planning-create-access](preuves/student-planning-create-access.png)

## NR-17 — Accueil Formateur, date et compteur réels — FAIL

Référence cahier : SEC-REPRISE-004. Profil : USER03 Trainer. Organisation : Azur.

Étapes réellement exécutées : Ouvrir Accueil puis recharger.

Attendu : Date courante et nombre réel de séances.

Observé : 09/11 affiche toujours Monday21September2026·5sessions today avec My sessions today vide malgré une séance QA du jour.

Traçabilité : test-40/run98:97. Ticket : task-19.

Preuves : [nr-trainer-static-home-current](preuves/nr-trainer-static-home-current.png), [nr-trainer-home-reload-errors](preuves/nr-trainer-home-reload-errors.png)

## NR-18 — Préchargements selon permissions — FAIL

Référence cahier : SEC-REPRISE-004. Profil : Formateurs et Stagiaires. Organisation : Horizon et Azur.

Étapes réellement exécutées : Connexion et reload, observer notifications/console/réseau.

Attendu : Pas d’alertes parasites pour ressources administratives hors rôle.

Observé : Préchargementsprograms/referentials/audit/dashboards403 entraînent Some workspace data could not be loaded. Métier autorisé200 distinct.

Traçabilité : test-40/run98:98. Ticket : task-20.

Preuves : [nr-trainer-home-reload-errors](preuves/nr-trainer-home-reload-errors.png), [trainer-session-persisted](preuves/trainer-session-persisted.png)

## NR-19 — Libellé du rôle Responsable pédagogique — FAIL

Référence cahier : Extension ciblée du prompt correctifs. Profil : QA Responsable Horizon. Organisation : Horizon.

Étapes réellement exécutées : Connexion comme Responsable, création autorisée puis observation sidebar.

Attendu : Rôle affiché cohérent avec rôle réellement attribué.

Observé : SidebarTrainer encore affichée malgré rôle Responsable et création autorisée. Défaut existant task24, pas perte de permission de création.

Traçabilité : test-14/run93:32. Ticket : task-24.

Preuves : [nr-manager-session-persisted](preuves/nr-manager-session-persisted.png)
