# Rapport de recette — lot 1 du 07/11/2026

**Campagne partielle — NO GO provisoire.** Le cahier n’est pas entièrement exécuté. Le parcours essentiel séance → émargement → confirmation, les permissions des rôles et l’isolation complète des quatre centres restent à valider.

## A. Synthèse
| Mesure | Valeur |
|---|---:|
| Scénarios identifiés (IDs uniques) | 793 |
| Exécutés avec verdict PASS/FAIL | 21 |
| PASS | 17 |
| FAIL | 4 |
| BLOCKED | 9 |
| NOT APPLICABLE | 3 |
| NOT RUN | 760 |
| Réussite sur exécutés = 17 / (17+4) | 80,95 % |
| Couverture PASS/FAIL = 21 / 793 | 2,65 % |

Ce taux ne s’applique qu’au premier lot, pas au produit. Les variantes de comptes ne multiplient pas les IDs. MENU-UI-009 échoue sur USER-01 ; les trois autres itérations restent à réaliser.

## Environnement et découverte
- UI : https://pedagora.staging.locaguest.com ; API : https://pedagora.api.staging.locaguest.com ; AuthGate : https://auth.staging.locaguest.com.
- Staging déjà démarré ; aucun serveur local ni API appelée directement. Toutes les mutations ont été faites dans l’interface, onglet1 existant.
- Sources consultées : DOCX QA du 07/11 (extraction complète), README, package.json, environnement staging, routes et recherche de parcours mot de passe. Angular22, npm start pour local ; configuration staging legacy. Les appels réseau cités sont ceux observés dans Chrome.
- L’ancienne campagne 547 scénarios de la mémoire ne constitue pas le référentiel de ce lot. Les artefacts CC ont été recherchés avant création ; aucun verdict ancien n’a été repris comme preuve actuelle.
- Tests créés : test-29 à test-38 ; tests réutilisés et adaptés : test-4, test-25, test-23. Runs achevés. Exports durables cc-tests-20261107.json et cc-tasks-20261107.json.
- Propriétaires créés : USER-01 Sam Horizon QA / Centre Horizon ECSR ; USER-02 Sam Azur QA / Académie Azur Deux-Roues ; USER-03 Sam Provence QA / Institut Provence Poids Lourds ; USER-04 Sam Méditerranée QA / Institut Méditerranée Ambulancier. Chacun connecté puis actualisé ; une seule organisation propre affichée. Aucun mot de passe modifié.
- Horizon : organisation cdd10510-dff3-418c-8fff-883a7b29ef36. Aucun enregistrement métier dépendant créé. Le contrôle du sélecteur ne constitue pas un contrôle complet d’isolation multi-tenant.

## B. Portée réellement exécutée
Authentification : quatre inscriptions et connexions, validation vide/mauvais e-mail, doublon, mauvais mot de passe et correction, adresse inconnue, casse/espaces, reload et déconnexion, variante d’accès direct protégé dans la session courante, tentative de récupération.
Contexte Horizon : organisation unique, listes dépendantes vides, conservation après reload.
Pilotage Horizon : ouverture, sept étapes et indicateurs initiaux.
Présences Horizon : état initial avec défaut de libellé.
Ouvertures complémentaires sans verdict complet : planning, stagiaires, promotions, séances, conduite, fiches, compétences, stages, documents, statistiques, administration. Leur contenu est conservé dans observation-horizon-*.txt ; les interactions et répétitions par centre manquantes ne sont pas PASS.

## C. Anomalies nouvelles
| ID | Priorité | Résumé | Scénario | Preuve |
|---|---|---|---|---|
| task-14 | P2 | Double inscription présentée à tort comme indisponibilité AuthGate | AUTH-UI-006 | [capture](duplicate-inscription.png) |
| task-15 | P3 | Sections vides du pilotage sans message explicite | ORG-INIT-003 | [capture](horizon-pilotage-initial.png) |
| task-16 | P1 | Mot de passe oublié retourne à une connexion vierge ; récupération inaccessible | AUTH-UI-023 | [capture](forgot-password.png) |
| task-17 | P3 | including {{count}} excused affiché littéralement | MENU-UI-009 / USER-01 | [capture](attendance-empty.png) |

Les étapes de reproduction, attendu/observé, rôle et URL figurent dans le registre détaillé et l’export CC Tasks. Pas de fuite multi-tenant démontrée dans ce lot.

Régression supplémentaire : test-23 run41 PASS sur Horizon sans promotion, exports PDF/Excel/Print désactivés avec prérequis explicite (DOM et [capture](reports-no-cohort.png)). Commentaire ajouté à task-12 ; ticket conservé ouvert car le contexte original AFTRAL n’a pas été rejoué. Aucun fichier exporté ni contenu PDF/Excel validé.

## D. Dépendances et blocages
Les 9 BLOCKED sont AUTH-UI-007/008 (identité inter-application absente), AUTH-UI-015 (fenêtre privée non disponible ; variante même onglet conforme), AUTH-UI-018 (deux profils indépendants non disponibles), AUTH-UI-019 à 022 (commande de changement non exposée), ORG-INIT-005 (propriétaire déjà éligible responsable).
AUTH-UI-024 à 026 sont NOT APPLICABLE au mode legacy constaté ; cela ne vaut pas validation OIDC.
Les 760 NOT RUN demeurent non exécutés, sans les convertir globalement en blocages. Les préconditions métier de SIG-E2E restent à préparer ; aucune livraison e-mail ni aucun total d’heures signé n’est validé.
Aucun SIRET, agrément ou adresse légale inventé. Aucun compte existant d’ECF/AFTRAL supprimé ou modifié.
Les preuves enregistrées par les outils Chrome sont horodatées dans la conversation du 07/11/2026 ; les PNG sont dans ce dossier. Les snapshots numériques cités dans les tests restent dans la trace d’outils ; les observations DOM de menus sont aussi sauvegardées ici.

## E. Décision
**NO GO provisoire** : récupération de compte inaccessible (P1) et contrôles essentiels non exécutés. Ce lot ne permet aucune conclusion favorable sur confirmation d’heures, signatures, statistiques après activité, permissions des rôles ou isolation complète.

Suite ordonnée et préconditions : [plan de recette](plan-recette-20261107.md). Source de vérité des verdicts : [registre JSON](campagne-20261107.json), [suivi CSV](suivi-20261107.csv). Détails par ID dans suivi-detaille-20261107.md.
